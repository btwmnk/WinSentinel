using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Diagnostics.Tracing;
using Microsoft.Diagnostics.Tracing.Parsers;
using Microsoft.Diagnostics.Tracing.Parsers.Kernel;
using Microsoft.Diagnostics.Tracing.Session;
using Microsoft.Win32;

namespace XFlags.Services
{
    public enum MonMode { Game, Program, Network }

    public sealed class MonLine
    {
        public string Op = "";
        public string Color = "info";
        public string Text = "";
    }

    public sealed class MonitorService
    {
        public readonly ConcurrentQueue<MonLine> Queue = new();
        public bool IsRunning { get; private set; }

        public bool Verbose { get; set; }
        public bool CaptureFiles { get; set; }
        public string CaptureDir { get; private set; } = "";

        private TraceEventSession? _kernel, _dns;
        private readonly List<Socket> _raw = new();
        private readonly List<FileSystemWatcher> _watchers = new();
        private readonly object _lock = new();
        private readonly HashSet<int> _pids = new();
        private readonly Dictionary<int, string> _pidNames = new();
        private readonly Dictionary<int, string> _pidPaths = new();
        private readonly HashSet<string> _seen = new(StringComparer.OrdinalIgnoreCase);
        private readonly Dictionary<string, NetStat> _net = new();
        private readonly Dictionary<string, string> _dnsMap = new();
        private readonly Dictionary<int, HashSet<string>> _writes = new();
        private readonly Dictionary<string, int> _flowPid = new();
        private readonly HashSet<string> _localIps = new();
        private readonly Dictionary<ulong, string> _kcb = new();
        private readonly List<MonLine> _history = new();
        private readonly Dictionary<string, string> _captured = new(StringComparer.OrdinalIgnoreCase);
        private readonly HashSet<string> _capturing = new(StringComparer.OrdinalIgnoreCase);
        private StreamWriter? _log;
        private readonly object _logLock = new();

        private List<string> _targets = new();
        private bool _autoUe, _ueLog, _netAll, _game;
        private int _launchParent = -1;
        private DateTime _start;
        private CancellationTokenSource? _cts;
        private volatile bool _sniff;

        private static readonly string[] CaptureExt = { ".ini", ".log", ".json", ".txt", ".cfg", ".conf", ".xml", ".yml", ".yaml", ".dat",
                                                        ".cmd", ".bat", ".ps1", ".psm1", ".vbs", ".vbe", ".js", ".jse", ".wsf", ".hta", ".reg", ".tmp", ".config" };

        public MonLine[] Snapshot() { lock (_lock) return _history.ToArray(); }
        public string? CapturedCopy(string original) { lock (_lock) return _captured.TryGetValue(original, out var c) ? c : null; }

        public static string LogDir => Path.Combine(AppContext.BaseDirectory, "Logs");

        private static readonly Regex UeExe = new(@"-(Win64|Win32|WinGDK)-(Shipping|Test|DebugGame)\.exe", RegexOptions.IgnoreCase | RegexOptions.Compiled);
        private static readonly Regex UePkg = new(@"(?<![\w/])/(?:Game|Engine)/[\w\-\./]+|[\w\-\.:/\\]+\.(?:uasset|umap)", RegexOptions.IgnoreCase | RegexOptions.Compiled);
        private static readonly Regex UeCat = new(@"^(?:\[[^\]]*\])*\s*([A-Za-z]\w*):", RegexOptions.Compiled);
        private static readonly Regex IpRe = new(@"(?:::ffff:)?(\d{1,3}(?:\.\d{1,3}){3})", RegexOptions.Compiled);

        private static readonly string[] Tools = { "cmd.exe","powershell.exe","pwsh.exe","dism.exe","reg.exe","regedit.exe","sc.exe","schtasks.exe","bcdedit.exe","netsh.exe","wmic.exe","msiexec.exe","rundll32.exe","regsvr32.exe","taskkill.exe","icacls.exe","takeown.exe","vssadmin.exe" };
        private static readonly string[] Containers = { ".pak",".utoc",".ucas",".sig" };
        private static readonly string[] Packages = { ".uasset",".umap",".uexp",".ubulk" };
        private static readonly string[] HttpMethods = { "GET ","POST ","PUT ","HEAD ","DELETE ","OPTIONS ","PATCH ","CONNECT " };
        private static readonly string[] Persist = { @"\CurrentVersion\Run", @"\CurrentVersion\RunOnce", @"\Winlogon", @"\Image File Execution Options", @"\CurrentControlSet\Services", @"\Active Setup\Installed Components" };

        private sealed class NetStat { public int Pid; public string Proc="",Proto="",Ip=""; public int Port; public long Sent,Recv; }

        private void Emit(string color, string op, string text, DateTime? at = null)
        {
            double t = ((at ?? DateTime.Now) - _start).TotalSeconds;
            var line = new MonLine { Color = color, Op = op, Text = $"+{t,8:0.000}  {op,-8} {text}" };
            Queue.Enqueue(line);
            lock (_lock) { _history.Add(line); if (_history.Count > 100000) _history.RemoveRange(0, 20000); }
            lock (_logLock) { try { _log?.WriteLine(line.Text); } catch { } }
        }

        public static bool IsElevated => TraceEventSession.IsElevated() == true;

        public bool Start(MonMode mode, List<string> targets, bool autoUe, bool ueLog, string ueArgs, string? launchPath = null)
        {
            Stop();
            if (!IsElevated) { Emit("del", "ERROR", "run XFlags as administrator"); return false; }

            _game = mode == MonMode.Game;
            _netAll = mode == MonMode.Network;
            _targets = targets;
            _autoUe = autoUe && _game;
            _ueLog = ueLog && _game;
            _start = DateTime.Now;
            _cts = new CancellationTokenSource();
            lock (_lock) { _pids.Clear(); _pidNames.Clear(); _pidPaths.Clear(); _seen.Clear(); _net.Clear(); _dnsMap.Clear(); _writes.Clear(); _flowPid.Clear(); _localIps.Clear(); _kcb.Clear(); _history.Clear(); _captured.Clear(); _capturing.Clear(); _launchParent = -1; }

            try
            {
                Directory.CreateDirectory(LogDir);
                string tag = targets.Count > 0 ? Path.GetFileNameWithoutExtension(targets[0]) : (mode == MonMode.Network ? "all" : "ue");
                string stamp = _start.ToString("yyyyMMdd_HHmmss");
                lock (_logLock) { _log?.Dispose(); _log = new StreamWriter(Path.Combine(LogDir, $"{mode.ToString().ToLowerInvariant()}_{tag}_{stamp}.log"), false, Encoding.UTF8); }
                CaptureDir = Path.Combine(LogDir, "captured", $"{tag}_{stamp}");
                if (CaptureFiles) Directory.CreateDirectory(CaptureDir);
            }
            catch { }

            if (CaptureFiles) StartCaptureWatch(targets, launchPath);

            var kw = KernelTraceEventParser.Keywords.Process | KernelTraceEventParser.Keywords.ImageLoad
                   | KernelTraceEventParser.Keywords.FileIOInit | KernelTraceEventParser.Keywords.FileIO
                   | KernelTraceEventParser.Keywords.DiskFileIO | KernelTraceEventParser.Keywords.Registry
                   | KernelTraceEventParser.Keywords.NetworkTCPIP;
            try
            {
                if (!_netAll) StartDns();
                if (!_game) StartSniffer();
                var s = new TraceEventSession(KernelTraceEventParser.KernelSessionName) { StopOnDispose = true };
                s.EnableKernelProvider(kw);
                Hook(s);
                _kernel = s;
                Task.Run(() => { try { s.Source.Process(); } catch (Exception ex) { Emit("del", "ERROR", "ETW: " + ex.Message); } });
            }
            catch (Exception ex) { Emit("del", "ERROR", "cannot start ETW: " + ex.Message); Stop(); return false; }

            IsRunning = true;

            foreach (var t in targets)
                foreach (var p in Process.GetProcessesByName(Path.GetFileNameWithoutExtension(t)))
                {
                    Track(p.Id, t, "already running");
                    if (_ueLog) StartUeTail(PathOf(p), p.Id);
                }

            if (launchPath != null)
            {
                string args = _ueLog ? ueArgs : "";
                lock (_lock) _launchParent = Environment.ProcessId;
                try { Process.Start(new ProcessStartInfo(launchPath, args) { UseShellExecute = false, WorkingDirectory = Path.GetDirectoryName(launchPath) ?? "" }); Emit("info","INFO",$"launched {Path.GetFileName(launchPath)} {args}"); }
                catch (Exception ex) { Emit("del","ERROR","launch failed: " + ex.Message); }
                finally { Task.Delay(3000).ContinueWith(_ => { lock (_lock) _launchParent = -1; }); }
            }
            else Emit("info", "INFO", _netAll ? "watching network of ALL processes" : "waiting for: " + string.Join(", ", targets) + (_autoUe ? " (+any UE *-Shipping.exe)" : ""));
            return true;
        }

        public void Stop()
        {
            try { _cts?.Cancel(); } catch { }
            _cts = null;
            _sniff = false;
            foreach (var s in _raw) { try { s.Close(); } catch { } }
            _raw.Clear();
            foreach (var w in _watchers) { try { w.EnableRaisingEvents = false; w.Dispose(); } catch { } }
            _watchers.Clear();
            var d = _dns; _dns = null; if (d != null) { try { d.Dispose(); } catch { } }
            var k = _kernel; _kernel = null;
            if (k != null) { try { k.Dispose(); } catch { } if (IsRunning) Summary(); }
            IsRunning = false;
            lock (_logLock) { try { _log?.Flush(); _log?.Dispose(); } catch { } _log = null; }
        }

        private void Hook(TraceEventSession s)
        {
            var k = s.Source.Kernel;
            k.ProcessStart += d =>
            {
                string img = d.ImageFileName ?? "", cmd = d.CommandLine ?? "";
                string path = ExeFromCmd(cmd);
                lock (_lock) { _pidPaths[d.ProcessID] = path; _pidNames[d.ProcessID] = path.Length > 0 ? Path.GetFileName(path) : img; }
                bool child, us; lock (_lock) { child = _pids.Contains(d.ParentID); us = _launchParent > 0 && d.ParentID == _launchParent; }
                bool target = Matches(img, cmd);
                if (!child && !target && !us) return;
                if (path.Length > 0) img = Path.GetFileName(path);
                if (img.Equals("conhost.exe", StringComparison.OrdinalIgnoreCase)) return;
                Track(d.ProcessID, img, null);
                string why = child ? $"child of {Name(d.ParentID)}" : "target";
                bool tool = Tools.Any(t => img.Equals(t, StringComparison.OrdinalIgnoreCase));
                Emit("proc", tool ? "PROC !" : "PROC", $"[{d.ProcessID}] {img} ({why})  {cmd}", d.TimeStamp);
                if (_ueLog && _game && (target || us) && path.Length > 0) StartUeTail(path, d.ProcessID);
            };
            k.ProcessStop += d => { if (Tracked(d.ProcessID)) Emit("proc", "EXIT", $"[{d.ProcessID}] {Name(d.ProcessID)} exit {d.ExitStatus}", d.TimeStamp); };
            k.ImageLoad += d => { if (Verbose && _game && Tracked(d.ProcessID) && First("DLL|" + d.ProcessID + "|" + d.FileName)) Emit("file", "DLL", $"{Name(d.ProcessID)}  {d.FileName}", d.TimeStamp); };
            k.FileIOCreate += d =>
            {
                if (!Tracked(d.ProcessID)) return;
                string f = d.FileName ?? "";
                if (f.Length == 0) return;
                TryCapture(f);
                if (!First("OPEN|" + f)) return;
                if (_game && Packages.Any(x => f.EndsWith(x, StringComparison.OrdinalIgnoreCase))) { Emit("asset", "UASSET", $"{Name(d.ProcessID)}  {f}", d.TimeStamp); return; }
                if (_game && Containers.Any(x => f.EndsWith(x, StringComparison.OrdinalIgnoreCase))) { Emit("asset", "PAK", $"{Name(d.ProcessID)}  {f}", d.TimeStamp); return; }
                if (Verbose) Emit("file", "OPEN", $"{Name(d.ProcessID)}  {f}", d.TimeStamp);
                else if (InterestingOpen(f)) Emit("file", "OPEN", $"{Name(d.ProcessID)}  {f}", d.TimeStamp);
            };
            k.FileIOWrite += d => { if (Tracked(d.ProcessID)) { string f = d.FileName ?? ""; if (f.Length > 0) { TryCapture(f); if (First("WRITE|" + f)) { RememberWrite(d.ProcessID, f); Emit("file", "WRITE", $"{Name(d.ProcessID)}  {f}", d.TimeStamp); } } } };
            k.FileIODelete += d =>
            {
                if (!Tracked(d.ProcessID)) return;
                string f = d.FileName ?? ""; if (f.Length == 0 || !First("DEL|" + f)) return;
                string saved; lock (_lock) _captured.TryGetValue(f, out saved!);
                Emit("del", "DELETE", $"{Name(d.ProcessID)}  {f}" + (string.IsNullOrEmpty(saved) ? "" : "   [saved copy kept]"), d.TimeStamp);
            };
            k.FileIORename += d => { if (Tracked(d.ProcessID)) { string f = d.FileName ?? ""; if (f.Length > 0 && First("REN|" + f)) Emit("file", "RENAME", $"{Name(d.ProcessID)}  {f}", d.TimeStamp); } };

            k.RegistryKCBCreate += d => LearnKcb(d);
            k.RegistryKCBRundownBegin += d => LearnKcb(d);
            k.RegistryKCBRundownEnd += d => LearnKcb(d);
            k.RegistryKCBDelete += d => { lock (_lock) _kcb.Remove((ulong)d.KeyHandle); };
            k.RegistryOpen += d => LearnKcb(d);
            k.RegistryCreate += d => { LearnKcb(d); if (Verbose) Reg(d, "REG KEY+", "reg"); };
            k.RegistrySetValue += d => Reg(d, "REG SET", "reg");
            k.RegistryDelete += d => Reg(d, "REG KEY-", "del");
            k.RegistryDeleteValue += d => Reg(d, "REG DEL", "del");
            k.TcpIpSend += d => Net(d.ProcessID, d.daddr, d.dport, d.size, true, "TCP", d.TimeStamp);
            k.TcpIpRecv += d => Net(d.ProcessID, d.daddr, d.dport, d.size, false, "TCP", d.TimeStamp);
            k.UdpIpSend += d => Net(d.ProcessID, d.daddr, d.dport, d.size, true, "UDP", d.TimeStamp);
            k.UdpIpRecv += d => Net(d.ProcessID, d.daddr, d.dport, d.size, false, "UDP", d.TimeStamp);
        }

        private static readonly string _winDir = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
        private static readonly string[] DataExt =
            { ".ini", ".cfg", ".conf", ".config", ".json", ".xml", ".yml", ".yaml", ".toml", ".dat", ".sav", ".save",
              ".db", ".sqlite", ".txt", ".log", ".csv", ".lua", ".cvar", ".profile", ".settings", ".reg", ".bak" };

        private bool InterestingOpen(string f)
        {
            if (f.Length < 3 || f.IndexOf(":\\", StringComparison.Ordinal) < 0) return false;
            if (_winDir.Length > 0 && f.StartsWith(_winDir, StringComparison.OrdinalIgnoreCase)) return false;
            return DataExt.Contains(Path.GetExtension(f), StringComparer.OrdinalIgnoreCase);
        }

        private void LearnKcb(RegistryTraceData d)
        {
            string n = d.KeyName ?? "";
            if (n.Length == 0) return;
            lock (_lock) _kcb[(ulong)d.KeyHandle] = n;
        }

        private string ResolveKey(RegistryTraceData d)
        {
            string n = d.KeyName ?? "";
            if (n.StartsWith(@"\REGISTRY", StringComparison.OrdinalIgnoreCase)) return n;
            string? bas; lock (_lock) _kcb.TryGetValue((ulong)d.KeyHandle, out bas);
            if (bas == null) return n;
            if (n.Length == 0) return bas;
            if (bas.EndsWith(n, StringComparison.OrdinalIgnoreCase)) return bas;
            if (n.StartsWith(bas, StringComparison.OrdinalIgnoreCase)) return n;
            return bas.TrimEnd('\\') + "\\" + n;
        }

        private void Reg(RegistryTraceData d, string op, string color)
        {
            if (d.Status != 0 || !Tracked(d.ProcessID)) return;
            string key = NormReg(ResolveKey(d)), val = d.ValueName ?? "";

            if (!key.StartsWith("HKLM", StringComparison.OrdinalIgnoreCase) && !key.StartsWith("HKU", StringComparison.OrdinalIgnoreCase)) return;
            string who = Name(d.ProcessID); DateTime ts = d.TimeStamp;

            if (op == "REG SET")
            {

                Task.Run(() =>
                {
                    string data = ReadRegValue(key, val);
                    string target = val.Length > 0 ? $"{key}  [{val}]" : key;
                    if (data.Length > 0) target += " = " + data;
                    if (First("REG SET|" + target)) EmitReg(who, key, "REG SET", "reg", target, ts);
                });
                return;
            }

            string tgt = val.Length > 0 && op != "REG KEY+" && op != "REG KEY-" ? $"{key}  [{val}]" : key;
            if (First(op + "|" + tgt)) EmitReg(who, key, op, color, tgt, ts);
        }

        private void EmitReg(string who, string key, string op, string color, string target, DateTime ts)
        {
            if (Persist.Any(p => key.IndexOf(p, StringComparison.OrdinalIgnoreCase) >= 0) && op != "REG KEY-" && op != "REG DEL")
                Emit("autorun", "AUTORUN!", $"{who}  {target}", ts);
            else Emit(color, op, $"{who}  {target}", ts);
        }

        private void StartCaptureWatch(List<string> targets, string? launchPath)
        {
            var dirs = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            void Add(string? d) { if (!string.IsNullOrEmpty(d) && Directory.Exists(d)) dirs.Add(d!); }

            Add(Path.GetTempPath());
            Add(Environment.GetEnvironmentVariable("TEMP"));
            Add(launchPath != null ? Path.GetDirectoryName(launchPath) : null);
            foreach (var t in targets)
                foreach (var p in Process.GetProcessesByName(Path.GetFileNameWithoutExtension(t)))
                    try { Add(Path.GetDirectoryName(p.MainModule?.FileName)); } catch { }

            foreach (var dir in dirs)
            {
                try
                {
                    var w = new FileSystemWatcher(dir) { IncludeSubdirectories = true, InternalBufferSize = 64 * 1024 };
                    w.NotifyFilter = NotifyFilters.FileName | NotifyFilters.LastWrite | NotifyFilters.Size;
                    FileSystemEventHandler h = (s, e) => TryCapture(e.FullPath);
                    w.Created += h;
                    w.Changed += h;
                    w.Renamed += (s, e) => TryCapture(e.FullPath);
                    w.EnableRaisingEvents = true;
                    _watchers.Add(w);
                }
                catch { }
            }
            if (_watchers.Count > 0) Emit("info", "CAPTURE", $"watching {_watchers.Count} folder(s) for created files -> {CaptureDir}");
        }

        private void TryCapture(string f)
        {
            if (!CaptureFiles || f.Length == 0) return;
            string ext = Path.GetExtension(f);
            if (!CaptureExt.Contains(ext, StringComparer.OrdinalIgnoreCase)) return;

            string nm = Path.GetFileName(f);
            if (nm.Equals("desktop.ini", StringComparison.OrdinalIgnoreCase) || nm.Equals("thumbs.db", StringComparison.OrdinalIgnoreCase)) return;
            if (nm.Contains('$')) return;
            lock (_lock)
            {
                if (_captured.TryGetValue(f, out var got) && got.Length > 0) return;
                if (!_capturing.Add(f)) return;
            }
            Task.Run(async () =>
            {
                string dest = "";
                try
                {

                    for (int i = 0; i < 30; i++)
                    {
                        try
                        {
                            if (File.Exists(f))
                            {
                                long len = new FileInfo(f).Length;
                                if (len > 8L * 1024 * 1024) break;
                                if (len > 0)
                                {
                                    Directory.CreateDirectory(CaptureDir);
                                    string d = Path.Combine(CaptureDir, Flatten(f));

                                    using (var src = new FileStream(f, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
                                    using (var dst = File.Create(d))
                                        src.CopyTo(dst);
                                    dest = d;
                                    break;
                                }
                            }
                        }
                        catch { }
                        await Task.Delay(100);
                    }
                    if (dest.Length > 0)
                    {
                        lock (_lock) _captured[f] = dest;
                        Emit("asset", "SAVED", $"copy of {Path.GetFileName(f)} -> {dest}");
                    }
                }
                catch { }
                finally { lock (_lock) _capturing.Remove(f); }
            });
        }

        private static string Flatten(string full)
        {
            string name = Path.GetFileName(full);
            uint h = 2166136261; foreach (char c in full) { h ^= c; h *= 16777619; }
            foreach (char c in Path.GetInvalidFileNameChars()) name = name.Replace(c, '_');
            return h.ToString("x8") + "_" + name;
        }

        private static string ReadRegValue(string key, string valueName)
        {
            try
            {
                RegistryKey? root = null; string sub = "";
                if (key.StartsWith("HKLM\\", StringComparison.OrdinalIgnoreCase)) { root = Registry.LocalMachine; sub = key[5..]; }
                else if (key.StartsWith("HKU\\", StringComparison.OrdinalIgnoreCase)) { root = Registry.Users; sub = key[4..]; }
                if (root == null) return "";
                using var k = root.OpenSubKey(sub);
                var v = k?.GetValue(valueName);
                if (v == null) return "";
                if (v is byte[] b) return "(" + b.Length + " bytes)";
                string s = v.ToString() ?? "";
                return s.Length > 120 ? s[..120] + "…" : s;
            }
            catch { return ""; }
        }

        private void Net(int pid, IPAddress? addr, int port, int size, bool send, string proto, DateTime at)
        {
            if (addr == null || pid <= 0) return;
            string ip = Norm(addr);
            lock (_lock) _flowPid[ip + ":" + port] = pid;
            if (!_netAll && !Tracked(pid)) return;
            if (IsLocal(addr) || pid == Environment.ProcessId) return;
            string key = pid + "|" + proto + "|" + ip + "|" + port; bool isNew;
            lock (_lock)
            {
                if (!_net.TryGetValue(key, out var st)) { st = new NetStat { Pid = pid, Proto = proto, Ip = ip, Port = port, Proc = Name(pid) }; _net[key] = st; isNew = true; }
                else isNew = false;
                if (send) st.Sent += size; else st.Recv += size;
            }
            if (isNew) Emit("net", send ? "NET OUT" : "NET IN", $"{Name(pid)}  {(send ? "->" : "<-")} {Endpoint(ip, port)}  {proto}", at);
        }

        private void StartDns()
        {
            try
            {
                var dns = new TraceEventSession("XFlags-DNS") { StopOnDispose = true };
                dns.EnableProvider("Microsoft-Windows-DNS-Client");
                dns.Source.Dynamic.All += e =>
                {
                    try
                    {
                        if ((int)e.ID != 3008) return;
                        string name = e.PayloadByName("QueryName") as string ?? "", res = e.PayloadByName("QueryResults") as string ?? "";
                        if (name.Length == 0 || res.Length == 0) return;
                        foreach (var part in res.Split(';'))
                        {
                            var m = IpRe.Match(part.Trim());
                            if (m.Success && IPAddress.TryParse(m.Groups[1].Value, out var a)) lock (_lock) _dnsMap[Norm(a)] = name;
                        }
                    }
                    catch { }
                };
                _dns = dns;
                Task.Run(() => { try { dns.Source.Process(); } catch { } });
            }
            catch { }
        }

        private void StartSniffer()
        {
            _sniff = true;
            try
            {
                foreach (var ni in NetworkInterface.GetAllNetworkInterfaces())
                {
                    if (ni.OperationalStatus != OperationalStatus.Up) continue;
                    foreach (var ua in ni.GetIPProperties().UnicastAddresses)
                        if (ua.Address.AddressFamily == AddressFamily.InterNetwork && !IPAddress.IsLoopback(ua.Address))
                        {
                            lock (_lock) _localIps.Add(ua.Address.ToString());
                            try
                            {
                                var s = new Socket(AddressFamily.InterNetwork, SocketType.Raw, ProtocolType.IP);
                                s.Bind(new IPEndPoint(ua.Address, 0));
                                s.SetSocketOption(SocketOptionLevel.IP, SocketOptionName.HeaderIncluded, true);
                                s.IOControl(IOControlCode.ReceiveAll, new byte[] { 1, 0, 0, 0 }, new byte[4]);
                                _raw.Add(s);
                                var buf = new byte[65535];
                                Recv(s, buf);
                            }
                            catch { }
                        }
                }
                if (_raw.Count > 0) Emit("info", "SNIFF", $"content parser on ({_raw.Count} iface): SNI + HTTP");
            }
            catch { }
        }

        private void Recv(Socket s, byte[] buf)
        {
            if (!_sniff) return;
            try
            {
                s.BeginReceive(buf, 0, buf.Length, SocketFlags.None, ar =>
                {
                    int len = 0; try { len = s.EndReceive(ar); } catch { }
                    if (len > 0) { try { Packet(buf, len); } catch { } }
                    if (_sniff) Recv(s, buf);
                }, null);
            }
            catch { }
        }

        private void Packet(byte[] b, int len)
        {
            if (len < 20) return;
            int ihl = (b[0] & 0x0F) * 4;
            if ((b[0] >> 4) != 4 || b[9] != 6 || len < ihl + 20) return;
            int total = (b[2] << 8) | b[3]; if (total > len) total = len;
            string src = $"{b[12]}.{b[13]}.{b[14]}.{b[15]}", dst = $"{b[16]}.{b[17]}.{b[18]}.{b[19]}";
            int sp = (b[ihl] << 8) | b[ihl + 1], dp = (b[ihl + 2] << 8) | b[ihl + 3];
            int off = ihl + (b[ihl + 12] >> 4) * 4, pl = total - off;
            if (pl <= 0 || off >= len) return; if (off + pl > len) pl = len - off;
            bool outb; lock (_lock) outb = _localIps.Contains(src);
            string rip = outb ? dst : src; int rport = outb ? dp : sp;
            int pid; lock (_lock) if (!_flowPid.TryGetValue(rip + ":" + rport, out pid)) pid = -1;
            if (pid <= 0 && !_netAll) return;
            if (pid > 0 && !_netAll && !Tracked(pid)) return;
            string who = pid > 0 ? Name(pid) : "?";

            if (outb && b[off] == 0x16 && off + 5 < len && b[off + 5] == 0x01)
            {
                string? sni = Sni(b, off, pl);
                if (sni != null && First("SNI|" + pid + "|" + sni)) { Emit("sni", "TLS SNI", $"{who}  {sni}  ({rip}:{rport})"); lock (_lock) if (!_dnsMap.ContainsKey(rip)) _dnsMap[rip] = sni; }
                return;
            }
            string start = Ascii(b, off, Math.Min(pl, 8));
            if (HttpMethods.Any(m => start.StartsWith(m, StringComparison.Ordinal)))
            {
                string line = Line(b, off, pl), host = Header(b, off, pl, "Host:");
                if (First("HREQ|" + pid + "|" + host + "|" + line)) Emit("http", "HTTP >", $"{who}  {(host.Length > 0 ? host : rip)}  {line}");
            }
            else if (pl >= 12 && b[off] == 'H' && b[off + 1] == 'T' && b[off + 2] == 'T' && b[off + 3] == 'P')
            {
                string line = Line(b, off, pl);
                if (First("HRESP|" + pid + "|" + rip + "|" + line)) Emit("http", "HTTP <", $"{who}  {rip}  {line}");
            }
        }

        private static string? Sni(byte[] b, int p, int len)
        {
            try
            {
                int end = p + len, i = p + 5;
                if (i + 4 > end || b[i] != 0x01) return null;
                int hs = (b[i + 1] << 16) | (b[i + 2] << 8) | b[i + 3]; i += 4; int he = Math.Min(end, i + hs);
                i += 2 + 32; if (i >= he) return null;
                int sid = b[i]; i += 1 + sid; if (i + 2 > he) return null;
                int cs = (b[i] << 8) | b[i + 1]; i += 2 + cs; if (i >= he) return null;
                int cm = b[i]; i += 1 + cm; if (i + 2 > he) return null;
                int ext = (b[i] << 8) | b[i + 1]; i += 2; int ee = Math.Min(he, i + ext);
                while (i + 4 <= ee)
                {
                    int type = (b[i] << 8) | b[i + 1], el = (b[i + 2] << 8) | b[i + 3], eb = i + 4;
                    if (type == 0)
                    {
                        int j = eb + 2; if (j + 3 > ee) return null;
                        int nt = b[j], nl = (b[j + 1] << 8) | b[j + 2]; j += 3;
                        if (nt == 0 && j + nl <= ee && nl is > 0 and < 256) return Encoding.ASCII.GetString(b, j, nl);
                        return null;
                    }
                    i = eb + el;
                }
            }
            catch { }
            return null;
        }

        public void Summary()
        {
            List<NetStat> stats; Dictionary<int, HashSet<string>> writes; Dictionary<string, string> dns;
            lock (_lock) { stats = _net.Values.Select(s => new NetStat { Pid = s.Pid, Proc = s.Proc, Proto = s.Proto, Ip = s.Ip, Port = s.Port, Sent = s.Sent, Recv = s.Recv }).ToList(); writes = _writes.ToDictionary(k => k.Key, v => new HashSet<string>(v.Value)); dns = new(_dnsMap); }
            Emit("info", "SUMMARY", "==================== NETWORK ====================");
            if (stats.Count == 0) Emit("info", "SUMMARY", "no network traffic");
            foreach (var g in stats.GroupBy(s => s.Pid).OrderByDescending(g => g.Sum(x => x.Sent + x.Recv)))
            {
                string proc = g.First().Proc.Length > 0 ? g.First().Proc : Name(g.Key);
                Emit("proc", "SUMMARY", $"{proc}   total ↑ {Sz(g.Sum(x => x.Sent))}  ↓ {Sz(g.Sum(x => x.Recv))}");
                foreach (var s in g.OrderByDescending(x => x.Sent + x.Recv))
                    Emit("net", "SUMMARY", $"    {s.Proto,-4} {Endpoint(s.Ip, s.Port)}   ↑ {Sz(s.Sent)}  ↓ {Sz(s.Recv)}");
            }
            var byApp = DomainsByApp();
            if (byApp.Count > 0) { Emit("info", "SUMMARY", "================ DOMAINS BY APP ================"); foreach (var kv in byApp) { Emit("proc", "SUMMARY", $"{kv.Key}  ({kv.Value.Count})"); foreach (var h in kv.Value) Emit("sni", "SUMMARY", "    " + h); } }
            if (writes.Count > 0) { Emit("info", "SUMMARY", "================ FILES WRITTEN ================"); foreach (var kv in writes) { Emit("proc", "SUMMARY", Name(kv.Key)); foreach (var f in kv.Value.OrderBy(x => x)) { string sz; try { sz = File.Exists(f) ? Sz(new FileInfo(f).Length) : "deleted"; } catch { sz = "?"; } Emit("file", "SUMMARY", $"    {sz,10}  {f}"); } } }
        }

        public SortedDictionary<string, SortedSet<string>> DomainsByApp()
        {
            var res = new SortedDictionary<string, SortedSet<string>>(StringComparer.OrdinalIgnoreCase);
            List<NetStat> stats; Dictionary<string, string> dns;
            lock (_lock) { stats = _net.Values.ToList(); dns = new(_dnsMap); }
            foreach (var s in stats)
            {
                string proc = StripPid(s.Proc.Length > 0 ? s.Proc : Name(s.Pid));
                string host = dns.TryGetValue(s.Ip, out var d) ? d : s.Ip;
                if (!res.TryGetValue(proc, out var set)) res[proc] = set = new SortedSet<string>(StringComparer.OrdinalIgnoreCase);
                set.Add(host);
            }
            return res;
        }

        private void StartUeTail(string? exe, int pid)
        {
            if (string.IsNullOrEmpty(exe) || !First("UELOG|" + exe)) return;
            var token = _cts?.Token ?? CancellationToken.None;
            var dirs = UeDirs(exe);
            if (dirs.Count == 0) { Emit("del", "UE LOG", "no Saved\\Logs near exe / LocalAppData"); return; }
            Emit("info", "UE LOG", $"scanning {dirs.Count} Saved\\Logs for the game log…");
            DateTime since = DateTime.Now.AddSeconds(-5);
            Task.Run(async () =>
            {
                string? cur = null; Encoding enc = Encoding.UTF8; long pos = 0; string partial = ""; DateTime wait = DateTime.Now.AddSeconds(60);
                while (!token.IsCancellationRequested)
                {
                    try
                    {
                        string? newest = null; DateTime best = since;
                        foreach (var d in dirs) if (Directory.Exists(d)) foreach (var f in Directory.GetFiles(d, "*.log")) { var t = File.GetLastWriteTime(f); if (t > best) { best = t; newest = f; } }
                        if (newest != null && newest != cur) { cur = newest; pos = 0; partial = ""; enc = DetectEnc(cur); Emit("info", "UE LOG", "reading " + cur); }
                        if (cur == null && DateTime.Now > wait) { Emit("del", "UE LOG", "no fresh log in 60s — logging off in this build, or -log not passed"); wait = DateTime.MaxValue; }
                        if (cur != null)
                            using (var fs = new FileStream(cur, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
                            {
                                if (fs.Length < pos) pos = 0; fs.Seek(pos, SeekOrigin.Begin);
                                using var sr = new StreamReader(fs, enc, false);
                                string chunk = await sr.ReadToEndAsync(); pos = fs.Position;
                                string text = partial + chunk; int nl = text.LastIndexOf('\n');
                                partial = nl >= 0 ? text[(nl + 1)..] : text;
                                if (nl >= 0) foreach (var line in text[..nl].Split('\n')) ParseUe(line.TrimEnd('\r'));
                            }
                    }
                    catch { }
                    try { await Task.Delay(500, token); } catch { break; }
                }
            });
        }

        private void ParseUe(string line)
        {
            if (line.Length == 0) return;
            foreach (Match m in UePkg.Matches(line))
            {
                string pkg = m.Value.TrimEnd('.', '/', ',');
                int dot = pkg.LastIndexOf('.');
                if (pkg.StartsWith("/") && dot > pkg.LastIndexOf('/')) pkg = pkg[..dot];
                if (pkg.Length < 7 || !First("PKG|" + pkg)) continue;
                var cm = UeCat.Match(line);
                Emit("asset", "UASSET", cm.Success ? $"{pkg}   ({cm.Groups[1].Value})" : pkg);
            }
        }

        private static Encoding DetectEnc(string path)
        {
            try { using var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete); byte[] b = new byte[2]; if (fs.Read(b, 0, 2) == 2 && b[0] == 0xFF && b[1] == 0xFE) return Encoding.Unicode; } catch { }
            return Encoding.UTF8;
        }

        private static List<string> UeDirs(string exe)
        {
            var dirs = new List<string>();
            void Add(string d) { if (!string.IsNullOrEmpty(d) && !dirs.Contains(d, StringComparer.OrdinalIgnoreCase)) dirs.Add(d); }
            try
            {
                var d = Directory.GetParent(exe);
                for (int i = 0; i < 7 && d != null; i++) { string c = Path.Combine(d.FullName, "Saved", "Logs"); if (Directory.Exists(c)) Add(c); d = d.Parent; }
                string bn = Path.GetFileNameWithoutExtension(exe); int dash = bn.IndexOf('-'); string proj = dash > 0 ? bn[..dash] : bn;
                string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                string mg = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Personal), "My Games");
                Add(Path.Combine(local, proj, "Saved", "Logs")); Add(Path.Combine(mg, proj, "Saved", "Logs"));
                foreach (var root in new[] { local, mg }) if (Directory.Exists(root)) try { foreach (var sub in Directory.EnumerateDirectories(root)) { string c = Path.Combine(sub, "Saved", "Logs"); if (Directory.Exists(c)) Add(c); } } catch { }
            }
            catch { }
            return dirs;
        }

        public static bool Block(string exePath)
        {
            string rule = "XFlags block " + Path.GetFileName(exePath);
            return Netsh($"advfirewall firewall add rule name=\"{rule}\" dir=out action=block program=\"{exePath}\" enable=yes")
                 & Netsh($"advfirewall firewall add rule name=\"{rule}\" dir=in action=block program=\"{exePath}\" enable=yes");
        }
        public static bool Unblock(string exeName) => Netsh($"advfirewall firewall delete rule name=\"XFlags block {exeName}\"");
        public string? PathForPid(int pid) { lock (_lock) return _pidPaths.TryGetValue(pid, out var p) && p.Length > 0 ? p : null; }

        private static bool Netsh(string args)
        {
            try { using var p = Process.Start(new ProcessStartInfo("netsh.exe", args) { UseShellExecute = false, CreateNoWindow = true }); if (p == null) return false; p.WaitForExit(10000); return p.ExitCode == 0; } catch { return false; }
        }

        private void Track(int pid, string name, string? note) { bool added; lock (_lock) { added = _pids.Add(pid); _pidNames[pid] = name; } if (added && note != null) Emit("proc", "TRACK", $"[{pid}] {name} ({note})"); }
        private bool Tracked(int pid) { lock (_lock) return _pids.Contains(pid); }
        private void RememberWrite(int pid, string f) { lock (_lock) { if (!_writes.TryGetValue(pid, out var s)) _writes[pid] = s = new(StringComparer.OrdinalIgnoreCase); s.Add(f); } }
        private bool First(string key) { lock (_lock) return _seen.Add(key); }
        private string Name(int pid) { lock (_lock) { if (_pidNames.TryGetValue(pid, out var n)) return $"{n}[{pid}]"; } string nm = pid == 4 ? "System" : "?"; try { if (pid != 4) nm = Process.GetProcessById(pid).ProcessName + ".exe"; } catch { } lock (_lock) _pidNames[pid] = nm; return $"{nm}[{pid}]"; }
        private static string? PathOf(Process p) { try { return p.MainModule?.FileName; } catch { return null; } }

        private bool Matches(string img, string cmd)
        {
            string exe = Path.GetFileName(ExeFromCmd(cmd));
            foreach (var t in _targets) { if (img.Equals(t, StringComparison.OrdinalIgnoreCase)) return true; if (exe.Equals(t, StringComparison.OrdinalIgnoreCase)) return true; if (exe.Length == 0 && img.Length >= 14 && t.StartsWith(img, StringComparison.OrdinalIgnoreCase)) return true; }
            return _autoUe && UeExe.IsMatch(exe);
        }
        private static string ExeFromCmd(string cmd)
        {
            cmd = cmd.Trim(); if (cmd.Length == 0) return "";
            if (cmd[0] == '"') { int e = cmd.IndexOf('"', 1); return e > 1 ? cmd.Substring(1, e - 1) : ""; }
            int x = cmd.IndexOf(".exe", StringComparison.OrdinalIgnoreCase); return x > 0 ? cmd[..(x + 4)] : "";
        }
        private static string NormReg(string k)
        {
            if (k.StartsWith(@"\REGISTRY\MACHINE", StringComparison.OrdinalIgnoreCase)) return "HKLM" + k[17..];
            if (k.StartsWith(@"\REGISTRY\USER", StringComparison.OrdinalIgnoreCase)) return "HKU" + k[14..];
            return k;
        }
        private string Endpoint(string ip, int port) { string? h; lock (_lock) _dnsMap.TryGetValue(ip, out h); string ep = ip.Contains(':') ? $"[{ip}]:{port}" : $"{ip}:{port}"; return h != null ? $"{h} ({ep})" : ep; }
        private static string Norm(IPAddress a) { if (a.IsIPv4MappedToIPv6) a = a.MapToIPv4(); return a.ToString(); }
        private static bool IsLocal(IPAddress a)
        {
            if (a.IsIPv4MappedToIPv6) a = a.MapToIPv4();
            if (IPAddress.IsLoopback(a)) return true;
            if (a.AddressFamily == AddressFamily.InterNetwork) { var b = a.GetAddressBytes(); return b[0] == 10 || (b[0] == 172 && b[1] >= 16 && b[1] <= 31) || (b[0] == 192 && b[1] == 168) || (b[0] == 169 && b[1] == 254) || b[0] >= 224; }
            return a.IsIPv6LinkLocal || a.IsIPv6SiteLocal || a.IsIPv6Multicast;
        }
        private static string StripPid(string n) { int b = n.IndexOf('['); return b > 0 ? n[..b] : n; }
        private static string Sz(long b) => b < 1024 ? b + " B" : b < 1048576 ? (b / 1024.0).ToString("0.0") + " KB" : b < 1073741824 ? (b / 1048576.0).ToString("0.00") + " MB" : (b / 1073741824.0).ToString("0.00") + " GB";
        private static string Ascii(byte[] b, int off, int len) { var sb = new StringBuilder(len); for (int i = 0; i < len && off + i < b.Length; i++) { byte c = b[off + i]; sb.Append(c is >= 32 and < 127 ? (char)c : '.'); } return sb.ToString(); }
        private static string Line(byte[] b, int off, int len) { var sb = new StringBuilder(); for (int i = 0; i < len && i < 512 && off + i < b.Length; i++) { byte c = b[off + i]; if (c == '\r' || c == '\n') break; sb.Append(c is >= 32 and < 127 ? (char)c : '.'); } return sb.ToString(); }
        private static string Header(byte[] b, int off, int len, string name) { string t = Encoding.ASCII.GetString(b, off, Math.Min(len, 2048)); foreach (var l in t.Split('\n')) if (l.StartsWith(name, StringComparison.OrdinalIgnoreCase)) return l[name.Length..].Trim(); return ""; }
    }
}
