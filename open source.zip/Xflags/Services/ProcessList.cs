using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace XFlags.Services
{
    public enum SigStatus { Unknown, NoPath, Signed, Catalog, Unsigned, Untrusted }

    public sealed class ProcRow : INotifyPropertyChanged
    {
        public int Pid { get; set; }
        public int Ppid { get; set; }
        public string Name { get; set; } = "";
        public string Path { get; set; } = "";
        public string Company { get; set; } = "";
        public string Description { get; set; } = "";
        public string User { get; set; } = "";
        public bool Hidden { get; set; }
        public int Depth { get; set; }

        private SigStatus _status = SigStatus.Unknown;
        public SigStatus Status { get => _status; set { _status = value; Raise(nameof(Status)); Raise(nameof(Sig)); } }

        private string _signer = "";
        public string Signer { get => _signer; set { _signer = value; Raise(nameof(Signer)); } }

        private string _flags = "";
        public string Flags { get => _flags; set { _flags = value; Raise(nameof(Flags)); Raise(nameof(Level)); } }

        public string Sig => Status switch
        {
            SigStatus.Signed => "signed",
            SigStatus.Catalog => "catalog",
            SigStatus.Unsigned => "UNSIGNED",
            SigStatus.Untrusted => "UNTRUSTED",
            SigStatus.NoPath => "no path",
            _ => "…"
        };

        public string Level
        {
            get
            {
                if (Flags.Contains("HIDDEN") || Flags.Contains("MASQUERADE") || Status == SigStatus.Untrusted) return "bad";
                if (Flags.Length > 0 || Status == SigStatus.Unsigned) return "warn";
                return "ok";
            }
        }

        public string Display => $"{Pid,6}  {Name}";

        public event PropertyChangedEventHandler? PropertyChanged;
        private void Raise([CallerMemberName] string? n = null) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n!));
    }

    public sealed class ModuleRow
    {
        public string Name = "";
        public string Path = "";
        public string Signer = "";
        public SigStatus Status = SigStatus.Unknown;

        public string Sig => Status switch
        {
            SigStatus.Signed => "signed",
            SigStatus.Catalog => "catalog",
            SigStatus.Unsigned => "UNSIGNED",
            SigStatus.Untrusted => "UNTRUSTED",
            _ => ""
        };
        public string Level => Status is SigStatus.Unsigned or SigStatus.Untrusted ? "warn" : "ok";
    }

    public static class ProcessList
    {

        public static List<ModuleRow> Modules(int pid)
        {
            var res = new List<ModuleRow>();
            try
            {
                using var p = Process.GetProcessById(pid);
                foreach (System.Diagnostics.ProcessModule m in p.Modules)
                {
                    string path = "";
                    try { path = m.FileName ?? ""; } catch { }
                    var row = new ModuleRow { Name = m.ModuleName ?? System.IO.Path.GetFileName(path), Path = path };
                    if (path.Length > 0 && File.Exists(path)) { var (st, signer) = Authenticode.Check(path); row.Status = st; row.Signer = signer; }
                    res.Add(row);
                }
            }
            catch { }

            res.Sort((a, b) =>
            {
                int ra = a.Level == "warn" ? 0 : 1, rb = b.Level == "warn" ? 0 : 1;
                return ra != rb ? ra.CompareTo(rb) : string.Compare(a.Name, b.Name, StringComparison.OrdinalIgnoreCase);
            });
            return res;
        }

        public static List<ProcRow> Enumerate()
        {
            var rows = new List<ProcRow>();
            var seen = new HashSet<int>();

            IntPtr snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
            if (snap != INVALID_HANDLE)
            {
                var pe = new PROCESSENTRY32 { dwSize = (uint)Marshal.SizeOf<PROCESSENTRY32>() };
                if (Process32First(snap, ref pe))
                    do
                    {
                        int pid = (int)pe.th32ProcessID;
                        if (!seen.Add(pid)) continue;
                        var r = new ProcRow { Pid = pid, Ppid = (int)pe.th32ParentProcessID, Name = pe.szExeFile ?? "" };
                        Fill(r);
                        rows.Add(r);
                    } while (Process32Next(snap, ref pe));
                CloseHandle(snap);
            }

            for (uint pid = 8; pid < 0x40000; pid += 4)
            {
                if (seen.Contains((int)pid)) continue;
                IntPtr h = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, false, pid);
                if (h == IntPtr.Zero) continue;
                string path = ImagePath(h);
                CloseHandle(h);
                if (path.Length == 0) continue;
                seen.Add((int)pid);
                var r = new ProcRow { Pid = (int)pid, Name = System.IO.Path.GetFileName(path), Hidden = true };
                Fill(r);
                rows.Add(r);
            }

            return rows;
        }

        private static void Fill(ProcRow r)
        {
            if (r.Pid is 0 or 4) { r.Name = r.Pid == 0 ? "System Idle Process" : "System"; return; }
            IntPtr h = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, false, (uint)r.Pid);
            if (h != IntPtr.Zero)
            {
                r.Path = ImagePath(h);
                r.User = TokenUser(h);
                CloseHandle(h);
            }
            if (r.Path.Length > 0)
            {
                try
                {
                    var fi = FileVersionInfo.GetVersionInfo(r.Path);
                    r.Company = fi.CompanyName?.Trim() ?? "";
                    r.Description = fi.FileDescription?.Trim() ?? "";
                }
                catch { }
                if (r.Name.Length == 0) r.Name = System.IO.Path.GetFileName(r.Path);
            }
        }

        private static readonly string[] SystemNames =
            { "svchost.exe","csrss.exe","lsass.exe","services.exe","winlogon.exe","wininit.exe","smss.exe","explorer.exe","spoolsv.exe","dwm.exe","taskhostw.exe","conhost.exe","lsaiso.exe","fontdrvhost.exe" };

        public static void Verify(ProcRow r)
        {

            if (r.Path.Length == 0)
                r.Status = (r.Pid is 0 or 4) ? SigStatus.Signed : SigStatus.NoPath;
            else
            {
                var (st, signer) = Authenticode.Check(r.Path);
                r.Status = st;
                r.Signer = signer;
            }

            var f = new List<string>();
            if (r.Hidden) f.Add("HIDDEN");

            string win = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
            string sys32 = Environment.GetFolderPath(Environment.SpecialFolder.System);
            string sysWow = Environment.GetFolderPath(Environment.SpecialFolder.SystemX86);
            string p = r.Path;
            bool inSystem = p.Length > 0 && (p.StartsWith(sys32, StringComparison.OrdinalIgnoreCase) || p.StartsWith(sysWow, StringComparison.OrdinalIgnoreCase));

            if (Array.Exists(SystemNames, n => n.Equals(r.Name, StringComparison.OrdinalIgnoreCase)) && r.Path.Length > 0 && !inSystem)
                f.Add("MASQUERADE");

            string tmp = System.IO.Path.GetTempPath().TrimEnd('\\');
            string appdata = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            if (p.Length > 0)
            {
                if (p.StartsWith(tmp, StringComparison.OrdinalIgnoreCase)) f.Add("TEMP");
                else if (p.StartsWith(appdata, StringComparison.OrdinalIgnoreCase) || p.StartsWith(local, StringComparison.OrdinalIgnoreCase)) f.Add("APPDATA");
            }

            if (r.Status == SigStatus.Untrusted) f.Add("BAD-SIG");
            else if (r.Status == SigStatus.Unsigned)
            {
                if (inSystem || (p.Length > 0 && p.StartsWith(win, StringComparison.OrdinalIgnoreCase))) f.Add("UNSIGNED-IN-SYS");
                else f.Add("unsigned");
            }

            bool inProfile = f.Contains("TEMP") || f.Contains("APPDATA");
            if ((r.Status == SigStatus.Unsigned || r.Status == SigStatus.Untrusted || inProfile) && IsDotNet(r.Path)) f.Add("NET");

            r.Flags = string.Join(", ", f);
        }

        public static bool Kill(int pid)
        {
            try { using var p = Process.GetProcessById(pid); p.Kill(); return true; } catch { return false; }
        }

        public static string Sha256(string path)
        {
            try { using var fs = File.OpenRead(path); using var sha = System.Security.Cryptography.SHA256.Create(); return Convert.ToHexString(sha.ComputeHash(fs)).ToLowerInvariant(); }
            catch { return ""; }
        }

        public static bool IsDotNet(string path)
        {
            if (string.IsNullOrEmpty(path)) return false;
            try
            {
                using var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                using var br = new BinaryReader(fs);
                if (fs.Length < 0x40) return false;
                fs.Seek(0x3C, SeekOrigin.Begin);
                int pe = br.ReadInt32();
                if (pe <= 0 || pe + 24 > fs.Length) return false;
                fs.Seek(pe, SeekOrigin.Begin);
                if (br.ReadUInt32() != 0x00004550) return false;
                fs.Seek(pe + 4 + 16, SeekOrigin.Begin);
                ushort magic = br.ReadUInt16();
                int dirOff = pe + 24 + (magic == 0x20b ? 112 : 96);
                fs.Seek(dirOff + 14 * 8, SeekOrigin.Begin);
                uint rva = br.ReadUInt32();
                return rva != 0;
            }
            catch { return false; }
        }

        private static string ImagePath(IntPtr h)
        {
            var sb = new StringBuilder(1024); int cap = sb.Capacity;
            return QueryFullProcessImageName(h, 0, sb, ref cap) ? sb.ToString() : "";
        }

        private static string TokenUser(IntPtr hProc)
        {
            if (!OpenProcessToken(hProc, TOKEN_QUERY, out IntPtr tok)) return "";
            try
            {
                GetTokenInformation(tok, 1 , IntPtr.Zero, 0, out int len);
                if (len == 0) return "";
                IntPtr buf = Marshal.AllocHGlobal(len);
                try
                {
                    if (!GetTokenInformation(tok, 1, buf, len, out _)) return "";
                    IntPtr sid = Marshal.ReadIntPtr(buf);
                    var name = new StringBuilder(256); int cchName = name.Capacity;
                    var dom = new StringBuilder(256); int cchDom = dom.Capacity;
                    if (LookupAccountSid(null, sid, name, ref cchName, dom, ref cchDom, out _))
                        return dom.Length > 0 ? dom + "\\" + name : name.ToString();
                }
                finally { Marshal.FreeHGlobal(buf); }
            }
            finally { CloseHandle(tok); }
            return "";
        }

        private const uint TH32CS_SNAPPROCESS = 2;
        private const uint PROCESS_QUERY_LIMITED_INFORMATION = 0x1000;
        private const uint TOKEN_QUERY = 0x0008;
        private static readonly IntPtr INVALID_HANDLE = new(-1);

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private struct PROCESSENTRY32
        {
            public uint dwSize; public uint cntUsage; public uint th32ProcessID; public IntPtr th32DefaultHeapID;
            public uint th32ModuleID; public uint cntThreads; public uint th32ParentProcessID; public int pcPriClassBase;
            public uint dwFlags; [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)] public string szExeFile;
        }

        [DllImport("kernel32.dll", SetLastError = true)] private static extern IntPtr CreateToolhelp32Snapshot(uint flags, uint pid);
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] private static extern bool Process32First(IntPtr snap, ref PROCESSENTRY32 pe);
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] private static extern bool Process32Next(IntPtr snap, ref PROCESSENTRY32 pe);
        [DllImport("kernel32.dll")] private static extern bool CloseHandle(IntPtr h);
        [DllImport("kernel32.dll", SetLastError = true)] private static extern IntPtr OpenProcess(uint access, bool inherit, uint pid);
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)] private static extern bool QueryFullProcessImageName(IntPtr h, uint flags, StringBuilder buf, ref int size);
        [DllImport("advapi32.dll", SetLastError = true)] private static extern bool OpenProcessToken(IntPtr h, uint access, out IntPtr token);
        [DllImport("advapi32.dll", SetLastError = true)] private static extern bool GetTokenInformation(IntPtr token, int cls, IntPtr info, int len, out int retLen);
        [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)] private static extern bool LookupAccountSid(string? sys, IntPtr sid, StringBuilder name, ref int cchName, StringBuilder dom, ref int cchDom, out int use);
    }

    internal static class Authenticode
    {
        public static (SigStatus, string) Check(string path)
        {
            if (!File.Exists(path)) return (SigStatus.NoPath, "");
            int hr = VerifyEmbedded(path);
            if (hr == 0)
            {
                string signer = SignerName(path);
                return (SigStatus.Signed, signer);
            }
            if ((uint)hr == TRUST_E_NOSIGNATURE || (uint)hr == TRUST_E_PROVIDER_UNKNOWN || (uint)hr == 0x800B0100)
            {

                return InCatalog(path) ? (SigStatus.Catalog, "Windows catalog") : (SigStatus.Unsigned, "");
            }

            return (SigStatus.Untrusted, "");
        }

        private static string SignerName(string path)
        {
            try { using var c = new X509Certificate2(X509Certificate.CreateFromSignedFile(path)); string cn = c.GetNameInfo(X509NameType.SimpleName, false); return cn.Length > 0 ? cn : c.Subject; }
            catch { return ""; }
        }

        private static int VerifyEmbedded(string path)
        {
            var fileInfo = new WINTRUST_FILE_INFO
            {
                cbStruct = (uint)Marshal.SizeOf<WINTRUST_FILE_INFO>(),
                pcwszFilePath = Marshal.StringToCoTaskMemUni(path)
            };
            IntPtr pFile = Marshal.AllocCoTaskMem(Marshal.SizeOf<WINTRUST_FILE_INFO>());
            Marshal.StructureToPtr(fileInfo, pFile, false);

            var wtd = new WINTRUST_DATA
            {
                cbStruct = (uint)Marshal.SizeOf<WINTRUST_DATA>(),
                dwUIChoice = 2,
                fdwRevocationChecks = 0,
                dwUnionChoice = 1,
                pFile = pFile,
                dwStateAction = 1,
                dwProvFlags = 0x00000010 | 0x00000100
            };
            IntPtr pData = Marshal.AllocCoTaskMem(Marshal.SizeOf<WINTRUST_DATA>());
            Marshal.StructureToPtr(wtd, pData, false);
            Guid action = WINTRUST_ACTION_GENERIC_VERIFY_V2;
            int hr;
            try
            {
                hr = WinVerifyTrust(IntPtr.Zero, ref action, pData);
                var close = (WINTRUST_DATA)Marshal.PtrToStructure(pData, typeof(WINTRUST_DATA))!;
                close.dwStateAction = 2;
                Marshal.StructureToPtr(close, pData, true);
                WinVerifyTrust(IntPtr.Zero, ref action, pData);
            }
            finally
            {
                Marshal.FreeCoTaskMem(fileInfo.pcwszFilePath);
                Marshal.FreeCoTaskMem(pFile);
                Marshal.FreeCoTaskMem(pData);
            }
            return hr;
        }

        private static bool InCatalog(string path)
        {
            return CatalogCheck(path, "SHA256") || CatalogCheck(path, null);
        }

        private static bool CatalogCheck(string path, string? algo)
        {
            IntPtr hCatAdmin = IntPtr.Zero, hFile = IntPtr.Zero, hCatInfo = IntPtr.Zero, pHash = IntPtr.Zero;
            try
            {
                if (algo != null)
                {
                    if (!CryptCATAdminAcquireContext2(ref hCatAdmin, IntPtr.Zero, algo, IntPtr.Zero, 0)) return false;
                }
                else
                {
                    Guid drv = DRIVER_ACTION_VERIFY;
                    if (!CryptCATAdminAcquireContext(ref hCatAdmin, ref drv, 0)) return false;
                }

                hFile = CreateFile(path, 0x80000000, 0x1, IntPtr.Zero, 3, 0, IntPtr.Zero);
                if (hFile == INVALID) return false;

                int cb = 0;
                if (algo != null) CryptCATAdminCalcHashFromFileHandle2(hCatAdmin, hFile, ref cb, IntPtr.Zero, 0);
                else CryptCATAdminCalcHashFromFileHandle(hFile, ref cb, IntPtr.Zero, 0);
                if (cb <= 0) return false;

                pHash = Marshal.AllocHGlobal(cb);
                bool ok = algo != null
                    ? CryptCATAdminCalcHashFromFileHandle2(hCatAdmin, hFile, ref cb, pHash, 0)
                    : CryptCATAdminCalcHashFromFileHandle(hFile, ref cb, pHash, 0);
                if (!ok) return false;

                hCatInfo = CryptCATAdminEnumCatalogFromHash(hCatAdmin, pHash, cb, 0, IntPtr.Zero);
                return hCatInfo != IntPtr.Zero;
            }
            catch { return false; }
            finally
            {
                if (hCatInfo != IntPtr.Zero && hCatAdmin != IntPtr.Zero) CryptCATAdminReleaseCatalogContext(hCatAdmin, hCatInfo, 0);
                if (pHash != IntPtr.Zero) Marshal.FreeHGlobal(pHash);
                if (hFile != IntPtr.Zero && hFile != INVALID) CloseHandle(hFile);
                if (hCatAdmin != IntPtr.Zero) CryptCATAdminReleaseContext(hCatAdmin, 0);
            }
        }

        private const uint TRUST_E_NOSIGNATURE = 0x800B0100;
        private const uint TRUST_E_PROVIDER_UNKNOWN = 0x800B0001;
        private static readonly IntPtr INVALID = new(-1);
        private static Guid WINTRUST_ACTION_GENERIC_VERIFY_V2 = new("00AAC56B-CD44-11D0-8CC2-00C04FC295EE");
        private static Guid DRIVER_ACTION_VERIFY = new("F750E6C3-38EE-11D1-85E5-00C04FC295EE");

        [StructLayout(LayoutKind.Sequential)]
        private struct WINTRUST_FILE_INFO { public uint cbStruct; public IntPtr pcwszFilePath; public IntPtr hFile; public IntPtr pgKnownSubject; }

        [StructLayout(LayoutKind.Sequential)]
        private struct WINTRUST_DATA
        {
            public uint cbStruct; public IntPtr pPolicyCallbackData; public IntPtr pSIPClientData;
            public uint dwUIChoice; public uint fdwRevocationChecks; public uint dwUnionChoice; public IntPtr pFile;
            public uint dwStateAction; public IntPtr hWVTStateData; public IntPtr pwszURLReference;
            public uint dwProvFlags; public uint dwUIContext; public IntPtr pSignatureSettings;
        }

        [DllImport("wintrust.dll", SetLastError = true)] private static extern int WinVerifyTrust(IntPtr hwnd, ref Guid action, IntPtr pData);
        [DllImport("wintrust.dll", SetLastError = true)] private static extern bool CryptCATAdminAcquireContext(ref IntPtr hCatAdmin, ref Guid subsystem, uint flags);
        [DllImport("wintrust.dll", SetLastError = true, CharSet = CharSet.Unicode)] private static extern bool CryptCATAdminAcquireContext2(ref IntPtr hCatAdmin, IntPtr subsystem, string hashAlgo, IntPtr strongPolicy, uint flags);
        [DllImport("wintrust.dll", SetLastError = true)] private static extern bool CryptCATAdminCalcHashFromFileHandle(IntPtr hFile, ref int cbHash, IntPtr pbHash, uint flags);
        [DllImport("wintrust.dll", SetLastError = true)] private static extern bool CryptCATAdminCalcHashFromFileHandle2(IntPtr hCatAdmin, IntPtr hFile, ref int cbHash, IntPtr pbHash, uint flags);
        [DllImport("wintrust.dll", SetLastError = true)] private static extern IntPtr CryptCATAdminEnumCatalogFromHash(IntPtr hCatAdmin, IntPtr pbHash, int cbHash, uint flags, IntPtr prevCatInfo);
        [DllImport("wintrust.dll", SetLastError = true)] private static extern bool CryptCATAdminReleaseContext(IntPtr hCatAdmin, uint flags);
        [DllImport("wintrust.dll", SetLastError = true)] private static extern bool CryptCATAdminReleaseCatalogContext(IntPtr hCatAdmin, IntPtr hCatInfo, uint flags);
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)] private static extern IntPtr CreateFile(string name, uint access, uint share, IntPtr sec, uint disp, uint flags, IntPtr template);
        [DllImport("kernel32.dll")] private static extern bool CloseHandle(IntPtr h);
    }
}
