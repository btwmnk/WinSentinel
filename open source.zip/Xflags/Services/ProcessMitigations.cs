using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;

namespace XFlags.Services
{
    public static class ProcessMitigations
    {
        private const uint PROCESS_QUERY_LIMITED_INFORMATION = 0x1000;

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr OpenProcess(uint access, bool inherit, int pid);
        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool CloseHandle(IntPtr h);
        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool GetProcessMitigationPolicy(IntPtr hProcess, int policy, byte[] buffer, IntPtr length);

        private const int DEP = 0, ASLR = 1, DynCode = 2, StrictHandle = 3, CFG = 7, Sig = 8, ImageLoad = 10, Cet = 15;

        public static (bool running, string info) Read(string exeName)
        {
            string name = exeName.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) ? exeName[..^4] : exeName;
            Process[] procs;
            try { procs = Process.GetProcessesByName(name); } catch { procs = Array.Empty<Process>(); }
            if (procs.Length == 0) return (false, "process not running");

            IntPtr h = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, false, procs[0].Id);
            if (h == IntPtr.Zero) return (false, "cannot read process (access denied)");

            var on = new List<string>();
            try
            {
                if (Try(h, DEP, 8, out var dep))
                {
                    bool en = (dep[0] & 1) != 0, perm = dep.Length > 4 && dep[4] != 0;
                    if (en) on.Add(perm ? "DEP (permanent, OS default on 64-bit)" : "DEP");
                }
                if (Try(h, ASLR, 4, out var a))
                {
                    uint f = BitConverter.ToUInt32(a, 0);
                    if ((f & 0x1) != 0) on.Add((f & 0x4) != 0 ? "ASLR (high entropy)" : "ASLR");
                    else if ((f & 0x4) != 0) on.Add("ASLR high-entropy");
                }
                if (Try(h, CFG, 4, out var c)) { uint f = BitConverter.ToUInt32(c, 0); if ((f & 0x1) != 0) on.Add((f & 0x4) != 0 ? "CF Guard (strict)" : "CF Guard"); }
                if (Try(h, Cet, 4, out var e)) { uint f = BitConverter.ToUInt32(e, 0); if ((f & 0x1) != 0) on.Add((f & 0x10) != 0 ? "CET shadow stack (strict)" : "CET shadow stack"); }
                if (Try(h, DynCode, 4, out var d)) { if ((BitConverter.ToUInt32(d, 0) & 0x1) != 0) on.Add("Dynamic code disabled"); }
                if (Try(h, Sig, 4, out var s)) { if ((BitConverter.ToUInt32(s, 0) & 0x1) != 0) on.Add("Signed-only (block non-MS)"); }
                if (Try(h, StrictHandle, 4, out var sh)) { if ((BitConverter.ToUInt32(sh, 0) & 0x1) != 0) on.Add("Strict handle checks"); }
                if (Try(h, ImageLoad, 4, out var il)) { if ((BitConverter.ToUInt32(il, 0) & 0x7) != 0) on.Add("Image-load restrictions"); }
            }
            finally { CloseHandle(h); }

            return (true, on.Count > 0 ? string.Join("   ", on) : "no extra mitigations active (defaults)");
        }

        private static bool Try(IntPtr h, int policy, int size, out byte[] buf)
        {
            buf = new byte[size];
            return GetProcessMitigationPolicy(h, policy, buf, (IntPtr)size);
        }
    }
}
