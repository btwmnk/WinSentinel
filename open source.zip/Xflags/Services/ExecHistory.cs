using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.Win32;

namespace XFlags.Services
{
    public sealed class ExecRow
    {
        public string Name = "";
        public string Path = "";
        public DateTime Last;
        public string Source = "";
        public int Count;
        public string LastStr => Last == default ? "" : Last.ToString("yyyy-MM-dd HH:mm:ss");
        public string CountStr => Count > 0 ? Count.ToString() : "";

        public string PfFile = "";
        public string RegHive = "";
        public string RegSub = "";
        public string RegVal = "";
    }

    public static class ExecHistory
    {
        public static List<ExecRow> Scan()
        {
            var res = new List<ExecRow>();
            Prefetch(res);
            Bam(res);
            UserAssist(res);
            res.Sort((a, b) => b.Last.CompareTo(a.Last));
            return res;
        }

        public static bool Delete(ExecRow r)
        {
            try
            {
                if (r.PfFile.Length > 0)
                {
                    if (File.Exists(r.PfFile)) File.Delete(r.PfFile);
                    return true;
                }
                if (r.RegHive.Length > 0 && r.RegSub.Length > 0)
                {

                    try
                    {
                        var root = r.RegHive == "HKLM" ? Registry.LocalMachine : Registry.CurrentUser;
                        using var k = root.OpenSubKey(r.RegSub, true);
                        if (k != null) { k.DeleteValue(r.RegVal, false); return true; }
                    }
                    catch { }

                    return RegHive.DeleteValueBackup(r.RegHive, r.RegSub, r.RegVal);
                }
            }
            catch { }
            return false;
        }

        private static void Prefetch(List<ExecRow> res)
        {
            try
            {
                string dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "Prefetch");
                if (!Directory.Exists(dir)) return;
                foreach (var f in Directory.GetFiles(dir, "*.pf"))
                {
                    string fn = Path.GetFileName(f);
                    int dash = fn.LastIndexOf('-');
                    string name = dash > 0 ? fn[..dash] : fn;
                    res.Add(new ExecRow { Name = name, Path = f, Last = File.GetLastWriteTime(f), Source = "Prefetch", PfFile = f });
                }
            }
            catch { }
        }

        private static void Bam(List<ExecRow> res)
        {
            foreach (var bamSub in new[]
            {
                @"SYSTEM\CurrentControlSet\Services\bam\State\UserSettings",
                @"SYSTEM\CurrentControlSet\Services\bam\UserSettings"
            })
            {
                try
                {
                    using var root = Registry.LocalMachine.OpenSubKey(bamSub);
                    if (root == null) continue;
                    foreach (var sid in root.GetSubKeyNames())
                    {
                        using var k = root.OpenSubKey(sid);
                        if (k == null) continue;
                        foreach (var val in k.GetValueNames())
                        {
                            if (!val.Contains('\\')) continue;
                            if (k.GetValue(val) is not byte[] data || data.Length < 8) continue;
                            long ft = BitConverter.ToInt64(data, 0);
                            DateTime dt = default;
                            try { if (ft > 0) dt = DateTime.FromFileTime(ft); } catch { }
                            string path = NormDevice(val);
                            res.Add(new ExecRow { Name = Path.GetFileName(path), Path = path, Last = dt, Source = "BAM", RegHive = "HKLM", RegSub = bamSub + "\\" + sid, RegVal = val });
                        }
                    }
                }
                catch { }
            }
        }

        private static void UserAssist(List<ExecRow> res)
        {
            try
            {
                using var ua = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Explorer\UserAssist");
                if (ua == null) return;
                foreach (var guid in ua.GetSubKeyNames())
                {
                    using var count = ua.OpenSubKey(guid + @"\Count");
                    if (count == null) continue;
                    foreach (var val in count.GetValueNames())
                    {
                        string name = Rot13(val);
                        if (name.IndexOf(".exe", StringComparison.OrdinalIgnoreCase) < 0) continue;
                        int runs = 0; DateTime dt = default;
                        if (count.GetValue(val) is byte[] d && d.Length >= 68)
                        {
                            try { runs = BitConverter.ToInt32(d, 4); } catch { }
                            try { long ft = BitConverter.ToInt64(d, 60); if (ft > 0) dt = DateTime.FromFileTime(ft); } catch { }
                        }
                        res.Add(new ExecRow { Name = Path.GetFileName(name), Path = name, Last = dt, Count = runs, Source = "UserAssist", RegHive = "HKCU", RegSub = @"Software\Microsoft\Windows\CurrentVersion\Explorer\UserAssist\" + guid + @"\Count", RegVal = val });
                    }
                }
            }
            catch { }
        }

        private static string NormDevice(string p)
        {

            const string pfx = @"\Device\HarddiskVolume";
            if (p.StartsWith(pfx, StringComparison.OrdinalIgnoreCase))
            {
                int slash = p.IndexOf('\\', pfx.Length);
                if (slash > 0)
                {
                    string sysRoot = Path.GetPathRoot(Environment.GetFolderPath(Environment.SpecialFolder.Windows)) ?? "C:\\";
                    return sysRoot.TrimEnd('\\') + p[slash..];
                }
            }
            return p;
        }

        private static string Rot13(string s)
        {
            var a = s.ToCharArray();
            for (int i = 0; i < a.Length; i++)
            {
                char c = a[i];
                if (c is >= 'a' and <= 'z') a[i] = (char)('a' + (c - 'a' + 13) % 26);
                else if (c is >= 'A' and <= 'Z') a[i] = (char)('A' + (c - 'A' + 13) % 26);
            }
            return new string(a);
        }
    }
}
