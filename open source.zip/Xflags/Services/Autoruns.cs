using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Principal;
using Microsoft.Win32;

namespace XFlags.Services
{
    public enum AutorunKind { RegValue, StartupFile, Other }
    public enum ToggleKind { None, Approved, Service, Task, AutorunsDisabled }

    public sealed class AutorunRow : System.ComponentModel.INotifyPropertyChanged
    {
        public string Category = "";
        public string Name = "";
        public string Command = "";
        public string Path = "";
        public string Signer = "";
        public string Description = "";
        public string Timestamp = "";
        public string Flags = "";
        public SigStatus Status = SigStatus.Unknown;
        public bool Enabled = true;

        public AutorunKind Kind = AutorunKind.Other;
        public RegistryKey? Root;
        public string SubKey = "";
        public string ValueName = "";
        public string FilePath = "";

        public ToggleKind Toggle = ToggleKind.None;
        public RegistryKey? ApprovedRoot;
        public string ApprovedSub = "";
        public int ServiceStart = 2;

        private Microsoft.UI.Xaml.Media.ImageSource? _icon;
        public Microsoft.UI.Xaml.Media.ImageSource? Icon
        {
            get => _icon;
            set { _icon = value; PropertyChanged?.Invoke(this, new System.ComponentModel.PropertyChangedEventArgs(nameof(Icon))); }
        }

        public event System.ComponentModel.PropertyChangedEventHandler? PropertyChanged;
        public void Refresh()
        {
            foreach (var n in new[] { nameof(State), nameof(Level), nameof(Flags), nameof(Sig), nameof(Publisher), nameof(Verdict) })
                PropertyChanged?.Invoke(this, new System.ComponentModel.PropertyChangedEventArgs(n));
        }

        public string Sig => Status switch
        {
            SigStatus.Signed => "signed",
            SigStatus.Catalog => "catalog",
            SigStatus.Unsigned => "UNSIGNED",
            SigStatus.Untrusted => "UNTRUSTED",
            SigStatus.NoPath => "no file",
            _ => ""
        };

        public string Publisher => Status switch
        {
            SigStatus.Signed or SigStatus.Catalog => "(Verified) " + (Signer.Length > 0 ? Signer : "—"),
            SigStatus.Unsigned => "(Not verified)",
            SigStatus.Untrusted => "(BAD signature)",
            SigStatus.NoPath => "file not found",
            _ => ""
        };

        public string State => Enabled ? "on" : "OFF";
        public bool Trusted => Status == SigStatus.Signed || Status == SigStatus.Catalog;

        public string Level
        {
            get
            {
                if (!Enabled) return "off";
                bool hijack = Flags.Contains("HIJACK");
                bool sharp = Flags.Contains("MASQUERADE") || Flags.Contains("SUSPICIOUS-CMD") || Flags.Contains("HIDDEN-FILE");
                if (Status == SigStatus.Untrusted) return "bad";
                if (Flags.Contains("HIDDEN-FILE")) return "bad";
                if ((Status == SigStatus.Unsigned || Status == SigStatus.NoPath) && (hijack || sharp)) return "bad";
                if (Status == SigStatus.Unsigned || Status == SigStatus.NoPath) return "warn";
                return "ok";
            }
        }

        public string Verdict => Level switch { "off" => "disabled", "bad" => "RISKY", "warn" => "review", _ => "ok" };

        public string Group => GroupOf(Category);

        public static string GroupOf(string cat)
        {
            if (cat.Contains("Run") || cat.Contains("Active Setup") || cat.Contains("Startup") || cat.Contains("Logon") || cat.Contains("Windows\\")) return "Logon";
            if (cat.Contains("Winlogon")) return "Winlogon";
            if (cat.Contains("ContextMenu") || cat.Contains("DragDrop") || cat.Contains("ShellServiceObject") || cat.Contains("SharedTaskScheduler") || cat.Contains("Explorer")) return "Explorer";
            if (cat == "BHO") return "Internet Explorer";
            if (cat == "Scheduled Task") return "Scheduled Tasks";
            if (cat == "Service") return "Services";
            if (cat == "Driver") return "Drivers";
            if (cat == "Codecs") return "Codecs";
            if (cat == "BootExecute") return "Boot Execute";
            if (cat == "IFEO Debugger" || cat == "SilentProcessExit") return "Image Hijacks";
            if (cat == "AppInit_DLLs" || cat == "AppCertDlls") return "AppInit";
            if (cat == "KnownDLLs") return "Known DLLs";
            if (cat.StartsWith("LSA ")) return "LSA Providers";
            if (cat == "Network Provider") return "Network Providers";
            if (cat == "Print Monitor") return "Print Monitors";
            if (cat == "Font Drivers") return "Font Drivers";
            return "Other";
        }
    }

    public static class Autoruns
    {

        public static readonly string[] GroupOrder =
            { "Logon","Explorer","Internet Explorer","Scheduled Tasks","Services","Drivers","Codecs","Boot Execute","Image Hijacks","AppInit","Known DLLs","Winlogon","LSA Providers","Network Providers","Print Monitors","Font Drivers","Other" };

        private static readonly string[] LolBins =
            { "powershell.exe","pwsh.exe","wscript.exe","cscript.exe","mshta.exe","rundll32.exe","regsvr32.exe","cmd.exe","certutil.exe","bitsadmin.exe","curl.exe","msbuild.exe","installutil.exe","conhost.exe" };

        private static byte[] ApprovedEnabledBytes => new byte[12] { 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        private static byte[] ApprovedDisabledBytes() { var b = new byte[12]; b[0] = 3; BitConverter.GetBytes(DateTime.Now.ToFileTime()).CopyTo(b, 4); return b; }

        private static RegistryKey _hkcu = Registry.CurrentUser;

        public static List<(string name, string sid)> Users()
        {
            var res = new List<(string, string)>();
            string cur = "";
            try { cur = WindowsIdentity.GetCurrent().User?.Value ?? ""; } catch { }
            try
            {
                foreach (var sid in Registry.Users.GetSubKeyNames())
                {
                    if (sid.EndsWith("_Classes", StringComparison.OrdinalIgnoreCase)) continue;
                    if (!sid.StartsWith("S-1-5-21") && sid != "S-1-5-18" && sid != "S-1-5-19" && sid != "S-1-5-20") continue;
                    string name = sid switch { "S-1-5-18" => "SYSTEM", "S-1-5-19" => "LOCAL SERVICE", "S-1-5-20" => "NETWORK SERVICE", _ => ProfileName(sid) ?? sid };
                    if (sid == cur) name += "  (current)";
                    res.Add((name, sid));
                }
            }
            catch { }

            res.Sort((a, b) => (a.Item2 == cur ? 0 : 1).CompareTo(b.Item2 == cur ? 0 : 1));
            if (res.Count == 0) res.Add(("current user", cur));
            return res;
        }

        private static string InteractiveUserSid()
        {

            try
            {
                foreach (var sid in Registry.Users.GetSubKeyNames())
                {
                    if (!sid.StartsWith("S-1-5-21") || sid.EndsWith("_Classes", StringComparison.OrdinalIgnoreCase)) continue;
                    foreach (var rk in new[] { @"\SOFTWARE\Microsoft\Windows\CurrentVersion\Run", @"\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce" })
                        try { using var k = Registry.Users.OpenSubKey(sid + rk); if (k != null && k.GetValueNames().Length > 0) return sid; } catch { }
                }
            }
            catch { }

            foreach (var p in Process.GetProcessesByName("explorer"))
            {
                IntPtr hp = IntPtr.Zero, tok = IntPtr.Zero;
                try
                {
                    hp = OpenProcess(0x1000 , false, (uint)p.Id);
                    if (hp != IntPtr.Zero && OpenProcessToken(hp, 0x0008 , out tok))
                    {
                        using var wi = new WindowsIdentity(tok);
                        string s = wi.User?.Value ?? "";
                        if (s.Length > 0) return s;
                    }
                }
                catch { }
                finally { if (tok != IntPtr.Zero) CloseHandle(tok); if (hp != IntPtr.Zero) CloseHandle(hp); try { p.Dispose(); } catch { } }
            }
            return "";
        }

        [DllImport("kernel32.dll", SetLastError = true)] private static extern IntPtr OpenProcess(uint access, bool inherit, uint pid);
        [DllImport("advapi32.dll", SetLastError = true)] private static extern bool OpenProcessToken(IntPtr h, uint access, out IntPtr token);
        [DllImport("kernel32.dll")] private static extern bool CloseHandle(IntPtr h);

        private static string? ProfileName(string sid)
        {
            try { using var k = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList\" + sid); string p = k?.GetValue("ProfileImagePath")?.ToString() ?? ""; return p.Length > 0 ? System.IO.Path.GetFileName(p) : null; }
            catch { return null; }
        }

        public static List<AutorunRow> Scan(string? sid = null)
        {
            string cur = "";
            try { cur = WindowsIdentity.GetCurrent().User?.Value ?? ""; } catch { }
            _hkcu = Registry.CurrentUser;

            if (string.IsNullOrEmpty(sid) || sid == cur)
            {
                string inter = InteractiveUserSid();
                if (!string.IsNullOrEmpty(inter)) sid = inter;
            }

            if (!string.IsNullOrEmpty(sid) && sid != cur)
            {
                try { var h = Registry.Users.OpenSubKey(sid, true) ?? Registry.Users.OpenSubKey(sid); if (h != null) _hkcu = h; } catch { }
            }

            var rows = new List<AutorunRow>();
            RunKeys(rows);
            RunOnceEx(rows);
            RunServices(rows);
            ExplorerRun(rows);
            Winlogon(rows);
            WinlogonNotify(rows);
            WindowsLoadRun(rows);
            LogonScript(rows);
            ActiveSetup(rows);
            AppInit(rows);
            AppCertDlls(rows);
            SessionManager(rows);
            KnownDlls(rows);
            Ifeo(rows);
            SilentProcessExit(rows);
            ShellEx(rows);
            Bho(rows);
            LsaPackages(rows);
            NetworkProviders(rows);
            PrintMonitors(rows);
            FontDrivers(rows);
            Codecs(rows);
            StartupFolders(rows);
            ScheduledTasks(rows);
            ServicesAndDrivers(rows);
            foreach (var r in rows) Classify(r);
            return rows;
        }

        private static void RunKeys(List<AutorunRow> rows)
        {
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            AddRunValues(rows, seen, Registry.LocalMachine, @"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", "HKLM Run", false, true);
            AddRunValues(rows, seen, Registry.LocalMachine, @"SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce", "HKLM RunOnce", false, false);
            AddRunValues(rows, seen, Registry.LocalMachine, @"SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Run", "HKLM Run (32)", true, true);
            AddRunValues(rows, seen, Registry.LocalMachine, @"SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\RunOnce", "HKLM RunOnce (32)", true, false);
            AddRunValues(rows, seen, Registry.LocalMachine, @"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer\Run", "HKLM Policies Run", false, false);

            AddRunValues(rows, seen, Registry.CurrentUser, @"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", "HKCU Run", false, true);
            AddRunValues(rows, seen, Registry.CurrentUser, @"SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce", "HKCU RunOnce", false, false);
            AddRunValues(rows, seen, Registry.CurrentUser, @"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer\Run", "HKCU Policies Run", false, false);

            AddAutorunsDisabled(rows, Registry.LocalMachine, @"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", "HKLM Run");
            AddAutorunsDisabled(rows, Registry.LocalMachine, @"SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Run", "HKLM Run (32)");
            AddAutorunsDisabled(rows, Registry.CurrentUser, @"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", "HKCU Run");
            AddAutorunsDisabled(rows, Registry.CurrentUser, @"SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce", "HKCU RunOnce");

            foreach (var (sub, label) in new[]
            {
                (@"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", "HKCU Run"),
                (@"SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce", "HKCU RunOnce"),
                (@"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer\Run", "HKCU Policies Run"),
            })
            {
                foreach (var (sid, name, value) in RegHive.ReadUserValues(sub))
                {
                    if (!seen.Add(label + "|" + name + "|" + value)) continue;
                    rows.Add(new AutorunRow { Category = label, Name = name, Command = value, Kind = AutorunKind.Other });
                }
            }
        }

        public static int LastHiveCount;

        private static List<RegistryKey> UserHives()
        {
            var list = new List<RegistryKey> { Registry.CurrentUser };
            try
            {
                foreach (var sid in Registry.Users.GetSubKeyNames())
                {
                    if (!sid.StartsWith("S-1-5-21") || sid.EndsWith("_Classes", StringComparison.OrdinalIgnoreCase)) continue;
                    try { var h = Registry.Users.OpenSubKey(sid, true) ?? Registry.Users.OpenSubKey(sid); if (h != null) list.Add(h); } catch { }
                }
            }
            catch { }
            LastHiveCount = list.Count;
            return list;
        }

        private static void AddAutorunsDisabled(List<AutorunRow> rows, RegistryKey root, string sub, string label)
        {
            try
            {
                using var k = root.OpenSubKey(sub + @"\AutorunsDisabled");
                if (k == null) return;
                foreach (var name in k.GetValueNames())
                {
                    string cmd = k.GetValue(name)?.ToString() ?? "";
                    if (name.Length == 0 || cmd.Length == 0) continue;
                    rows.Add(new AutorunRow
                    {
                        Category = label, Name = name, Command = cmd, Kind = AutorunKind.Other,
                        Root = root, SubKey = sub, ValueName = name,
                        Toggle = ToggleKind.AutorunsDisabled, Enabled = false
                    });
                }
            }
            catch { }
        }

        private static void AddRunValues(List<AutorunRow> rows, HashSet<string> seen, RegistryKey root, string sub, string label, bool wow, bool approvable)
        {
            try
            {
                using var k = root.OpenSubKey(sub);
                if (k == null) return;
                foreach (var name in k.GetValueNames())
                {
                    string cmd = k.GetValue(name)?.ToString() ?? "";
                    if (cmd.Length == 0) continue;
                    if (!seen.Add(label + "|" + name + "|" + cmd)) continue;
                    var r = new AutorunRow
                    {
                        Category = label, Name = name, Command = cmd, Kind = AutorunKind.RegValue,
                        Root = root, SubKey = sub, ValueName = name
                    };
                    if (approvable)
                    {
                        r.Toggle = ToggleKind.Approved; r.ApprovedRoot = root;
                        r.ApprovedSub = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\" + (wow ? "Run32" : "Run");
                        r.Enabled = ApprovedEnabled(root, r.ApprovedSub, name);
                    }
                    rows.Add(r);
                }
            }
            catch { }
        }

        private static void RunOnceEx(List<AutorunRow> rows)
        {
            EnumValues(rows, Registry.LocalMachine, @"SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnceEx", "HKLM RunOnceEx");
            EnumValues(rows, _hkcu, @"SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnceEx", "HKCU RunOnceEx");
        }

        private static void RunServices(List<AutorunRow> rows)
        {
            foreach (var sub in new[] { @"SOFTWARE\Microsoft\Windows\CurrentVersion\RunServices", @"SOFTWARE\Microsoft\Windows\CurrentVersion\RunServicesOnce" })
            {
                EnumValues(rows, Registry.LocalMachine, sub, "HKLM " + System.IO.Path.GetFileName(sub));
                EnumValues(rows, _hkcu, sub, "HKCU " + System.IO.Path.GetFileName(sub));
            }
        }

        private static void ExplorerRun(List<AutorunRow> rows)
            => EnumValues(rows, _hkcu, @"Software\Microsoft\Windows\CurrentVersion\Explorer\Run", "HKCU Explorer\\Run");

        private static void Winlogon(List<AutorunRow> rows)
        {
            const string sub = @"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon";
            foreach (var (root, cat) in new[] { (Registry.LocalMachine, "HKLM Winlogon"), (_hkcu, "HKCU Winlogon") })
                try
                {
                    using var k = root.OpenSubKey(sub);
                    if (k == null) continue;
                    foreach (var vn in new[] { "Shell", "Userinit", "Taskman", "GinaDLL", "AppSetup" })
                    {
                        string v = k.GetValue(vn)?.ToString() ?? "";
                        if (v.Trim().Length > 0) rows.Add(new AutorunRow { Category = cat, Name = vn, Command = v, Kind = AutorunKind.Other, Root = root, SubKey = sub, ValueName = vn });
                    }
                }
                catch { }
        }

        private static void WinlogonNotify(List<AutorunRow> rows)
        {
            const string sub = @"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\Notify";
            try
            {
                using var root = Registry.LocalMachine.OpenSubKey(sub);
                if (root == null) return;
                foreach (var name in root.GetSubKeyNames())
                    try { using var k = root.OpenSubKey(name); string dll = k?.GetValue("DllName")?.ToString() ?? ""; if (dll.Length > 0) rows.Add(new AutorunRow { Category = "Winlogon Notify", Name = name, Command = dll, Path = dll, Kind = AutorunKind.Other }); }
                    catch { }
            }
            catch { }
        }

        private static void WindowsLoadRun(List<AutorunRow> rows)
        {
            const string sub = @"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Windows";
            try
            {
                using var k = _hkcu.OpenSubKey(sub);
                if (k == null) return;
                foreach (var vn in new[] { "load", "run" })
                {
                    string v = k.GetValue(vn)?.ToString() ?? "";
                    if (v.Trim().Length > 0) rows.Add(new AutorunRow { Category = "HKCU Windows\\" + vn, Name = vn, Command = v, Kind = AutorunKind.RegValue, Root = _hkcu, SubKey = sub, ValueName = vn });
                }
            }
            catch { }
        }

        private static void LogonScript(List<AutorunRow> rows)
        {
            try
            {
                using var k = _hkcu.OpenSubKey(@"Environment");
                string v = k?.GetValue("UserInitMprLogonScript")?.ToString() ?? "";
                if (v.Trim().Length > 0) rows.Add(new AutorunRow { Category = "Logon Script", Name = "UserInitMprLogonScript", Command = v, Kind = AutorunKind.RegValue, Root = _hkcu, SubKey = @"Environment", ValueName = "UserInitMprLogonScript" });
            }
            catch { }
        }

        private static void ActiveSetup(List<AutorunRow> rows)
        {
            foreach (var sub in new[] { @"SOFTWARE\Microsoft\Active Setup\Installed Components", @"SOFTWARE\Wow6432Node\Microsoft\Active Setup\Installed Components" })
                try
                {
                    using var root = Registry.LocalMachine.OpenSubKey(sub);
                    if (root == null) continue;
                    foreach (var name in root.GetSubKeyNames())
                        try { using var k = root.OpenSubKey(name); string sp = k?.GetValue("StubPath")?.ToString() ?? ""; if (sp.Trim().Length > 0) rows.Add(new AutorunRow { Category = "Active Setup", Name = k?.GetValue("")?.ToString() is { Length: > 0 } d ? d : name, Command = sp, Kind = AutorunKind.Other }); }
                        catch { }
                }
                catch { }
        }

        private static void AppInit(List<AutorunRow> rows)
        {
            foreach (var sub in new[] { @"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Windows", @"SOFTWARE\Wow6432Node\Microsoft\Windows NT\CurrentVersion\Windows" })
                try
                {
                    using var k = Registry.LocalMachine.OpenSubKey(sub);
                    string dlls = k?.GetValue("AppInit_DLLs")?.ToString() ?? "";
                    if (dlls.Trim().Length > 0) rows.Add(new AutorunRow { Category = "AppInit_DLLs", Name = "AppInit_DLLs", Command = dlls, Path = dlls, Kind = AutorunKind.Other });
                }
                catch { }
        }

        private static void AppCertDlls(List<AutorunRow> rows)
            => EnumValues(rows, Registry.LocalMachine, @"SYSTEM\CurrentControlSet\Control\Session Manager\AppCertDlls", "AppCertDlls");

        private static void SessionManager(List<AutorunRow> rows)
        {
            try
            {
                using var k = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\Session Manager");
                if (k?.GetValue("BootExecute") is string[] be)
                    foreach (var s in be) if (s.Trim().Length > 0 && !s.Equals("autocheck autochk *", StringComparison.OrdinalIgnoreCase)) rows.Add(new AutorunRow { Category = "BootExecute", Name = s, Command = s, Kind = AutorunKind.Other });
            }
            catch { }
        }

        private static void KnownDlls(List<AutorunRow> rows)
        {
            try
            {
                using var k = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\Session Manager\KnownDLLs");
                if (k == null) return;
                string sys = Environment.GetFolderPath(Environment.SpecialFolder.System);
                foreach (var name in k.GetValueNames())
                {
                    if (name.StartsWith("DllDirectory", StringComparison.OrdinalIgnoreCase)) continue;
                    string dll = k.GetValue(name)?.ToString() ?? "";
                    if (dll.Length == 0) continue;
                    rows.Add(new AutorunRow { Category = "KnownDLLs", Name = name, Command = dll, Path = System.IO.Path.Combine(sys, dll), Kind = AutorunKind.Other });
                }
            }
            catch { }
        }

        private static void Ifeo(List<AutorunRow> rows)
        {
            try
            {
                using var root = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options");
                if (root == null) return;
                foreach (var name in root.GetSubKeyNames())
                    try { using var k = root.OpenSubKey(name); string dbg = k?.GetValue("Debugger")?.ToString() ?? ""; if (dbg.Trim().Length > 0) rows.Add(new AutorunRow { Category = "IFEO Debugger", Name = name, Command = dbg, Kind = AutorunKind.Other }); }
                    catch { }
            }
            catch { }
        }

        private static void SilentProcessExit(List<AutorunRow> rows)
        {
            try
            {
                using var root = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion\SilentProcessExit");
                if (root == null) return;
                foreach (var name in root.GetSubKeyNames())
                    try { using var k = root.OpenSubKey(name); string mon = k?.GetValue("MonitorProcess")?.ToString() ?? ""; if (mon.Trim().Length > 0) rows.Add(new AutorunRow { Category = "SilentProcessExit", Name = name, Command = mon, Kind = AutorunKind.Other }); }
                    catch { }
            }
            catch { }
        }

        private static void ShellEx(List<AutorunRow> rows)
        {
            (string sub, string cat)[] roots =
            {
                (@"*\ShellEx\ContextMenuHandlers", "ContextMenuHandlers *"),
                (@"AllFilesystemObjects\ShellEx\ContextMenuHandlers", "ContextMenuHandlers files"),
                (@"Directory\ShellEx\ContextMenuHandlers", "ContextMenuHandlers dir"),
                (@"Directory\Background\ShellEx\ContextMenuHandlers", "ContextMenuHandlers bg"),
                (@"Directory\ShellEx\DragDropHandlers", "DragDropHandlers"),
                (@"Folder\ShellEx\ContextMenuHandlers", "ContextMenuHandlers folder"),
                (@"Drive\ShellEx\ContextMenuHandlers", "ContextMenuHandlers drive"),
                (@"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\ShellServiceObjectDelayLoad", "ShellServiceObjectDelayLoad"),
                (@"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\SharedTaskScheduler", "SharedTaskScheduler"),
            };
            foreach (var (sub, cat) in roots)
            {
                bool underClasses = !sub.StartsWith("SOFTWARE", StringComparison.OrdinalIgnoreCase);
                string full = underClasses ? @"SOFTWARE\Classes\" + sub : sub;
                try
                {
                    using var root = Registry.LocalMachine.OpenSubKey(full);
                    if (root == null) continue;
                    if (cat.StartsWith("Shell") || cat.StartsWith("Shared"))
                    {
                        foreach (var name in root.GetValueNames())
                        {
                            string clsid = root.GetValue(name)?.ToString() ?? "";
                            if (clsid.Length == 0) continue;
                            string dll = ClsidToPath(clsid);
                            rows.Add(new AutorunRow { Category = cat, Name = name, Command = dll.Length > 0 ? dll : clsid, Path = dll, Kind = AutorunKind.Other });
                        }
                    }
                    else
                    {
                        foreach (var name in root.GetSubKeyNames())
                        {
                            using var k = root.OpenSubKey(name);
                            string clsid = k?.GetValue("")?.ToString() ?? "";
                            string dll = clsid.StartsWith("{") ? ClsidToPath(clsid) : "";
                            rows.Add(new AutorunRow { Category = cat, Name = name, Command = dll.Length > 0 ? dll : (clsid.Length > 0 ? clsid : name), Path = dll, Kind = AutorunKind.Other });
                        }
                    }
                }
                catch { }
            }
        }

        private static void Bho(List<AutorunRow> rows)
        {
            foreach (var sub in new[] {
                @"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Browser Helper Objects",
                @"SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\Browser Helper Objects" })
                try
                {
                    using var root = Registry.LocalMachine.OpenSubKey(sub);
                    if (root == null) continue;
                    foreach (var clsid in root.GetSubKeyNames())
                    {
                        string dll = ClsidToPath(clsid);
                        rows.Add(new AutorunRow { Category = "BHO", Name = clsid, Command = dll.Length > 0 ? dll : clsid, Path = dll, Kind = AutorunKind.Other });
                    }
                }
                catch { }
        }

        private static void LsaPackages(List<AutorunRow> rows)
        {
            try
            {
                using var k = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\Lsa");
                if (k == null) return;
                string sys = Environment.GetFolderPath(Environment.SpecialFolder.System);
                foreach (var vn in new[] { "Authentication Packages", "Security Packages", "Notification Packages" })
                    if (k.GetValue(vn) is string[] arr)
                        foreach (var s in arr) if (s.Trim().Length > 0 && s != "\"\"") rows.Add(new AutorunRow { Category = "LSA " + vn, Name = s, Command = s, Path = System.IO.Path.Combine(sys, s.EndsWith(".dll", StringComparison.OrdinalIgnoreCase) ? s : s + ".dll"), Kind = AutorunKind.Other });
            }
            catch { }
        }

        private static void NetworkProviders(List<AutorunRow> rows)
        {
            try
            {
                using var ord = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\NetworkProvider\Order");
                string order = ord?.GetValue("ProviderOrder")?.ToString() ?? "";
                foreach (var name in order.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
                    try
                    {
                        using var k = Registry.LocalMachine.OpenSubKey($@"SYSTEM\CurrentControlSet\Services\{name}\NetworkProvider");
                        string dll = k?.GetValue("ProviderPath")?.ToString() ?? "";
                        rows.Add(new AutorunRow { Category = "Network Provider", Name = name, Command = dll, Path = Environment.ExpandEnvironmentVariables(dll), Kind = AutorunKind.Other });
                    }
                    catch { }
            }
            catch { }
        }

        private static void PrintMonitors(List<AutorunRow> rows)
        {
            try
            {
                using var root = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\Print\Monitors");
                if (root == null) return;
                foreach (var name in root.GetSubKeyNames())
                    try { using var k = root.OpenSubKey(name); string dll = k?.GetValue("Driver")?.ToString() ?? ""; if (dll.Trim().Length > 0) rows.Add(new AutorunRow { Category = "Print Monitor", Name = name, Command = dll, Path = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), dll), Kind = AutorunKind.Other }); }
                    catch { }
            }
            catch { }
        }

        private static void FontDrivers(List<AutorunRow> rows)
        {
            try
            {
                using var k = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Font Drivers");
                if (k == null) return;
                foreach (var name in k.GetValueNames())
                {
                    string dll = k.GetValue(name)?.ToString() ?? "";
                    if (dll.Trim().Length == 0) continue;
                    rows.Add(new AutorunRow { Category = "Font Drivers", Name = name, Command = dll, Path = Environment.ExpandEnvironmentVariables(dll), Kind = AutorunKind.Other });
                }
            }
            catch { }
        }

        private static void Codecs(List<AutorunRow> rows)
        {
            string sys = Environment.GetFolderPath(Environment.SpecialFolder.System);
            foreach (var sub in new[] { @"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Drivers32", @"SOFTWARE\Wow6432Node\Microsoft\Windows NT\CurrentVersion\Drivers32" })
                try
                {
                    using var k = Registry.LocalMachine.OpenSubKey(sub);
                    if (k == null) continue;
                    foreach (var name in k.GetValueNames())
                    {
                        string dll = k.GetValue(name)?.ToString() ?? "";
                        if (dll.Trim().Length == 0) continue;
                        string p = dll.Contains('\\') ? Environment.ExpandEnvironmentVariables(dll) : System.IO.Path.Combine(sys, dll);
                        rows.Add(new AutorunRow { Category = "Codecs", Name = name, Command = dll, Path = p, Kind = AutorunKind.Other });
                    }
                }
                catch { }
        }

        private static void StartupFolders(List<AutorunRow> rows)
        {
            var user = Environment.GetFolderPath(Environment.SpecialFolder.Startup);
            var common = Environment.GetFolderPath(Environment.SpecialFolder.CommonStartup);
            foreach (var (dir, cat, approvedRoot) in new[] { (user, "Startup (user)", _hkcu), (common, "Startup (all users)", Registry.LocalMachine) })
            {
                try
                {
                    if (!Directory.Exists(dir)) continue;
                    foreach (var f in Directory.GetFiles(dir))
                    {
                        if (f.EndsWith("desktop.ini", StringComparison.OrdinalIgnoreCase)) continue;
                        string target = f.EndsWith(".lnk", StringComparison.OrdinalIgnoreCase) ? (ResolveLnk(f) ?? f) : f;
                        string vn = System.IO.Path.GetFileName(f);
                        string appSub = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\StartupFolder";
                        rows.Add(new AutorunRow { Category = cat, Name = vn, Command = target, Path = target, Kind = AutorunKind.StartupFile, FilePath = f, Toggle = ToggleKind.Approved, ApprovedRoot = approvedRoot, ApprovedSub = appSub, ValueName = vn, Enabled = ApprovedEnabled(approvedRoot, appSub, vn) });
                    }
                }
                catch { }
            }
        }

        private static void ScheduledTasks(List<AutorunRow> rows)
        {
            try
            {
                var psi = new ProcessStartInfo("schtasks.exe", "/query /fo CSV /v") { RedirectStandardOutput = true, UseShellExecute = false, CreateNoWindow = true, StandardOutputEncoding = System.Text.Encoding.UTF8 };
                using var p = Process.Start(psi);
                if (p == null) return;
                string outp = p.StandardOutput.ReadToEnd();
                p.WaitForExit(8000);
                var lines = outp.Split('\n');
                if (lines.Length < 2) return;
                var header = SplitCsv(lines[0]);
                int iName = Array.FindIndex(header, h => h.Equals("TaskName", StringComparison.OrdinalIgnoreCase));
                int iRun = Array.FindIndex(header, h => h.Equals("Task To Run", StringComparison.OrdinalIgnoreCase));
                int iStatus = Array.FindIndex(header, h => h.Equals("Status", StringComparison.OrdinalIgnoreCase) || h.Equals("Scheduled Task State", StringComparison.OrdinalIgnoreCase));
                if (iName < 0 || iRun < 0) return;
                var done = new HashSet<string>();
                foreach (var ln in lines.Skip(1))
                {
                    if (ln.Trim().Length == 0) continue;
                    var c = SplitCsv(ln);
                    if (c.Length <= Math.Max(iName, iRun)) continue;
                    string task = c[iName], run = c[iRun];
                    if (task.Equals("TaskName", StringComparison.OrdinalIgnoreCase)) continue;
                    if (run.Length == 0 || run.Equals("N/A", StringComparison.OrdinalIgnoreCase)) continue;
                    if (task.StartsWith(@"\Microsoft\Windows\", StringComparison.OrdinalIgnoreCase)) continue;
                    if (!done.Add(task + "|" + run)) continue;
                    bool enabled = !(iStatus >= 0 && c.Length > iStatus && c[iStatus].Equals("Disabled", StringComparison.OrdinalIgnoreCase));
                    rows.Add(new AutorunRow { Category = "Scheduled Task", Name = task, Command = run, Kind = AutorunKind.Other, Toggle = ToggleKind.Task, Enabled = enabled });
                }
            }
            catch { }
        }

        private static void ServicesAndDrivers(List<AutorunRow> rows)
        {
            try
            {
                using var root = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services");
                if (root == null) return;
                foreach (var name in root.GetSubKeyNames())
                    try
                    {
                        using var k = root.OpenSubKey(name);
                        if (k == null) continue;
                        object? so = k.GetValue("Start"); if (so == null) continue;
                        int start = Convert.ToInt32(so);
                        if (start > 4) continue;
                        int type = 0; try { type = Convert.ToInt32(k.GetValue("Type", 0)); } catch { }
                        string img = k.GetValue("ImagePath")?.ToString() ?? "";
                        bool driver = type == 1 || type == 2 || img.IndexOf(".sys", StringComparison.OrdinalIgnoreCase) >= 0;
                        if (img.Length == 0 && !driver) continue;
                        string disp = k.GetValue("DisplayName")?.ToString() ?? name;
                        rows.Add(new AutorunRow
                        {
                            Category = driver ? "Driver" : "Service", Name = name, Command = img.Length > 0 ? img : name,
                            Path = ExePath(img), Description = disp, Kind = AutorunKind.Other,
                            Toggle = ToggleKind.Service, ServiceStart = start, Enabled = start != 4
                        });
                    }
                    catch { }
            }
            catch { }
        }

        public static bool SetEnabled(AutorunRow r, bool enable)
        {
            try
            {
                switch (r.Toggle)
                {
                    case ToggleKind.Approved:
                        if (r.ApprovedRoot == null) return false;
                        using (var k = r.ApprovedRoot.CreateSubKey(r.ApprovedSub, true))
                        {
                            if (k == null) return false;
                            k.SetValue(r.ValueName, enable ? ApprovedEnabledBytes : ApprovedDisabledBytes(), RegistryValueKind.Binary);
                        }
                        r.Enabled = enable; return true;

                    case ToggleKind.Service:
                        using (var k = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services\" + r.Name, true))
                        {
                            if (k == null) return false;
                            int val = enable ? (r.ServiceStart == 4 ? 2 : r.ServiceStart) : 4;
                            k.SetValue("Start", val, RegistryValueKind.DWord);
                        }
                        r.Enabled = enable; return true;

                    case ToggleKind.Task:
                        var psi = new ProcessStartInfo("schtasks.exe", $"/change /tn \"{r.Name}\" {(enable ? "/enable" : "/disable")}") { UseShellExecute = false, CreateNoWindow = true };
                        using (var p = Process.Start(psi)) { p?.WaitForExit(8000); if (p != null && p.ExitCode != 0) return false; }
                        r.Enabled = enable; return true;

                    case ToggleKind.AutorunsDisabled:
                        if (r.Root == null) return false;

                        string fromSub = enable ? r.SubKey + @"\AutorunsDisabled" : r.SubKey;
                        string toSub = enable ? r.SubKey : r.SubKey + @"\AutorunsDisabled";
                        using (var from = r.Root.OpenSubKey(fromSub, true))
                        {
                            if (from == null) return false;
                            object? val = from.GetValue(r.ValueName);
                            if (val == null) return false;
                            using (var to = r.Root.CreateSubKey(toSub, true))
                                to?.SetValue(r.ValueName, val, from.GetValueKind(r.ValueName));
                            from.DeleteValue(r.ValueName, false);
                        }
                        r.Enabled = enable; return true;
                }
            }
            catch { }
            return false;
        }

        public static bool Delete(AutorunRow r)
        {
            try
            {
                if (r.Kind == AutorunKind.RegValue && r.Root != null)
                {
                    using var k = r.Root.OpenSubKey(r.SubKey, writable: true);
                    if (k == null) return false;
                    k.DeleteValue(r.ValueName, false);
                    return true;
                }
                if (r.Kind == AutorunKind.StartupFile && File.Exists(r.FilePath)) { File.Delete(r.FilePath); return true; }
            }
            catch { }
            return false;
        }

        private static void Classify(AutorunRow r)
        {
            if (r.Path.Length == 0) r.Path = ExePath(r.Command);
            string p = r.Path;

            if (r.Category != "AppInit_DLLs")
            {
                if (p.Length == 0) r.Status = SigStatus.NoPath;
                else if (File.Exists(p)) { var (st, signer) = Authenticode.Check(p); r.Status = st; r.Signer = signer; }
                else r.Status = SigStatus.NoPath;
            }

            if (p.Length > 0 && File.Exists(p))
            {
                try { if (r.Description.Length == 0) { var fi = System.Diagnostics.FileVersionInfo.GetVersionInfo(p); r.Description = (fi.FileDescription ?? "").Trim(); } } catch { }
                try { r.Timestamp = File.GetLastWriteTime(p).ToString("yyyy-MM-dd HH:mm"); } catch { }
            }

            var f = new List<string>();
            string tmp = System.IO.Path.GetTempPath().TrimEnd('\\');
            string appdata = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string progdata = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);
            string profile = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            string name = System.IO.Path.GetFileName(p);

            if (r.Name == "Shell" && r.Category.Contains("Winlogon") && !r.Command.Trim().Equals("explorer.exe", StringComparison.OrdinalIgnoreCase)) f.Add("SHELL-HIJACK");
            if (r.Name == "Userinit" && r.Command.IndexOf("userinit.exe", StringComparison.OrdinalIgnoreCase) < 0) f.Add("USERINIT-HIJACK");
            if (r.Category == "IFEO Debugger") f.Add("IFEO-HIJACK");
            if (r.Category == "AppInit_DLLs") f.Add("APPINIT");
            if (r.Category == "SilentProcessExit") f.Add("SILENT-EXIT");

            if (name.Length > 0 && LolBins.Any(l => l.Equals(name, StringComparison.OrdinalIgnoreCase)))
            {
                f.Add("LOLBIN");
                string cl = r.Command.ToLowerInvariant();
                if (cl.Contains("-enc") || cl.Contains("encodedcommand") || cl.Contains("-w hidden") || cl.Contains("hidden") || cl.Contains("bypass") || cl.Contains("downloadstring") || cl.Contains("frombase64") || cl.Contains("iex") || cl.Contains("http"))
                    f.Add("SUSPICIOUS-CMD");
            }

            if (p.Length > 0)
            {
                if (p.StartsWith(tmp, StringComparison.OrdinalIgnoreCase)) f.Add("TEMP");
                else if (p.StartsWith(appdata, StringComparison.OrdinalIgnoreCase) || p.StartsWith(local, StringComparison.OrdinalIgnoreCase)) f.Add("APPDATA");
                else if (p.StartsWith(progdata, StringComparison.OrdinalIgnoreCase)) f.Add("PROGRAMDATA");
                else if (p.StartsWith(profile, StringComparison.OrdinalIgnoreCase) && !p.StartsWith(appdata, StringComparison.OrdinalIgnoreCase) && !p.StartsWith(local, StringComparison.OrdinalIgnoreCase)) f.Add("USERDIR");
            }

            if (r.Status == SigStatus.Untrusted) f.Add("BAD-SIG");
            else if (r.Status == SigStatus.Unsigned) f.Add("unsigned");

            bool sketchy = f.Contains("TEMP") || f.Contains("APPDATA") || f.Contains("PROGRAMDATA") || f.Contains("USERDIR") || r.Status == SigStatus.Unsigned;
            if (sketchy && ProcessList.IsDotNet(p)) f.Add("NET");

            try { if (p.Length > 0 && File.Exists(p) && (File.GetAttributes(p) & FileAttributes.Hidden) != 0) f.Add("HIDDEN-FILE"); } catch { }

            if (!r.Enabled) f.Insert(0, "DISABLED");
            r.Flags = string.Join(", ", f);
        }

        private static void EnumValues(List<AutorunRow> rows, RegistryKey root, string sub, string cat)
        {
            try
            {
                using var k = root.OpenSubKey(sub);
                if (k == null) return;
                foreach (var name in k.GetValueNames())
                {
                    if (name.Length == 0) continue;
                    string cmd = k.GetValue(name)?.ToString() ?? "";
                    if (cmd.Trim().Length == 0) continue;
                    rows.Add(new AutorunRow { Category = cat, Name = name, Command = cmd, Kind = AutorunKind.RegValue, Root = root, SubKey = sub, ValueName = name });
                }
            }
            catch { }
        }

        private static bool ApprovedEnabled(RegistryKey root, string sub, string name)
        {
            try { using var k = root.OpenSubKey(sub); return k?.GetValue(name) is byte[] v && v.Length >= 1 ? (v[0] & 1) == 0 : true; }
            catch { return true; }
        }

        private static string ClsidToPath(string clsid)
        {
            clsid = clsid.Trim();
            if (!clsid.StartsWith("{")) return "";
            foreach (var root in new[] { Registry.ClassesRoot, Registry.CurrentUser, Registry.LocalMachine })
                foreach (var pre in new[] { @"CLSID\", @"Software\Classes\CLSID\", @"Software\Classes\Wow6432Node\CLSID\", @"SOFTWARE\Classes\CLSID\", @"SOFTWARE\Classes\Wow6432Node\CLSID\" })
                    try { using var k = root.OpenSubKey(pre + clsid + @"\InprocServer32"); string v = k?.GetValue("")?.ToString() ?? ""; if (v.Length > 0) return Environment.ExpandEnvironmentVariables(v.Trim('"')); }
                    catch { }
            return "";
        }

        private static string ExePath(string cmd)
        {
            if (string.IsNullOrWhiteSpace(cmd)) return "";
            string s = Environment.ExpandEnvironmentVariables(cmd.Trim());
            if (s.StartsWith(@"\??\")) s = s[4..];
            if (s.StartsWith("\"")) { int e = s.IndexOf('"', 1); return e > 1 ? s.Substring(1, e - 1) : s; }
            int x = s.IndexOf(".exe", StringComparison.OrdinalIgnoreCase);
            if (x > 0) return s[..(x + 4)];
            int dll = s.IndexOf(".dll", StringComparison.OrdinalIgnoreCase);
            if (dll > 0) return s[..(dll + 4)];
            int sys = s.IndexOf(".sys", StringComparison.OrdinalIgnoreCase);
            if (sys > 0) { string cand = s[..(sys + 4)]; if (!cand.Contains('\\')) cand = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "drivers", cand); return cand; }
            int sp = s.IndexOf(' ');
            return sp > 0 ? s[..sp] : s;
        }

        private static string[] SplitCsv(string line)
        {
            var res = new List<string>(); var sb = new System.Text.StringBuilder(); bool q = false;
            for (int i = 0; i < line.Length; i++)
            {
                char c = line[i];
                if (c == '"') { if (q && i + 1 < line.Length && line[i + 1] == '"') { sb.Append('"'); i++; } else q = !q; }
                else if (c == ',' && !q) { res.Add(sb.ToString()); sb.Clear(); }
                else if (c == '\r') { }
                else sb.Append(c);
            }
            res.Add(sb.ToString());
            return res.ToArray();
        }

        private static string? ResolveLnk(string lnk)
        {
            try
            {
                byte[] b = File.ReadAllBytes(lnk);
                string ascii = System.Text.Encoding.ASCII.GetString(b);
                int i = ascii.IndexOf(":\\", StringComparison.Ordinal);
                if (i >= 1)
                {
                    var sb = new System.Text.StringBuilder();
                    for (int j = i - 1; j < ascii.Length; j++) { char c = ascii[j]; if (c is >= (char)32 and < (char)127) sb.Append(c); else break; }
                    string cand = sb.ToString();
                    int exe = cand.IndexOf(".exe", StringComparison.OrdinalIgnoreCase);
                    return exe > 0 ? cand[..(exe + 4)] : cand;
                }
            }
            catch { }
            return null;
        }
    }
}
