using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace XFlags.Services
{
    public sealed class DefExclusion { public string Kind = ""; public string Value = ""; }

    public sealed class DefenderStatus
    {
        public string Error = "";
        public bool AntivirusEnabled, RealTime, TamperProtected, Loaded;
        public List<DefExclusion> Exclusions = new();
    }

    public static class DefenderInfo
    {
        public static DefenderStatus Scan()
        {
            var r = new DefenderStatus();
            try
            {

                string script =
                    "Import-Module Defender -ErrorAction SilentlyContinue; " +
                    "$s=Get-MpComputerStatus; " +
                    "Write-Output ('AV='+$s.AntivirusEnabled); " +
                    "Write-Output ('RT='+$s.RealTimeProtectionEnabled); " +
                    "Write-Output ('TP='+$s.IsTamperProtected); " +
                    "$p=Get-MpPreference; " +
                    "$p.ExclusionPath | ForEach-Object { Write-Output ('PATH='+$_) }; " +
                    "$p.ExclusionProcess | ForEach-Object { Write-Output ('PROC='+$_) }; " +
                    "$p.ExclusionExtension | ForEach-Object { Write-Output ('EXT='+$_) }";

                var psi = new ProcessStartInfo("powershell.exe",
                    "-NoProfile -ExecutionPolicy Bypass -Command \"" + script.Replace("\"", "\\\"") + "\"")
                { RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false, CreateNoWindow = true, StandardOutputEncoding = Encoding.UTF8 };

                using var p = Process.Start(psi);
                if (p == null) { r.Error = "cannot start powershell"; return r; }
                string outp = p.StandardOutput.ReadToEnd();
                p.WaitForExit(15000);
                bool anyLine = false;
                foreach (var raw in outp.Split('\n'))
                {
                    string line = raw.Trim();
                    if (line.StartsWith("AV=")) { r.AntivirusEnabled = line.EndsWith("True", StringComparison.OrdinalIgnoreCase); anyLine = true; }
                    else if (line.StartsWith("RT=")) r.RealTime = line.EndsWith("True", StringComparison.OrdinalIgnoreCase);
                    else if (line.StartsWith("TP=")) r.TamperProtected = line.EndsWith("True", StringComparison.OrdinalIgnoreCase);
                    else if (line.StartsWith("PATH=")) r.Exclusions.Add(new DefExclusion { Kind = "Path", Value = line[5..] });
                    else if (line.StartsWith("PROC=")) r.Exclusions.Add(new DefExclusion { Kind = "Process", Value = line[5..] });
                    else if (line.StartsWith("EXT=")) r.Exclusions.Add(new DefExclusion { Kind = "Extension", Value = line[4..] });
                }
                r.Loaded = anyLine;
                if (!anyLine) r.Error = "Defender не установлен/недоступен — читаю исключения из реестра";
            }
            catch (Exception ex) { r.Error = ex.Message; }

            try
            {
                var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                foreach (var ex in r.Exclusions) seen.Add(ex.Kind + "|" + ex.Value);
                foreach (var (kind, sub) in new[] { ("Path", ExclSub("Path")), ("Process", ExclSub("Process")), ("Extension", ExclSub("Extension")) })
                    foreach (var name in RegHive.ReadValueNames("HKLM", sub))
                        if (seen.Add(kind + "|" + name)) r.Exclusions.Add(new DefExclusion { Kind = kind, Value = name });
            }
            catch { }
            return r;
        }

        private static string ExclSub(string kind) => @"SOFTWARE\Microsoft\Windows Defender\Exclusions\" + kind switch
        {
            "Process" => "Processes",
            "Extension" => "Extensions",
            _ => "Paths"
        };

        public static (bool ok, string msg) AddExclusion(string kind, string value)
        {
            var (ok, msg) = RunMp("Add", kind, value);
            if (ok) return (true, "ok");
            return RegHive.SetDwordBackup("HKLM", ExclSub(kind), value, 0) ? (true, "via registry") : (false, msg);
        }

        public static (bool ok, string msg) RemoveExclusion(string kind, string value)
        {
            var (ok, msg) = RunMp("Remove", kind, value);
            if (ok) return (true, "ok");
            return RegHive.DeleteValueBackup("HKLM", ExclSub(kind), value) ? (true, "via registry") : (false, msg);
        }

        private static (bool, string) RunMp(string verb, string kind, string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return (false, "empty value");
            string param = kind switch { "Process" => "ExclusionProcess", "Extension" => "ExclusionExtension", _ => "ExclusionPath" };
            string safe = value.Replace("'", "''");
            try
            {
                var psi = new ProcessStartInfo("powershell.exe",
                    $"-NoProfile -ExecutionPolicy Bypass -Command \"Import-Module Defender -ErrorAction SilentlyContinue; {verb}-MpPreference -{param} '{safe}'\"")
                { RedirectStandardError = true, RedirectStandardOutput = true, UseShellExecute = false, CreateNoWindow = true };
                using var p = Process.Start(psi);
                if (p == null) return (false, "cannot start powershell");
                string err = p.StandardError.ReadToEnd();
                p.WaitForExit(15000);
                return p.ExitCode == 0 ? (true, "ok") : (false, err.Trim().Length > 0 ? err.Trim() : "exit " + p.ExitCode);
            }
            catch (Exception ex) { return (false, ex.Message); }
        }
    }
}
