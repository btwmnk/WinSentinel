using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Runtime.InteropServices;

namespace XFlags.Services
{
    public sealed class ConnRow
    {
        public string Proto = "";
        public int Pid;
        public string Proc = "";
        public string Path = "";
        public string Local = "";
        public string Remote = "";
        public string State = "";
        public string Signer = "";
        public SigStatus Status = SigStatus.Unknown;
        public bool PublicRemote;

        public string Sig => Status switch
        {
            SigStatus.Signed => "signed",
            SigStatus.Catalog => "catalog",
            SigStatus.Unsigned => "UNSIGNED",
            SigStatus.Untrusted => "UNTRUSTED",
            SigStatus.NoPath => "no path",
            _ => ""
        };

        public string Level
        {
            get
            {
                bool noTrust = Status is SigStatus.Unsigned or SigStatus.Untrusted;
                if (noTrust && PublicRemote && State == "ESTABLISHED") return "bad";
                if (noTrust || (PublicRemote && State == "ESTABLISHED")) return "warn";
                return "ok";
            }
        }
    }

    public static class NetConnections
    {
        public static List<ConnRow> Scan()
        {
            var rows = new List<ConnRow>();
            var pathCache = new Dictionary<int, (string path, string name)>();
            var sigCache = new ConcurrentDictionary<string, (SigStatus, string)>(StringComparer.OrdinalIgnoreCase);

            Tcp(rows, AF_INET);
            Tcp(rows, AF_INET6);
            Udp(rows, AF_INET);
            Udp(rows, AF_INET6);

            foreach (var r in rows)
            {

                if (!pathCache.TryGetValue(r.Pid, out var pi))
                {
                    string path = "", name = "";
                    try { using var p = Process.GetProcessById(r.Pid); name = p.ProcessName + ".exe"; try { path = p.MainModule?.FileName ?? ""; } catch { } }
                    catch { name = r.Pid == 4 ? "System" : r.Pid == 0 ? "Idle" : "?"; }
                    pi = (path, name); pathCache[r.Pid] = pi;
                }
                r.Path = pi.path; r.Proc = pi.name;

                if (r.Path.Length > 0)
                {
                    var sig = sigCache.GetOrAdd(r.Path, p => Authenticode.Check(p));
                    r.Status = sig.Item1; r.Signer = sig.Item2;
                }
            }
            return rows;
        }

        public static bool Kill(int pid) => ProcessList.Kill(pid);
        public static string Sha256(string path) => ProcessList.Sha256(path);

        private static void Tcp(List<ConnRow> rows, int af)
        {
            int size = 0;
            GetExtendedTcpTable(IntPtr.Zero, ref size, false, af, TCP_TABLE_OWNER_PID_ALL, 0);
            IntPtr buf = Marshal.AllocHGlobal(size);
            try
            {
                if (GetExtendedTcpTable(buf, ref size, false, af, TCP_TABLE_OWNER_PID_ALL, 0) != 0) return;
                int n = Marshal.ReadInt32(buf);
                int off = 4;
                int rowSize = af == AF_INET ? Marshal.SizeOf<MIB_TCPROW_OWNER_PID>() : Marshal.SizeOf<MIB_TCP6ROW_OWNER_PID>();
                for (int i = 0; i < n; i++)
                {
                    string local, remote, state; int pid;
                    if (af == AF_INET)
                    {
                        var r = Marshal.PtrToStructure<MIB_TCPROW_OWNER_PID>(buf + off);
                        local = $"{V4(r.localAddr)}:{Port(r.localPort)}";
                        remote = $"{V4(r.remoteAddr)}:{Port(r.remotePort)}";
                        state = TcpState(r.state); pid = (int)r.owningPid;
                        AddTcp(rows, "TCP", pid, local, remote, state, new IPAddress(r.remoteAddr));
                    }
                    else
                    {
                        var r = Marshal.PtrToStructure<MIB_TCP6ROW_OWNER_PID>(buf + off);
                        var ra = new IPAddress(r.remoteAddr);
                        local = $"[{new IPAddress(r.localAddr)}]:{Port(r.localPort)}";
                        remote = $"[{ra}]:{Port(r.remotePort)}";
                        state = TcpState(r.state); pid = (int)r.owningPid;
                        AddTcp(rows, "TCP6", pid, local, remote, state, ra);
                    }
                    off += rowSize;
                }
            }
            catch { }
            finally { Marshal.FreeHGlobal(buf); }
        }

        private static void AddTcp(List<ConnRow> rows, string proto, int pid, string local, string remote, string state, IPAddress ra)
        {
            rows.Add(new ConnRow { Proto = proto, Pid = pid, Local = local, Remote = remote, State = state, PublicRemote = IsPublic(ra) });
        }

        private static void Udp(List<ConnRow> rows, int af)
        {
            int size = 0;
            GetExtendedUdpTable(IntPtr.Zero, ref size, false, af, UDP_TABLE_OWNER_PID, 0);
            IntPtr buf = Marshal.AllocHGlobal(size);
            try
            {
                if (GetExtendedUdpTable(buf, ref size, false, af, UDP_TABLE_OWNER_PID, 0) != 0) return;
                int n = Marshal.ReadInt32(buf);
                int off = 4;
                int rowSize = af == AF_INET ? Marshal.SizeOf<MIB_UDPROW_OWNER_PID>() : Marshal.SizeOf<MIB_UDP6ROW_OWNER_PID>();
                for (int i = 0; i < n; i++)
                {
                    if (af == AF_INET)
                    {
                        var r = Marshal.PtrToStructure<MIB_UDPROW_OWNER_PID>(buf + off);
                        rows.Add(new ConnRow { Proto = "UDP", Pid = (int)r.owningPid, Local = $"{V4(r.localAddr)}:{Port(r.localPort)}", Remote = "*", State = "", PublicRemote = false });
                    }
                    else
                    {
                        var r = Marshal.PtrToStructure<MIB_UDP6ROW_OWNER_PID>(buf + off);
                        rows.Add(new ConnRow { Proto = "UDP6", Pid = (int)r.owningPid, Local = $"[{new IPAddress(r.localAddr)}]:{Port(r.localPort)}", Remote = "*", State = "", PublicRemote = false });
                    }
                    off += rowSize;
                }
            }
            catch { }
            finally { Marshal.FreeHGlobal(buf); }
        }

        private static string V4(uint a) => new IPAddress(a).ToString();
        private static int Port(uint p) => ((int)(p & 0xFF) << 8) | ((int)(p >> 8) & 0xFF);
        private static string TcpState(uint s) => s switch
        {
            1 => "CLOSED", 2 => "LISTEN", 3 => "SYN_SENT", 4 => "SYN_RCVD", 5 => "ESTABLISHED",
            6 => "FIN_WAIT1", 7 => "FIN_WAIT2", 8 => "CLOSE_WAIT", 9 => "CLOSING", 10 => "LAST_ACK",
            11 => "TIME_WAIT", 12 => "DELETE_TCB", _ => s.ToString()
        };
        private static bool IsPublic(IPAddress a)
        {
            try
            {
                if (IPAddress.IsLoopback(a)) return false;
                var b = a.GetAddressBytes();
                if (b.Length == 4)
                {
                    if (b[0] == 0 || b[0] == 10 || b[0] == 127 || b[0] >= 224) return false;
                    if (b[0] == 172 && b[1] >= 16 && b[1] <= 31) return false;
                    if (b[0] == 192 && b[1] == 168) return false;
                    if (b[0] == 169 && b[1] == 254) return false;
                    return true;
                }
                return !a.IsIPv6LinkLocal && !a.IsIPv6SiteLocal && !a.IsIPv6Multicast && !a.Equals(IPAddress.IPv6Any);
            }
            catch { return false; }
        }

        private const int AF_INET = 2, AF_INET6 = 23;
        private const int TCP_TABLE_OWNER_PID_ALL = 5;
        private const int UDP_TABLE_OWNER_PID = 1;

        [StructLayout(LayoutKind.Sequential)]
        private struct MIB_TCPROW_OWNER_PID { public uint state, localAddr; public uint localPort; public uint remoteAddr, remotePort, owningPid; }
        [StructLayout(LayoutKind.Sequential)]
        private struct MIB_TCP6ROW_OWNER_PID { [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)] public byte[] localAddr; public uint localScopeId, localPort; [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)] public byte[] remoteAddr; public uint remoteScopeId, remotePort, state, owningPid; }
        [StructLayout(LayoutKind.Sequential)]
        private struct MIB_UDPROW_OWNER_PID { public uint localAddr, localPort, owningPid; }
        [StructLayout(LayoutKind.Sequential)]
        private struct MIB_UDP6ROW_OWNER_PID { [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)] public byte[] localAddr; public uint localScopeId, localPort, owningPid; }

        [DllImport("iphlpapi.dll", SetLastError = true)]
        private static extern uint GetExtendedTcpTable(IntPtr table, ref int size, bool order, int af, int cls, int reserved);
        [DllImport("iphlpapi.dll", SetLastError = true)]
        private static extern uint GetExtendedUdpTable(IntPtr table, ref int size, bool order, int af, int cls, int reserved);
    }
}
