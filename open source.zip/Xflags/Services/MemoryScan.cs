using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace XFlags.Services
{
    public sealed class InjRow
    {
        public int Pid;
        public string Proc = "";
        public string Path = "";
        public string Address = "";
        public string Size = "";
        public string Prot = "";
        public string Type = "";
        public bool Rwx;

        public string Level => Rwx ? "bad" : "warn";
    }

    public static class MemoryScan
    {
        public static List<InjRow> Scan()
        {
            var res = new List<InjRow>();
            foreach (var p in Process.GetProcesses())
            {
                int pid = p.Id;
                if (pid <= 4) { p.Dispose(); continue; }
                string name = ""; try { name = p.ProcessName + ".exe"; } catch { }
                IntPtr h = OpenProcess(PROCESS_QUERY_INFORMATION, false, (uint)pid);
                if (h == IntPtr.Zero) { p.Dispose(); continue; }
                string path = ImagePath(h);
                try
                {
                    IntPtr addr = IntPtr.Zero;
                    int sz = Marshal.SizeOf<MEMORY_BASIC_INFORMATION>();
                    int guard = 0;
                    while (VirtualQueryEx(h, addr, out var mbi, sz) != 0 && guard++ < 200000)
                    {
                        long baseA = (long)mbi.BaseAddress, region = (long)mbi.RegionSize;
                        if (region <= 0) break;

                        bool commit = mbi.State == MEM_COMMIT;
                        bool exec = (mbi.Protect & EXEC_MASK) != 0;
                        bool priv = mbi.Type == MEM_PRIVATE;
                        if (commit && exec && priv)
                        {
                            bool rwx = (mbi.Protect & PAGE_EXECUTE_READWRITE) != 0;
                            res.Add(new InjRow
                            {
                                Pid = pid, Proc = name, Path = path,
                                Address = "0x" + baseA.ToString("X"),
                                Size = Sz(region),
                                Prot = ProtStr(mbi.Protect),
                                Type = "PRIVATE",
                                Rwx = rwx
                            });
                        }

                        long next = baseA + region;
                        if (next <= baseA) break;
                        addr = (IntPtr)next;
                        if (next >= 0x7FFFFFFF0000) break;
                    }
                }
                catch { }
                finally { CloseHandle(h); p.Dispose(); }
            }

            res.Sort((a, b) => (a.Level == "bad" ? 0 : 1).CompareTo(b.Level == "bad" ? 0 : 1));
            return res;
        }

        public static string Sha256(string path) => ProcessList.Sha256(path);
        public static bool Kill(int pid) => ProcessList.Kill(pid);

        private static string ImagePath(IntPtr h)
        {
            var sb = new System.Text.StringBuilder(1024); int cap = sb.Capacity;
            return QueryFullProcessImageName(h, 0, sb, ref cap) ? sb.ToString() : "";
        }
        private static string ProtStr(uint p) => (p & 0xFF) switch
        {
            PAGE_EXECUTE => "X",
            PAGE_EXECUTE_READ => "RX",
            PAGE_EXECUTE_READWRITE => "RWX",
            PAGE_EXECUTE_WRITECOPY => "WCX",
            _ => "0x" + p.ToString("X")
        };
        private static string Sz(long b) => b < 1024 ? b + " B" : b < 1048576 ? (b / 1024.0).ToString("0.#") + " KB" : (b / 1048576.0).ToString("0.##") + " MB";

        private const uint PROCESS_QUERY_INFORMATION = 0x0400;
        private const uint MEM_COMMIT = 0x1000, MEM_PRIVATE = 0x20000;
        private const uint PAGE_EXECUTE = 0x10, PAGE_EXECUTE_READ = 0x20, PAGE_EXECUTE_READWRITE = 0x40, PAGE_EXECUTE_WRITECOPY = 0x80;
        private const uint EXEC_MASK = 0xF0;

        [StructLayout(LayoutKind.Sequential)]
        private struct MEMORY_BASIC_INFORMATION
        {
            public IntPtr BaseAddress;
            public IntPtr AllocationBase;
            public uint AllocationProtect;
            public uint __a1;
            public IntPtr RegionSize;
            public uint State;
            public uint Protect;
            public uint Type;
            public uint __a2;
        }

        [DllImport("kernel32.dll", SetLastError = true)] private static extern IntPtr OpenProcess(uint access, bool inherit, uint pid);
        [DllImport("kernel32.dll")] private static extern bool CloseHandle(IntPtr h);
        [DllImport("kernel32.dll")] private static extern int VirtualQueryEx(IntPtr h, IntPtr addr, out MEMORY_BASIC_INFORMATION mbi, int len);
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)] private static extern bool QueryFullProcessImageName(IntPtr h, uint flags, System.Text.StringBuilder buf, ref int size);
    }
}
