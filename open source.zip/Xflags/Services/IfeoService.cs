using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using Microsoft.Win32;

namespace XFlags.Services
{
    public sealed class FlagOption
    {
        public string Abbreviation = "";
        public string Description = "";
        public long Hex;
    }

    public sealed class MitigationOption
    {
        public string Abbreviation = "";
        public string Description = "";
        public long AlwaysOn;
        public long AlwaysOff;
    }

    public sealed class IfeoConfig
    {
        public int? CpuPriority, IoPriority, PagePriority, UseLargePages;
        public long? GlobalFlag, MitigationOptions;
        public string? Debugger;
    }

    public static class IfeoData
    {

        public static readonly List<FlagOption> GFlags = new()
        {
            new() { Abbreviation = "soe",  Hex = 0x01,       Description = "Stop on exception" },
            new() { Abbreviation = "sls",  Hex = 0x02,       Description = "Show loader snaps" },
            new() { Abbreviation = "dic",  Hex = 0x04,       Description = "Debug initial command" },
            new() { Abbreviation = "htc",  Hex = 0x10,       Description = "Heap tail checking" },
            new() { Abbreviation = "hfc",  Hex = 0x20,       Description = "Heap free checking" },
            new() { Abbreviation = "hpc",  Hex = 0x40,       Description = "Heap parameter checking" },
            new() { Abbreviation = "hvc",  Hex = 0x80,       Description = "Heap validation on call" },
            new() { Abbreviation = "mspe", Hex = 0x200,      Description = "Silent process exit monitoring" },
            new() { Abbreviation = "htg",  Hex = 0x800,      Description = "Heap tagging" },
            new() { Abbreviation = "otl",  Hex = 0x4000,     Description = "Maintain object typelist (system)" },
            new() { Abbreviation = "htd",  Hex = 0x8000,     Description = "Heap tagging by DLL" },
            new() { Abbreviation = "dse",  Hex = 0x010000,   Description = "Disable stack extension" },
            new() { Abbreviation = "d32",  Hex = 0x020000,   Description = "CSRDEBUG (system)" },
            new() { Abbreviation = "ksl",  Hex = 0x040000,   Description = "Load kernel debugger symbols (system)" },
            new() { Abbreviation = "dps",  Hex = 0x080000,   Description = "Disable paging of kernel stacks (system)" },
            new() { Abbreviation = "scb",  Hex = 0x100000,   Description = "System critical breaks (system)" },
            new() { Abbreviation = "dhc",  Hex = 0x200000,   Description = "Disable heap coalescing" },
            new() { Abbreviation = "ece",  Hex = 0x400000,   Description = "Close exception" },
            new() { Abbreviation = "eel",  Hex = 0x800000,   Description = "Exception logging" },
            new() { Abbreviation = "eot",  Hex = 0x01000000, Description = "Handle type tagging" },
            new() { Abbreviation = "hpa",  Hex = 0x02000000, Description = "Page heap" },
            new() { Abbreviation = "dwl",  Hex = 0x04000000, Description = "Debug WinLogon (system)" },
            new() { Abbreviation = "cse",  Hex = 0x10000000, Description = "Early critical section events" },
            new() { Abbreviation = "sue",  Hex = 0x20000000, Description = "Stop on unhandled exception" },
            new() { Abbreviation = "bhd",  Hex = 0x40000000, Description = "Bad handle detection" },
            new() { Abbreviation = "dpd",  Hex = 0x80000000, Description = "Disable protected DLLs" },
        };

        public static readonly List<MitigationOption> Mitigations = new()
        {
            new() { Abbreviation = "aslr",          AlwaysOn = 0x100,             AlwaysOff = 0x200,             Description = "Mandatory ASLR (force relocate images)" },
            new() { Abbreviation = "heapt",         AlwaysOn = 0x1000,            AlwaysOff = 0x2000,            Description = "Heap termination on corruption" },
            new() { Abbreviation = "buaslr",        AlwaysOn = 0x10000,           AlwaysOff = 0x20000,           Description = "Bottom-up ASLR" },
            new() { Abbreviation = "heaslr",        AlwaysOn = 0x100000,          AlwaysOff = 0x200000,          Description = "High-entropy ASLR" },
            new() { Abbreviation = "shc",           AlwaysOn = 0x1000000,         AlwaysOff = 0x2000000,         Description = "Strict handle checks" },
            new() { Abbreviation = "dis-win32k",    AlwaysOn = 0x10000000,        AlwaysOff = 0x20000000,        Description = "Disable Win32k calls" },
            new() { Abbreviation = "dis-extpoint",  AlwaysOn = 0x100000000,       AlwaysOff = 0x200000000,       Description = "Disable extension points" },
            new() { Abbreviation = "dis-dyncode",   AlwaysOn = 0x1000000000,      AlwaysOff = 0x2000000000,      Description = "Disable dynamic code (breaks .NET/Electron)" },
            new() { Abbreviation = "cfg",           AlwaysOn = 0x10000000000,     AlwaysOff = 0x20000000000,     Description = "Control Flow Guard" },
            new() { Abbreviation = "block-non-ms",  AlwaysOn = 0x100000000000,    AlwaysOff = 0x200000000000,    Description = "Block non-Microsoft binaries" },
            new() { Abbreviation = "block-non-sysf",AlwaysOn = 0x1000000000000,   AlwaysOff = 0x2000000000000,   Description = "Block non-system fonts" },
            new() { Abbreviation = "dis-remloads",  AlwaysOn = 0x10000000000000,  AlwaysOff = 0x20000000000000,  Description = "Disable remote image loads" },
            new() { Abbreviation = "dis-lowintl",   AlwaysOn = 0x100000000000000, AlwaysOff = 0x200000000000000, Description = "Disable low-integrity image loads" },
            new() { Abbreviation = "pref-sysimg",   AlwaysOn = 0x1000000000000000,AlwaysOff = 0x2000000000000000,Description = "Prefer system32 images" },
        };

        public static readonly List<FlagOption> Extra = new()
        {
            new() { Abbreviation = "dep",   Hex = 0x1, Description = "DEP (enable only; permanent on x64)" },
            new() { Abbreviation = "atl",   Hex = 0x2, Description = "ATL thunk emulation" },
            new() { Abbreviation = "sehop", Hex = 0x4, Description = "SEHOP" },
        };
    }

    public static class IfeoManager
    {
        private const string IfeoPath = @"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options";
        private const string ManagedKey = @"Software\XFlags\ManagedIfeo";

        public static List<string> GetProcessNames(bool running)
        {
            var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            if (running)
            {
                foreach (var p in Process.GetProcesses())
                    if (!string.IsNullOrEmpty(p.ProcessName)) set.Add(p.ProcessName + ".exe");
            }
            else
            {
                using var key = Registry.LocalMachine.OpenSubKey(IfeoPath);
                if (key != null)
                    foreach (var sub in key.GetSubKeyNames())
                        set.Add(sub.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) ? sub : sub + ".exe");
            }
            return set.OrderBy(x => x, StringComparer.OrdinalIgnoreCase).ToList();
        }

        public static HashSet<string> GetConfigured()
        {
            var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            try
            {
                using var k = Registry.CurrentUser.OpenSubKey(ManagedKey);
                if (k != null) foreach (var v in k.GetValueNames()) set.Add(v);
            }
            catch { }
            return set;
        }

        public static IfeoConfig? Get(string process)
        {
            var cfg = new IfeoConfig();
            using (var key = Registry.LocalMachine.OpenSubKey($@"{IfeoPath}\{process}"))
            {
                if (key == null) return null;
                cfg.UseLargePages = RDWord(key, "UseLargePages");
                cfg.GlobalFlag = RFlags(key, "GlobalFlag");
                cfg.MitigationOptions = RFlags(key, "MitigationOptions");
                cfg.Debugger = key.GetValue("Debugger") as string;
            }
            using (var key = Registry.LocalMachine.OpenSubKey($@"{IfeoPath}\{process}\PerfOptions"))
            {
                if (key != null)
                {
                    cfg.CpuPriority = RDWord(key, "CpuPriorityClass");
                    cfg.IoPriority = RDWord(key, "IoPriority");
                    cfg.PagePriority = RDWord(key, "PagePriority");
                }
            }
            return cfg;
        }

        public static void Set(string process, IfeoConfig c)
        {
            Track(process, true);
            string def = $@"{IfeoPath}\{process}", opt = $@"{def}\PerfOptions";
            using (var key = Registry.LocalMachine.CreateSubKey(def))
            {
                SetDW(key, "UseLargePages", c.UseLargePages);
                SetFlagsDW(key, "GlobalFlag", c.GlobalFlag);
                SetMit(key, c.MitigationOptions);
                SetStr(key, "Debugger", string.IsNullOrEmpty(c.Debugger) ? null : c.Debugger);
            }
            if (c.CpuPriority.HasValue || c.IoPriority.HasValue || c.PagePriority.HasValue)
            {
                using var key = Registry.LocalMachine.CreateSubKey(opt);
                SetDW(key, "CpuPriorityClass", c.CpuPriority);
                SetDW(key, "IoPriority", c.IoPriority);
                SetDW(key, "PagePriority", c.PagePriority);
            }
            else { try { Registry.LocalMachine.DeleteSubKey(opt, false); } catch { } }

            bool empty = !c.UseLargePages.HasValue && !c.GlobalFlag.HasValue && !c.MitigationOptions.HasValue
                       && string.IsNullOrEmpty(c.Debugger) && !c.CpuPriority.HasValue && !c.IoPriority.HasValue && !c.PagePriority.HasValue;
            if (empty) Delete(process);
        }

        public static void Delete(string process)
        {
            try { Registry.LocalMachine.DeleteSubKeyTree($@"{IfeoPath}\{process}", false); } catch { }
            Track(process, false);
        }

        public static List<string> GetManaged()
        {
            using var k = Registry.CurrentUser.OpenSubKey(ManagedKey);
            return k?.GetValueNames().ToList() ?? new List<string>();
        }

        private static void Track(string process, bool add)
        {
            try
            {
                using var k = Registry.CurrentUser.CreateSubKey(ManagedKey);
                if (add) k.SetValue(process, 1, RegistryValueKind.DWord); else k.DeleteValue(process, false);
            }
            catch { }
        }

        private static int? RDWord(RegistryKey key, string name)
        {
            var v = key.GetValue(name);
            if (v == null) return null;
            try { return Convert.ToInt32(v); } catch { return null; }
        }

        private static long? RFlags(RegistryKey key, string name)
        {
            var v = key.GetValue(name);
            if (v == null) return null;
            try
            {
                if (v is int i) return (long)(uint)i;
                if (v is long l) return l;
                if (v is byte[] b) return b.Length >= 8 ? BitConverter.ToInt64(b, 0) : 0L;
                if (v is string s) return Convert.ToInt64(s, 16);
                return Convert.ToInt64(v);
            }
            catch { return null; }
        }

        private static void SetDW(RegistryKey key, string name, int? value)
        {
            if (value.HasValue) key.SetValue(name, value.Value, RegistryValueKind.DWord);
            else key.DeleteValue(name, false);
        }

        private static void SetFlagsDW(RegistryKey key, string name, long? value)
        {
            if (value.HasValue) key.SetValue(name, unchecked((int)(value.Value & 0xFFFFFFFFL)), RegistryValueKind.DWord);
            else key.DeleteValue(name, false);
        }

        private static void SetMit(RegistryKey key, long? value)
        {
            var existing = key.GetValue("MitigationOptions") as byte[];
            if (existing != null && existing.Length > 8)
            {
                var data = (byte[])existing.Clone();
                BitConverter.GetBytes(value ?? 0L).CopyTo(data, 0);
                if (data.All(x => x == 0)) key.DeleteValue("MitigationOptions", false);
                else key.SetValue("MitigationOptions", data, RegistryValueKind.Binary);
                return;
            }
            if (value.HasValue) key.SetValue("MitigationOptions", value.Value, RegistryValueKind.QWord);
            else key.DeleteValue("MitigationOptions", false);
        }

        private static void SetStr(RegistryKey key, string name, string? value)
        {
            if (value != null) key.SetValue(name, value, RegistryValueKind.String);
            else key.DeleteValue(name, false);
        }
    }
}
