using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

namespace XFlags.Services
{
    public sealed class DriverRow
    {
        public string Name = "";
        public string Path = "";
        public string Signer = "";
        public string Company = "";
        public SigStatus Status = SigStatus.Unknown;

        public string Sig => Status switch
        {
            SigStatus.Signed => "signed",
            SigStatus.Catalog => "catalog",
            SigStatus.Unsigned => "UNSIGNED",
            SigStatus.Untrusted => "UNTRUSTED",
            SigStatus.NoPath => "no file",
            _ => ""
        };
        public string Level => Status is SigStatus.Unsigned or SigStatus.Untrusted or SigStatus.NoPath ? "warn" : "ok";
    }

    public static class DriversList
    {
        public static List<DriverRow> Scan()
        {
            var res = new List<DriverRow>();
            try
            {
                uint needed = 0;
                EnumDeviceDrivers(null, 0, out needed);
                if (needed == 0) return res;
                int count = (int)(needed / (uint)IntPtr.Size);
                var bases = new IntPtr[count];
                if (!EnumDeviceDrivers(bases, needed, out needed)) return res;

                string win = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
                var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

                foreach (var b in bases)
                {
                    if (b == IntPtr.Zero) continue;
                    var sb = new StringBuilder(1024);
                    if (GetDeviceDriverFileName(b, sb, sb.Capacity) == 0) continue;
                    string raw = sb.ToString();
                    string path = Normalize(raw, win);
                    if (!seen.Add(path)) continue;

                    var row = new DriverRow { Name = System.IO.Path.GetFileName(path), Path = path };
                    if (File.Exists(path))
                    {
                        var (st, signer) = Authenticode.Check(path);
                        row.Status = st; row.Signer = signer;
                        try { var fi = System.Diagnostics.FileVersionInfo.GetVersionInfo(path); row.Company = (fi.CompanyName ?? "").Trim(); } catch { }
                    }
                    else row.Status = SigStatus.NoPath;
                    res.Add(row);
                }
            }
            catch { }

            res.Sort((a, b) =>
            {
                int ra = a.Level == "warn" ? 0 : 1, rb = b.Level == "warn" ? 0 : 1;
                return ra != rb ? ra.CompareTo(rb) : string.Compare(a.Name, b.Name, StringComparison.OrdinalIgnoreCase);
            });
            return res;
        }

        public static string Sha256(string path) => ProcessList.Sha256(path);

        public static (bool ok, string msg) InstallDriver(string sysPath, string? serviceName = null)
        {
            if (string.IsNullOrEmpty(sysPath) || !File.Exists(sysPath)) return (false, "файл не найден");
            string name = serviceName ?? System.IO.Path.GetFileNameWithoutExtension(sysPath);
            IntPtr scm = OpenSCManager(null, null, SC_MANAGER_ALL_ACCESS);
            if (scm == IntPtr.Zero) return (false, "OpenSCManager: " + Marshal.GetLastWin32Error());
            IntPtr svc = IntPtr.Zero;
            try
            {
                svc = CreateService(scm, name, name, SERVICE_ALL_ACCESS, SERVICE_KERNEL_DRIVER, SERVICE_DEMAND_START, SERVICE_ERROR_NORMAL,
                                    sysPath, null, IntPtr.Zero, null, null, null);
                if (svc == IntPtr.Zero)
                {
                    int e = Marshal.GetLastWin32Error();
                    if (e == 1073) svc = OpenService(scm, name, SERVICE_ALL_ACCESS);
                    if (svc == IntPtr.Zero) return (false, "CreateService: " + e);
                }
                if (!StartService(svc, 0, null))
                {
                    int e = Marshal.GetLastWin32Error();
                    if (e == 1056) return (true, "уже запущен");
                    return (false, "StartService: " + ErrText(e));
                }
                return (true, "установлен и запущен: " + name);
            }
            catch (Exception ex) { return (false, ex.Message); }
            finally { if (svc != IntPtr.Zero) CloseServiceHandle(svc); CloseServiceHandle(scm); }
        }

        public static (bool ok, string msg) UninstallDriver(string serviceName)
        {
            IntPtr scm = OpenSCManager(null, null, SC_MANAGER_ALL_ACCESS);
            if (scm == IntPtr.Zero) return (false, "OpenSCManager: " + Marshal.GetLastWin32Error());
            IntPtr svc = IntPtr.Zero;
            try
            {
                svc = OpenService(scm, serviceName, SERVICE_ALL_ACCESS);
                if (svc == IntPtr.Zero) return (false, "служба не найдена: " + serviceName);
                var st = new SERVICE_STATUS();
                ControlService(svc, SERVICE_CONTROL_STOP, ref st);
                bool ok = DeleteService(svc);
                return ok ? (true, "удалён: " + serviceName) : (false, "DeleteService: " + Marshal.GetLastWin32Error());
            }
            finally { if (svc != IntPtr.Zero) CloseServiceHandle(svc); CloseServiceHandle(scm); }
        }

        private static string ErrText(int e) => e switch
        {
            577 => "577 — драйвер не подписан (включена проверка подписи DSE)",
            1275 => "1275 — драйвер заблокирован политикой",
            1058 => "1058 — служба отключена",
            _ => e.ToString()
        };

        private const uint SC_MANAGER_ALL_ACCESS = 0xF003F, SERVICE_ALL_ACCESS = 0xF01FF;
        private const uint SERVICE_KERNEL_DRIVER = 0x1, SERVICE_DEMAND_START = 0x3, SERVICE_ERROR_NORMAL = 0x1, SERVICE_CONTROL_STOP = 0x1;

        [StructLayout(LayoutKind.Sequential)]
        private struct SERVICE_STATUS { public uint t, cur, ctrl, win32, svc, chk, wait; }

        [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        private static extern IntPtr OpenSCManager(string? machine, string? db, uint access);
        [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        private static extern IntPtr CreateService(IntPtr scm, string name, string display, uint access, uint type, uint start, uint errCtrl, string binPath, string? group, IntPtr tag, string? deps, string? user, string? pwd);
        [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        private static extern IntPtr OpenService(IntPtr scm, string name, uint access);
        [DllImport("advapi32.dll", SetLastError = true)]
        private static extern bool StartService(IntPtr svc, int argc, string[]? argv);
        [DllImport("advapi32.dll", SetLastError = true)]
        private static extern bool ControlService(IntPtr svc, uint control, ref SERVICE_STATUS status);
        [DllImport("advapi32.dll", SetLastError = true)]
        private static extern bool DeleteService(IntPtr svc);
        [DllImport("advapi32.dll", SetLastError = true)]
        private static extern bool CloseServiceHandle(IntPtr h);

        private static string Normalize(string p, string win)
        {
            if (string.IsNullOrEmpty(p)) return p;
            if (p.StartsWith(@"\SystemRoot\", StringComparison.OrdinalIgnoreCase)) return win + p.Substring(11);
            if (p.StartsWith(@"\??\", StringComparison.Ordinal)) return p.Substring(4);
            if (p.StartsWith(@"\Windows\", StringComparison.OrdinalIgnoreCase))
                return System.IO.Path.GetPathRoot(win)?.TrimEnd('\\') + p;
            return p;
        }

        [DllImport("psapi.dll", SetLastError = true)]
        private static extern bool EnumDeviceDrivers(IntPtr[]? image, uint cb, out uint needed);
        [DllImport("psapi.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern int GetDeviceDriverFileName(IntPtr image, StringBuilder name, int size);
    }
}
