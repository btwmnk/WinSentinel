using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;

namespace XFlags.Services
{
    public static class RegHive
    {
        private static readonly IntPtr HKEY_USERS = new(unchecked((int)0x80000003));
        private static readonly IntPtr HKEY_LOCAL_MACHINE = new(unchecked((int)0x80000002));
        private static readonly IntPtr HKEY_CURRENT_USER = new(unchecked((int)0x80000001));
        private const int KEY_READ = 0x20019;
        private const int KEY_SET_VALUE = 0x0002;
        private const int KEY_QUERY_VALUE = 0x0001;
        private const uint REG_OPTION_BACKUP_RESTORE = 0x00000004;
        private static bool _privEnabled;

        public static bool SetDwordBackup(string hive, string sub, string valueName, int val)
        {
            EnsureBackupPrivilege();
            IntPtr root = hive == "HKLM" ? HKEY_LOCAL_MACHINE : HKEY_CURRENT_USER;
            IntPtr hKey = IntPtr.Zero;
            try
            {
                int rc = RegCreateKeyEx(root, sub, 0, null, REG_OPTION_BACKUP_RESTORE, KEY_SET_VALUE | KEY_QUERY_VALUE, IntPtr.Zero, out hKey, out _);
                if (rc != 0 || hKey == IntPtr.Zero) return false;
                int d = val;
                return RegSetValueEx(hKey, valueName, 0, 4 , ref d, 4) == 0;
            }
            catch { return false; }
            finally { if (hKey != IntPtr.Zero) RegCloseKey(hKey); }
        }

        public static List<string> ReadValueNames(string hive, string sub)
        {
            var res = new List<string>();
            try
            {
                var root = hive == "HKLM" ? Microsoft.Win32.Registry.LocalMachine : Microsoft.Win32.Registry.CurrentUser;
                using var k = root.OpenSubKey(sub);
                if (k != null) { res.AddRange(k.GetValueNames()); return res; }
            }
            catch { }
            EnsureBackupPrivilege();
            IntPtr hRoot = hive == "HKLM" ? HKEY_LOCAL_MACHINE : HKEY_CURRENT_USER;
            IntPtr hKey = IntPtr.Zero;
            try
            {
                if (RegCreateKeyEx(hRoot, sub, 0, null, REG_OPTION_BACKUP_RESTORE, KEY_READ, IntPtr.Zero, out hKey, out _) != 0 || hKey == IntPtr.Zero) return res;
                for (int i = 0; ; i++)
                {
                    var name = new StringBuilder(16383);
                    int nameLen = name.Capacity; int type = 0, dataLen = 0;
                    int q = RegEnumValue(hKey, i, name, ref nameLen, IntPtr.Zero, out type, null, ref dataLen);
                    if (q == 259) break;
                    if (q != 0 && q != 234) break;
                    string nm = name.ToString();
                    if (nm.Length > 0) res.Add(nm);
                }
            }
            catch { }
            finally { if (hKey != IntPtr.Zero) RegCloseKey(hKey); }
            return res;
        }

        public static bool DeleteValueBackup(string hive, string sub, string valueName)
        {
            EnsureBackupPrivilege();
            IntPtr root = hive == "HKLM" ? HKEY_LOCAL_MACHINE : HKEY_CURRENT_USER;
            IntPtr hKey = IntPtr.Zero;
            try
            {
                int rc = RegCreateKeyEx(root, sub, 0, null, REG_OPTION_BACKUP_RESTORE, KEY_SET_VALUE | KEY_QUERY_VALUE, IntPtr.Zero, out hKey, out _);
                if (rc != 0 || hKey == IntPtr.Zero) return false;
                return RegDeleteValue(hKey, valueName) == 0;
            }
            catch { return false; }
            finally { if (hKey != IntPtr.Zero) RegCloseKey(hKey); }
        }

        public static int LastSids, LastVals;

        public static List<(string sid, string name, string value)> ReadUserValues(string subPath)
        {
            EnsureBackupPrivilege();
            var res = new List<(string, string, string)>();
            string[] sids;
            try { sids = Microsoft.Win32.Registry.Users.GetSubKeyNames(); }
            catch { return res; }

            int nsid = 0;
            foreach (var sid in sids)
            {
                if (!sid.StartsWith("S-1-5-21", StringComparison.Ordinal) || sid.EndsWith("_Classes", StringComparison.OrdinalIgnoreCase)) continue;
                nsid++;

                try
                {
                    using var k = Microsoft.Win32.Registry.Users.OpenSubKey(sid + "\\" + subPath);
                    if (k != null)
                    {
                        foreach (var name in k.GetValueNames())
                        {
                            string val = k.GetValue(name)?.ToString() ?? "";
                            if (name.Length > 0 && val.Length > 0) res.Add((sid, name, val));
                        }
                        continue;
                    }
                }
                catch { }

                IntPtr hKey = IntPtr.Zero;
                try
                {
                    int rc = RegCreateKeyEx(HKEY_USERS, sid + "\\" + subPath, 0, null, REG_OPTION_BACKUP_RESTORE, KEY_READ, IntPtr.Zero, out hKey, out _);
                    if (rc != 0 || hKey == IntPtr.Zero) continue;
                    for (int i = 0; ; i++)
                    {
                        var name = new StringBuilder(16383);
                        int nameLen = name.Capacity; int type = 0, dataLen = 0;
                        int q = RegEnumValue(hKey, i, name, ref nameLen, IntPtr.Zero, out type, null, ref dataLen);
                        if (q == 259) break;
                        if (q != 0 && q != 234) break;
                        byte[] data = new byte[Math.Max(dataLen, 2)];
                        nameLen = name.Capacity; name.Clear();
                        if (RegEnumValue(hKey, i, name, ref nameLen, IntPtr.Zero, out type, data, ref dataLen) != 0) continue;
                        if (type != 1 && type != 2) continue;
                        string val = Encoding.Unicode.GetString(data, 0, dataLen).TrimEnd('\0');
                        string nm = name.ToString();
                        if (nm.Length > 0 && val.Length > 0) res.Add((sid, nm, val));
                    }
                }
                catch { }
                finally { if (hKey != IntPtr.Zero) RegCloseKey(hKey); }
            }
            LastSids = nsid; LastVals = res.Count;
            return res;
        }

        private static void EnsureBackupPrivilege()
        {
            if (_privEnabled) return;
            _privEnabled = true;
            try
            {
                if (!OpenProcessToken(GetCurrentProcess(), 0x0020 | 0x0008 , out IntPtr tok)) return;
                try
                {
                    foreach (var priv in new[] { "SeBackupPrivilege", "SeRestorePrivilege" })
                    {
                        if (!LookupPrivilegeValue(null, priv, out LUID luid)) continue;
                        var tp = new TOKEN_PRIVILEGES { PrivilegeCount = 1, Luid = luid, Attributes = 0x00000002  };
                        AdjustTokenPrivileges(tok, false, ref tp, 0, IntPtr.Zero, IntPtr.Zero);
                    }
                }
                finally { CloseHandle(tok); }
            }
            catch { }
        }

        [StructLayout(LayoutKind.Sequential)] private struct LUID { public uint Low; public int High; }
        [StructLayout(LayoutKind.Sequential)] private struct TOKEN_PRIVILEGES { public int PrivilegeCount; public LUID Luid; public int Attributes; }

        [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern int RegCreateKeyEx(IntPtr hKey, string sub, int reserved, string? cls, uint options, int sam, IntPtr sec, out IntPtr result, out int disp);
        [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern int RegEnumValue(IntPtr hKey, int index, StringBuilder name, ref int nameLen, IntPtr reserved, out int type, byte[]? data, ref int dataLen);
        [DllImport("advapi32.dll")] private static extern int RegCloseKey(IntPtr hKey);
        [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern int RegDeleteValue(IntPtr hKey, string valueName);
        [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern int RegSetValueEx(IntPtr hKey, string valueName, int reserved, int type, ref int data, int cbData);
        [DllImport("kernel32.dll")] private static extern IntPtr GetCurrentProcess();
        [DllImport("advapi32.dll", SetLastError = true)] private static extern bool OpenProcessToken(IntPtr h, uint access, out IntPtr token);
        [DllImport("kernel32.dll")] private static extern bool CloseHandle(IntPtr h);
        [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern bool LookupPrivilegeValue(string? sys, string name, out LUID luid);
        [DllImport("advapi32.dll", SetLastError = true)] private static extern bool AdjustTokenPrivileges(IntPtr token, bool disableAll, ref TOKEN_PRIVILEGES newState, int len, IntPtr prev, IntPtr prevLen);
    }
}
