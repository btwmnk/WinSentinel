using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.UI.Dispatching;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Windows.ApplicationModel.DataTransfer;
using XFlags.Services;

namespace XFlags.Features
{
    public sealed partial class DriversPage : Page
    {
        private readonly ObservableCollection<DriverRow> _view = new();
        private readonly List<DriverRow> _all = new();
        private readonly DispatcherQueue _ui;
        private CancellationTokenSource? _cts;

        public DriversPage()
        {
            InitializeComponent();
            _ui = DispatcherQueue.GetForCurrentThread();
            List.ItemsSource = _view;
            Loaded += (s, e) => { if (_all.Count == 0) Refresh(); };
        }

        private void Refresh_Click(object sender, RoutedEventArgs e) => Refresh();

        private void Refresh()
        {
            _cts?.Cancel();
            _cts = new CancellationTokenSource();
            var token = _cts.Token;
            BtnRefresh.IsEnabled = false;
            Status.Text = "scanning drivers…";
            _all.Clear(); _view.Clear();

            Task.Run(() =>
            {
                var rows = DriversList.Scan();
                int uns = rows.Count(r => r.Level == "warn");
                _ui.TryEnqueue(() =>
                {
                    if (token.IsCancellationRequested) return;
                    _all.AddRange(rows);
                    ApplyFilter();
                    Status.Text = $"{rows.Count} drivers · {uns} unsigned/no-file";
                    BtnRefresh.IsEnabled = true;
                });
            }, token);
        }

        private void Filter_Changed(object sender, TextChangedEventArgs e) => ApplyFilter();
        private void Filter_Toggle(object sender, RoutedEventArgs e) => ApplyFilter();

        private void ApplyFilter()
        {
            string q = Filter.Text?.Trim() ?? "";
            bool onlyUns = OnlyUnsigned.IsChecked == true;
            _view.Clear();
            foreach (var r in _all)
            {
                if (onlyUns && r.Level != "warn") continue;
                if (q.Length > 0 &&
                    !(r.Name.Contains(q, StringComparison.OrdinalIgnoreCase)
                      || r.Path.Contains(q, StringComparison.OrdinalIgnoreCase)
                      || r.Company.Contains(q, StringComparison.OrdinalIgnoreCase))) continue;
                _view.Add(r);
            }
        }

        private DriverRow? Sel => List.SelectedItem as DriverRow;

        private void Ctx_Folder(object sender, RoutedEventArgs e)
        {
            if (Sel is not { Path.Length: > 0 } r || !File.Exists(r.Path)) return;
            try { Process.Start(new ProcessStartInfo("explorer.exe", $"/select,\"{r.Path}\"") { UseShellExecute = true }); } catch { }
        }

        private void Ctx_CopyPath(object sender, RoutedEventArgs e) { if (Sel is { Path.Length: > 0 } r) Copy(r.Path); }

        private void Ctx_VirusTotal(object sender, RoutedEventArgs e)
        {
            if (Sel is not { Path.Length: > 0 } r) return;
            Status.Text = "hashing…";
            Task.Run(() =>
            {
                string h = DriversList.Sha256(r.Path);
                _ui.TryEnqueue(() =>
                {
                    if (h.Length == 0) { Status.Text = "hash failed"; return; }
                    try { Process.Start(new ProcessStartInfo($"https://www.virustotal.com/gui/file/{h}") { UseShellExecute = true }); } catch { }
                    Status.Text = "opened VirusTotal";
                });
            });
        }

        private static void Copy(string text)
        {
            try { var dp = new DataPackage(); dp.SetText(text); Clipboard.SetContent(dp); } catch { }
        }

        private async void Install_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var picker = new Windows.Storage.Pickers.FileOpenPicker();
                WinRT.Interop.InitializeWithWindow.Initialize(picker, WinRT.Interop.WindowNative.GetWindowHandle(App.MainWindow));
                picker.FileTypeFilter.Add(".sys");
                var file = await picker.PickSingleFileAsync();
                if (file == null) return;
                string path = file.Path;
                Status.Text = "installing driver…";
                var (ok, msg) = await Task.Run(() => DriversList.InstallDriver(path));
                Status.Text = (ok ? "OK: " : "FAILED: ") + msg;
                if (ok) Refresh();
            }
            catch (Exception ex) { Status.Text = "install error: " + ex.Message; }
        }

        private async void Ctx_Uninstall(object sender, RoutedEventArgs e)
        {
            if (Sel is not { } r) return;
            string name = System.IO.Path.GetFileNameWithoutExtension(r.Name);
            Status.Text = "uninstalling…";
            var (ok, msg) = await Task.Run(() => DriversList.UninstallDriver(name));
            Status.Text = (ok ? "OK: " : "FAILED: ") + msg;
            if (ok) Refresh();
        }
    }
}
