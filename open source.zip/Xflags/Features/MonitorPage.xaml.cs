using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using Microsoft.UI.Dispatching;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Controls.Primitives;
using Microsoft.Win32;
using Windows.ApplicationModel.DataTransfer;
using XFlags.Services;

namespace XFlags.Features
{
    public sealed partial class MonitorPage : Page
    {
        private static readonly MonitorService Svc = new();
        private readonly ObservableCollection<MonLine> _view = new();
        private readonly List<MonLine> _all = new();
        private string _filter = "";
        private string _cat = "";
        private readonly DispatcherQueueTimer _timer;
        private static readonly Regex PidRe = new(@"\[(\d+)\]", RegexOptions.Compiled);
        private static readonly Regex WinPath = new(@"[A-Za-z]:\\[^\r\n]*", RegexOptions.Compiled);
        private static readonly Regex RegKeyRe = new(@"(HKLM|HKU|HKCU|HKCR|HKEY_[A-Z_]+)\\[^\r\n]*", RegexOptions.Compiled);

        public MonitorPage()
        {
            InitializeComponent();
            LogList.ItemsSource = _view;

            foreach (var l in Svc.Snapshot()) { _all.Add(l); if (Match(l)) _view.Add(l); }

            _timer = DispatcherQueue.CreateTimer();
            _timer.Interval = TimeSpan.FromMilliseconds(200);
            _timer.Tick += (s, e) => Drain();
            _timer.Start();
            ApplyMode();
            SyncButtons();

            Loaded += (s, e) =>
            {
                var sv = FindScrollViewer(LogList);
                if (sv != null)
                    sv.ViewChanged += (a, b) =>
                    {
                        if (sv.ScrollableHeight > 4)
                            Follow.IsChecked = sv.VerticalOffset >= sv.ScrollableHeight - 40;
                    };
                if (_view.Count > 0) LogList.ScrollIntoView(_view[^1]);
            };
        }

        private static ScrollViewer? FindScrollViewer(DependencyObject root)
        {
            if (root is ScrollViewer sv) return sv;
            int n = Microsoft.UI.Xaml.Media.VisualTreeHelper.GetChildrenCount(root);
            for (int i = 0; i < n; i++)
            {
                var r = FindScrollViewer(Microsoft.UI.Xaml.Media.VisualTreeHelper.GetChild(root, i));
                if (r != null) return r;
            }
            return null;
        }

        private void Drain()
        {
            int n = 0;
            while (n < 2000 && Svc.Queue.TryDequeue(out var line))
            {
                _all.Add(line);
                if (Match(line)) _view.Add(line);
                n++;
            }
            while (_all.Count > 100000) _all.RemoveAt(0);
            while (_view.Count > 20000) _view.RemoveAt(0);

            if (n > 0 && _view.Count > 0 && Follow.IsChecked == true) LogList.ScrollIntoView(_view[^1]);
            SyncButtons();
        }

        private bool Match(MonLine l)
        {
            if (!CatMatch(l)) return false;
            if (_filter.Length == 0) return true;
            foreach (var w in _filter.Split(' ', StringSplitOptions.RemoveEmptyEntries))
            {
                if (w.Length > 1 && w[0] == '-') { if (l.Text.Contains(w[1..], StringComparison.OrdinalIgnoreCase)) return false; }
                else if (!l.Text.Contains(w, StringComparison.OrdinalIgnoreCase)) return false;
            }
            return true;
        }

        private bool CatMatch(MonLine l)
        {
            if (_cat.Length == 0) return true;
            string op = l.Op;
            return _cat switch
            {
                "reg"   => op.StartsWith("REG", StringComparison.Ordinal) || op == "AUTORUN!",
                "file"  => op is "WRITE" or "OPEN" or "DELETE" or "RENAME" or "DLL" or "SAVED",
                "net"   => op.StartsWith("NET", StringComparison.Ordinal) || op.StartsWith("TLS", StringComparison.Ordinal) || op.StartsWith("HTTP", StringComparison.Ordinal) || op is "SNIFF" or "DNS",
                "proc"  => op.StartsWith("PROC", StringComparison.Ordinal) || op is "EXIT" or "TRACK",
                "asset" => op is "UASSET" or "PAK",
                _ => true
            };
        }

        private void Rebuild()
        {
            _view.Clear();
            foreach (var l in _all) if (Match(l)) _view.Add(l);
            if (_view.Count > 0 && Follow.IsChecked == true) LogList.ScrollIntoView(_view[^1]);
        }

        private void Cat_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not ToggleButton btn) return;
            _cat = (btn.Tag as string) ?? "";
            btn.IsChecked = true;
            if (btn.Parent is Panel p)
                foreach (var c in p.Children)
                    if (c is ToggleButton other && !ReferenceEquals(other, btn))
                        other.IsChecked = false;
            Rebuild();
        }

        private MonMode _mode = MonMode.Game;

        private void SyncButtons()
        {
            bool run = Svc.IsRunning;
            BtnStop.IsEnabled = run;
            BtnStart.IsEnabled = !run;
            BtnLaunch.IsEnabled = !run && _mode != MonMode.Network;
            Status.Text = run ? "● running" : "Idle";
        }

        private MonMode Mode() => _mode;

        private void Tab_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not ToggleButton btn) return;
            _mode = (btn.Tag as string) switch { "Program" => MonMode.Program, "Network" => MonMode.Network, _ => MonMode.Game };
            TabGame.IsChecked = _mode == MonMode.Game;
            TabProgram.IsChecked = _mode == MonMode.Program;
            TabNetwork.IsChecked = _mode == MonMode.Network;
            ApplyMode();
            SyncButtons();
        }

        private void ApplyMode()
        {
            bool game = _mode == MonMode.Game, net = _mode == MonMode.Network;
            TargetRow.Visibility = net ? Visibility.Collapsed : Visibility.Visible;
            UeArgs.Visibility = game ? Visibility.Visible : Visibility.Collapsed;
            AutoUe.Visibility = game ? Visibility.Visible : Visibility.Collapsed;
            UeLog.Visibility = game ? Visibility.Visible : Visibility.Collapsed;
            VerboseBox.Visibility = net ? Visibility.Collapsed : Visibility.Visible;
            CaptureBox.Visibility = net ? Visibility.Collapsed : Visibility.Visible;
            NetNote.Visibility = net ? Visibility.Visible : Visibility.Collapsed;
            BtnLaunch.Visibility = net ? Visibility.Collapsed : Visibility.Visible;
        }

        private List<string> ParseTargets()
        {
            var list = new List<string>();
            foreach (var part in (Targets.Text ?? "").Split(new[] { ';', ',' }, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
            {
                string n = Path.GetFileName(part.Trim('"'));
                if (n.Length == 0) continue;
                if (!n.EndsWith(".exe", StringComparison.OrdinalIgnoreCase)) n += ".exe";
                if (!list.Contains(n, StringComparer.OrdinalIgnoreCase)) list.Add(n);
            }
            return list;
        }

        private void Start_Click(object sender, RoutedEventArgs e)
        {
            _all.Clear(); _view.Clear();
            var mode = Mode();
            var targets = ParseTargets();
            bool autoUe = mode == MonMode.Game && AutoUe.IsChecked == true;
            if (mode != MonMode.Network && targets.Count == 0 && !autoUe)
            {
                Svc.Queue.Enqueue(new MonLine { Color = "info", Op = "INFO", Text = "enter exe name(s), enable Auto UE, or use Network mode" });
                return;
            }
            Svc.Verbose = VerboseBox.IsChecked == true;
            Svc.CaptureFiles = CaptureBox.IsChecked == true;
            Svc.Start(mode, targets, autoUe, UeLog.IsChecked == true, UeArgs.Text ?? "");
            SyncButtons();
        }

        private async void Launch_Click(object sender, RoutedEventArgs e)
        {
            var picker = new Windows.Storage.Pickers.FileOpenPicker();
            WinRT.Interop.InitializeWithWindow.Initialize(picker, WinRT.Interop.WindowNative.GetWindowHandle(App.MainWindow));
            picker.FileTypeFilter.Add(".exe");
            var file = await picker.PickSingleFileAsync();
            if (file == null) return;
            _all.Clear(); _view.Clear();
            var targets = ParseTargets();
            string name = Path.GetFileName(file.Path);
            if (!targets.Contains(name, StringComparer.OrdinalIgnoreCase)) targets.Add(name);
            Svc.Verbose = VerboseBox.IsChecked == true;
            Svc.CaptureFiles = CaptureBox.IsChecked == true;
            Svc.Start(Mode(), targets, Mode() == MonMode.Game && AutoUe.IsChecked == true, UeLog.IsChecked == true, UeArgs.Text ?? "", file.Path);
            SyncButtons();
        }

        private void Stop_Click(object sender, RoutedEventArgs e) { Svc.Stop(); SyncButtons(); }
        private void Summary_Click(object sender, RoutedEventArgs e) => Svc.Summary();
        private void Clear_Click(object sender, RoutedEventArgs e) { _all.Clear(); _view.Clear(); }
        private void Filter_Changed(object sender, TextChangedEventArgs e) { _filter = Filter.Text ?? ""; Rebuild(); }

        private void Domains_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Directory.CreateDirectory(MonitorService.LogDir);
                string path = Path.Combine(MonitorService.LogDir, $"domains_{DateTime.Now:yyyyMMdd_HHmmss}.txt");
                using (var w = new StreamWriter(path))
                    foreach (var kv in Svc.DomainsByApp()) { w.WriteLine(); w.WriteLine($"{kv.Key}  ({kv.Value.Count})"); foreach (var h in kv.Value) w.WriteLine("    " + h); }
                OpenFile(path);
            }
            catch { }
        }

        private void Report_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Directory.CreateDirectory(MonitorService.LogDir);
                string path = Path.Combine(MonitorService.LogDir, $"report_{DateTime.Now:yyyyMMdd_HHmmss}.txt");
                using (var w = new StreamWriter(path)) foreach (var l in _view) w.WriteLine(l.Text);
                OpenFile(path);
            }
            catch { }
        }

        private void Block_Click(object sender, RoutedEventArgs e)
        {
            var path = SelectedPath();
            if (path != null) MonitorService.Block(path);
        }

        private void Unblock_Click(object sender, RoutedEventArgs e)
        {
            var path = SelectedPath();
            if (path != null) MonitorService.Unblock(Path.GetFileName(path));
        }

        private void Log_DoubleTapped(object sender, Microsoft.UI.Xaml.Input.DoubleTappedRoutedEventArgs e)
        {
            if (LogList.SelectedItem is not MonLine l) return;
            if (OpenLineFile(l)) return;
            string? key = RegKeyIn(l);
            if (key != null) OpenRegedit(key);
        }

        private void Ctx_Open(object sender, RoutedEventArgs e)
        {
            if (LogList.SelectedItem is MonLine l) OpenLineFile(l);
        }

        private void Ctx_Folder(object sender, RoutedEventArgs e)
        {
            if (LogList.SelectedItem is not MonLine l) return;
            string? p = ResolveExisting(l);
            if (p == null) return;
            try { Process.Start(new ProcessStartInfo("explorer.exe", $"/select,\"{p}\"") { UseShellExecute = true }); } catch { }
        }

        private void Ctx_Regedit(object sender, RoutedEventArgs e)
        {
            if (LogList.SelectedItem is not MonLine l) return;
            string? key = RegKeyIn(l);
            if (key != null) OpenRegedit(key);
        }

        private void Ctx_Copy(object sender, RoutedEventArgs e)
        {
            if (LogList.SelectedItem is not MonLine l) return;
            try { var dp = new DataPackage(); dp.SetText(l.Text); Clipboard.SetContent(dp); } catch { }
        }

        private bool OpenLineFile(MonLine l)
        {
            string? p = ResolveExisting(l);
            if (p == null) return false;
            OpenFile(p);
            return true;
        }

        private string? ResolveExisting(MonLine l)
        {
            string? p = FilePathIn(l);
            if (p == null) return null;
            try { if (File.Exists(p)) return p; } catch { }
            var copy = Svc.CapturedCopy(p);
            if (!string.IsNullOrEmpty(copy) && File.Exists(copy)) return copy;

            try { if (File.Exists(p)) return p; } catch { }
            return null;
        }

        private static string? FilePathIn(MonLine l)
        {
            var m = WinPath.Match(l.Text);
            if (!m.Success) return null;
            string p = m.Value.Trim();
            int tag = p.IndexOf("   [saved copy kept]", StringComparison.Ordinal);
            if (tag >= 0) p = p[..tag].Trim();

            int arrow = p.IndexOf(" -> ", StringComparison.Ordinal);
            if (arrow >= 0) { var d = WinPath.Match(p[(arrow + 4)..]); if (d.Success) p = d.Value.Trim(); }
            return p.Length > 3 ? p : null;
        }

        private static string? RegKeyIn(MonLine l)
        {
            var m = RegKeyRe.Match(l.Text);
            if (!m.Success) return null;
            string key = m.Value.Trim();
            int b = key.IndexOf("  [", StringComparison.Ordinal);
            if (b >= 0) key = key[..b];
            int eq = key.IndexOf(" = ", StringComparison.Ordinal);
            if (eq >= 0) key = key[..eq];
            return key.Trim();
        }

        private static void OpenRegedit(string key)
        {
            try
            {
                string full = key;
                if (key.StartsWith("HKLM\\", StringComparison.OrdinalIgnoreCase)) full = "HKEY_LOCAL_MACHINE\\" + key[5..];
                else if (key.StartsWith("HKU\\", StringComparison.OrdinalIgnoreCase)) full = "HKEY_USERS\\" + key[4..];
                else if (key.StartsWith("HKCU\\", StringComparison.OrdinalIgnoreCase)) full = "HKEY_CURRENT_USER\\" + key[5..];
                else if (key.StartsWith("HKCR\\", StringComparison.OrdinalIgnoreCase)) full = "HKEY_CLASSES_ROOT\\" + key[5..];

                using (var rk = Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\Windows\CurrentVersion\Applets\Regedit"))
                    rk?.SetValue("LastKey", "Computer\\" + full, RegistryValueKind.String);

                foreach (var pr in Process.GetProcessesByName("regedit")) { try { pr.Kill(); pr.WaitForExit(1500); } catch { } }
                Process.Start(new ProcessStartInfo("regedit.exe") { UseShellExecute = true });
            }
            catch { }
        }

        private string? SelectedPath()
        {
            if (LogList.SelectedItem is not MonLine l) return null;
            var m = PidRe.Match(l.Text);
            if (!m.Success || !int.TryParse(m.Groups[1].Value, out int pid)) return null;
            var p = Svc.PathForPid(pid);
            if (p != null) return p;
            try { return Process.GetProcessById(pid).MainModule?.FileName; } catch { return null; }
        }

        private static void OpenFile(string path)
        {
            try { Process.Start(new ProcessStartInfo(path) { UseShellExecute = true }); } catch { }
        }
    }
}
