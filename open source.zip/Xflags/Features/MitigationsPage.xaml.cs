using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using XFlags.Common;
using XFlags.Services;

namespace XFlags.Features
{
    public sealed partial class MitigationsPage : Page
    {
        private readonly Dictionary<MitigationOption, ComboBox> _mit = new();
        private readonly Dictionary<FlagOption, ComboBox> _extra = new();
        private List<string> _all = new();
        private HashSet<string> _configured = new();
        private string? _selected;

        public MitigationsPage()
        {
            InitializeComponent();
            BuildRows();
            Reload();
        }

        private void Reload()
        {
            _all = IfeoManager.GetProcessNames(RbRunning.IsChecked == true);
            _configured = IfeoManager.GetConfigured();
            ApplyFilter(reselect: true);
        }

        private void ApplyFilter(bool reselect = false)
        {
            string q = SearchBox.Text?.Trim() ?? "";
            string? want = reselect ? _selected : null;
            ProcList.Items.Clear();
            object? sel = null;
            foreach (var n in _all)
                if (q.Length == 0 || n.Contains(q, StringComparison.OrdinalIgnoreCase))
                {
                    string label = _configured.Contains(n) ? "● " + n : n;
                    ProcList.Items.Add(label);
                    if (want != null && n.Equals(want, StringComparison.OrdinalIgnoreCase)) sel = label;
                }
            if (sel != null) ProcList.SelectedItem = sel;
        }

        private static string Clean(string s) => s.StartsWith("● ") ? s[2..] : s;

        private void Search_Changed(object sender, TextChangedEventArgs e) => ApplyFilter();
        private void Source_Changed(object sender, RoutedEventArgs e) { if (IsLoaded) Reload(); }

        private void Proc_Changed(object sender, SelectionChangedEventArgs e)
        {
            if (ProcList.SelectedItem is not string item) return;
            string proc = Clean(item);
            _selected = proc;
            SelInfo.Text = proc;

            long mask = IfeoManager.Get(proc)?.MitigationOptions ?? 0L;
            foreach (var (m, cb) in _mit)
                cb.SelectedIndex = (mask & m.AlwaysOn) != 0 ? 1 : (mask & m.AlwaysOff) != 0 ? 2 : 0;
            foreach (var (f, cb) in _extra)
                cb.SelectedIndex = (mask & f.Hex) != 0 ? 1 : 0;

            var (running, info) = ProcessMitigations.Read(proc);
            ActiveInfo.Text = running ? "ACTIVE IN PROCESS:  " + info : info;
        }

        private void BuildRows()
        {
            AddHeader("Policies");
            foreach (var m in IfeoData.Mitigations)
                _mit[m] = AddRow(m.Abbreviation, m.Description, threeState: true);
            AddHeader("Extra (enable only)");
            foreach (var f in IfeoData.Extra)
                _extra[f] = AddRow(f.Abbreviation, f.Description, threeState: false);
        }

        private void AddHeader(string text)
        {
            MitList.Children.Add(new TextBlock
            {
                Text = text,
                FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
                Margin = new Thickness(0, 10, 0, 0),
                Foreground = UiBrush.Accent
            });
        }

        private ComboBox AddRow(string name, string desc, bool threeState)
        {
            var card = new Border
            {
                Background = UiBrush.Card,
                BorderBrush = UiBrush.Stroke,
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(14)
            };
            var grid = new Grid { ColumnSpacing = 12 };
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(140) });

            var texts = new StackPanel { Spacing = 2 };
            texts.Children.Add(new TextBlock { Text = name, FontWeight = Microsoft.UI.Text.FontWeights.SemiBold });
            texts.Children.Add(new TextBlock { Text = desc, Foreground = UiBrush.Secondary, TextWrapping = TextWrapping.Wrap, FontSize = 12 });
            Grid.SetColumn(texts, 0);
            grid.Children.Add(texts);

            var combo = new ComboBox { HorizontalAlignment = HorizontalAlignment.Stretch };
            combo.Items.Add("Default");
            combo.Items.Add("On");
            if (threeState) combo.Items.Add("Off");
            combo.SelectedIndex = 0;
            Grid.SetColumn(combo, 1);
            grid.Children.Add(combo);

            card.Child = grid;
            MitList.Children.Add(card);
            return combo;
        }

        private long BuildMask()
        {
            long mask = 0;
            foreach (var (m, cb) in _mit)
            {
                if (cb.SelectedIndex == 1) mask |= m.AlwaysOn;
                else if (cb.SelectedIndex == 2) mask |= m.AlwaysOff;
            }
            foreach (var (f, cb) in _extra) if (cb.SelectedIndex == 1) mask |= f.Hex;
            return mask;
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (_selected == null) return;
            var cfg = IfeoManager.Get(_selected) ?? new IfeoConfig();
            long mask = BuildMask();
            cfg.MitigationOptions = mask == 0 ? (long?)null : mask;
            IfeoManager.Set(_selected, cfg);
            Reload();
        }

        private void Reset_Click(object sender, RoutedEventArgs e)
        {
            if (_selected == null) return;
            IfeoManager.Delete(_selected);
            foreach (var cb in _mit.Values) cb.SelectedIndex = 0;
            foreach (var cb in _extra.Values) cb.SelectedIndex = 0;
            Reload();
        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            foreach (var cb in _mit.Values) cb.SelectedIndex = 0;
            foreach (var cb in _extra.Values) cb.SelectedIndex = 0;
        }
    }
}
