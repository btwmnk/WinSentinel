using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.UI.Dispatching;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.Win32;
using Windows.ApplicationModel.DataTransfer;
using XFlags.Services;

namespace XFlags.Features
{
    public sealed partial class AutorunsPage : Page
    {
        private readonly List<AutorunRow> _all = new();
        private readonly System.Collections.ObjectModel.ObservableCollection<AutorunRow> _view = new();
        private readonly DispatcherQueue _ui;
        private CancellationTokenSource? _cts;
        private string _section = "All";
        private bool _buildingSections;

        public AutorunsPage()
        {
            InitializeComponent();
            _ui = DispatcherQueue.GetForCurrentThread();
            List.ItemsSource = _view;
            Loaded += (s, e) => { if (_all.Count == 0) Scan(); };
        }

        private void Scan_Click(object sender, RoutedEventArgs e) => Scan();

        private void Scan()
        {
            _cts?.Cancel();
            _cts = new CancellationTokenSource();
            var token = _cts.Token;
            BtnScan.IsEnabled = false;
            Status.Text = "scanning autoruns…";
            _all.Clear();

            Task.Run(() =>
            {
                var rows = Autoruns.Scan();
                int sus = rows.Count(r => r.Level != "ok" && r.Level != "off");
                _ui.TryEnqueue(() =>
                {
                    if (token.IsCancellationRequested) return;
                    _all.AddRange(rows);
                    ApplyFilter();
                    Status.Text = $"{rows.Count} entries · {sus} flagged";
                    BtnScan.IsEnabled = true;
                    LoadIcons(new List<AutorunRow>(rows), token);
                });
            }, token);
        }

        private readonly System.Collections.Concurrent.ConcurrentDictionary<string, Microsoft.UI.Xaml.Media.ImageSource?> _iconCache = new(StringComparer.OrdinalIgnoreCase);

        private void LoadIcons(List<AutorunRow> rows, CancellationToken token)
        {
            Task.Run(async () =>
            {
                foreach (var r in rows)
                {
                    if (token.IsCancellationRequested) return;
                    string key = r.Path;
                    if (key.Length == 0) continue;

                    if (_iconCache.TryGetValue(key, out var have)) { if (have != null) _ui.TryEnqueue(() => r.Icon = have); continue; }

                    byte[]? png = IconUtil.PngBytes(key);
                    if (png == null) { _iconCache[key] = null; continue; }

                    var tcs = new TaskCompletionSource();
                    _ui.TryEnqueue(async () =>
                    {
                        try
                        {
                            var bi = new Microsoft.UI.Xaml.Media.Imaging.BitmapImage();
                            using var ras = new Windows.Storage.Streams.InMemoryRandomAccessStream();
                            using (var dw = new Windows.Storage.Streams.DataWriter(ras)) { dw.WriteBytes(png); await dw.StoreAsync(); await dw.FlushAsync(); dw.DetachStream(); }
                            ras.Seek(0);
                            await bi.SetSourceAsync(ras);
                            _iconCache[key] = bi;
                            r.Icon = bi;
                        }
                        catch { }
                        finally { tcs.TrySetResult(); }
                    });
                    await tcs.Task;
                }
            }, token);
        }

        private static int Rank(AutorunRow r) => r.Level == "bad" ? 2 : r.Level == "warn" ? 1 : 0;

        private void Filter_Changed(object sender, TextChangedEventArgs e) => ApplyFilter();
        private void Filter_Toggle(object sender, RoutedEventArgs e) => ApplyFilter();

        private List<AutorunRow> Kept()
        {
            string q = Filter.Text?.Trim() ?? "";
            bool onlySus = OnlySus.IsChecked == true;
            bool hideSigned = HideSigned.IsChecked == true;
            bool hideNoFile = HideNoFile.IsChecked == true;
            var kept = new List<AutorunRow>();
            foreach (var r in _all)
            {
                if (onlySus && (r.Level == "ok" || r.Level == "off")) continue;
                if (hideSigned && (r.Status == SigStatus.Signed || r.Status == SigStatus.Catalog) && r.Level == "ok") continue;
                if (hideNoFile && r.Status == SigStatus.NoPath) continue;
                if (q.Length > 0 &&
                    !(r.Name.Contains(q, StringComparison.OrdinalIgnoreCase)
                      || r.Command.Contains(q, StringComparison.OrdinalIgnoreCase)
                      || r.Category.Contains(q, StringComparison.OrdinalIgnoreCase)
                      || r.Description.Contains(q, StringComparison.OrdinalIgnoreCase)
                      || r.Path.Contains(q, StringComparison.OrdinalIgnoreCase))) continue;
                kept.Add(r);
            }
            return kept;
        }

        private void ApplyFilter()
        {
            var kept = Kept();
            BuildSections(kept);
            PopulateRight(kept);
        }

        private void BuildSections(List<AutorunRow> kept)
        {
            var counts = new Dictionary<string, int>();
            foreach (var r in kept) counts[r.Group] = counts.TryGetValue(r.Group, out var c) ? c + 1 : 1;

            var labels = new List<string> { $"All  ({kept.Count})" };
            foreach (var key in Autoruns.GroupOrder)
                if (counts.TryGetValue(key, out var c) && c > 0) labels.Add($"{key}  ({c})");

            _buildingSections = true;
            SectionList.Items.Clear();
            foreach (var l in labels) SectionList.Items.Add(l);
            int sel = 0;
            for (int i = 0; i < labels.Count; i++) if (SectionKey(labels[i]) == _section) { sel = i; break; }
            SectionList.SelectedIndex = sel;
            _section = SectionKey(labels[sel]);
            _buildingSections = false;
        }

        private static string SectionKey(string label)
        {
            int p = label.LastIndexOf("  (", StringComparison.Ordinal);
            return p > 0 ? label[..p] : label;
        }

        private void Section_Changed(object sender, SelectionChangedEventArgs e)
        {
            if (_buildingSections) return;
            if (SectionList.SelectedItem is string s) { _section = SectionKey(s); PopulateRight(Kept()); }
        }

        private void PopulateRight(List<AutorunRow> kept)
        {
            IEnumerable<AutorunRow> src = _section == "All" ? kept : kept.Where(r => r.Group == _section);
            var ordered = src.OrderByDescending(Rank)
                             .ThenBy(r => r.Category, StringComparer.OrdinalIgnoreCase)
                             .ThenBy(r => r.Name, StringComparer.OrdinalIgnoreCase);
            _view.Clear();
            foreach (var r in ordered) _view.Add(r);
        }

        private AutorunRow? Sel => List.SelectedItem as AutorunRow;

        private void Ctx_Disable(object sender, RoutedEventArgs e) => SetEnabled(false);
        private void Ctx_Enable(object sender, RoutedEventArgs e) => SetEnabled(true);

        private void SetEnabled(bool enable)
        {
            if (Sel is not { } r) return;
            if (r.Toggle == ToggleKind.None) { Status.Text = "эту запись нельзя выключить обратимо — используй Delete или правь вручную"; return; }
            if (Autoruns.SetEnabled(r, enable))
            {
                var parts = r.Flags.Split(", ", StringSplitOptions.RemoveEmptyEntries).Where(x => x != "DISABLED").ToList();
                if (!enable) parts.Insert(0, "DISABLED");
                r.Flags = string.Join(", ", parts);
                r.Refresh();
                Status.Text = enable ? $"enabled: {r.Name}" : $"disabled: {r.Name}";
            }
            else Status.Text = "не удалось изменить (нет прав или запись уже изменена)";
        }

        private void Ctx_Folder(object sender, RoutedEventArgs e) { if (Sel is { } r) OpenFolder(r); }

        private static void OpenFolder(AutorunRow r)
        {
            if (r.Path.Length == 0 || !File.Exists(r.Path)) return;
            try { Process.Start(new ProcessStartInfo("explorer.exe", $"/select,\"{r.Path}\"") { UseShellExecute = true }); } catch { }
        }

        private void Row_DoubleTapped(object sender, Microsoft.UI.Xaml.Input.DoubleTappedRoutedEventArgs e)
        {
            var r = Sel;
            if (r == null) return;
            if (r.Path.Length > 0 && File.Exists(r.Path)) OpenFolder(r);
            else if (r.Kind == AutorunKind.RegValue) OpenRegedit(r);
        }

        private void Ctx_Regedit(object sender, RoutedEventArgs e) { if (Sel is { Kind: AutorunKind.RegValue } r) OpenRegedit(r); }

        private static void OpenRegedit(AutorunRow r)
        {
            if (r.Root == null) return;
            string root = r.Root == Registry.LocalMachine ? "HKEY_LOCAL_MACHINE"
                        : r.Root == Registry.CurrentUser ? "HKEY_CURRENT_USER"
                        : r.Root == Registry.Users ? "HKEY_USERS"
                        : r.Root == Registry.ClassesRoot ? "HKEY_CLASSES_ROOT" : "HKEY_CURRENT_USER";
            try
            {
                using (var rk = Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\Windows\CurrentVersion\Applets\Regedit"))
                    rk?.SetValue("LastKey", $"Computer\\{root}\\{r.SubKey}", RegistryValueKind.String);
                foreach (var pr in Process.GetProcessesByName("regedit")) { try { pr.Kill(); pr.WaitForExit(1500); } catch { } }
                Process.Start(new ProcessStartInfo("regedit.exe") { UseShellExecute = true });
            }
            catch { }
        }

        private void Ctx_CopyCmd(object sender, RoutedEventArgs e) { if (Sel is { } r) Copy(r.Command); }

        private void Ctx_CopyHash(object sender, RoutedEventArgs e)
        {
            if (Sel is not { Path.Length: > 0 } r) return;
            Status.Text = "hashing…";
            Task.Run(() => { string h = ProcessList.Sha256(r.Path); _ui.TryEnqueue(() => { if (h.Length > 0) { Copy(h); Status.Text = "SHA-256 copied"; } else Status.Text = "hash failed"; }); });
        }

        private void Ctx_VirusTotal(object sender, RoutedEventArgs e)
        {
            if (Sel is not { Path.Length: > 0 } r) return;
            Status.Text = "hashing for VirusTotal…";
            Task.Run(() =>
            {
                string h = ProcessList.Sha256(r.Path);
                _ui.TryEnqueue(() =>
                {
                    if (h.Length == 0) { Status.Text = "hash failed"; return; }
                    try { Process.Start(new ProcessStartInfo($"https://www.virustotal.com/gui/file/{h}") { UseShellExecute = true }); } catch { }
                    Status.Text = "opened VirusTotal";
                });
            });
        }

        private void Ctx_Delete(object sender, RoutedEventArgs e)
        {
            if (Sel is not { } r) return;
            if (r.Kind == AutorunKind.Other) { Status.Text = "эту запись (служба/Winlogon/задача) удаляй вручную — небезопасно автоматически"; return; }
            if (Autoruns.Delete(r)) { _all.Remove(r); ApplyFilter(); Status.Text = $"deleted autorun: {r.Name}"; }
            else Status.Text = "delete failed (нет прав или уже удалено)";
        }

        private static void Copy(string text)
        {
            try { var dp = new DataPackage(); dp.SetText(text); Clipboard.SetContent(dp); } catch { }
        }
    }
}
