using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using Microsoft.UI.Dispatching;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Windows.ApplicationModel.DataTransfer;
using XFlags.Services;

namespace XFlags.Features
{
    public sealed partial class DefenderPage : Page
    {
        private readonly ObservableCollection<DefExclusion> _view = new();
        private readonly DispatcherQueue _ui;

        public DefenderPage()
        {
            InitializeComponent();
            _ui = DispatcherQueue.GetForCurrentThread();
            List.ItemsSource = _view;
            Loaded += (s, e) => Refresh();
        }

        private void Refresh_Click(object sender, RoutedEventArgs e) => Refresh();

        private void Refresh()
        {
            BtnRefresh.IsEnabled = false;
            Status.Text = "querying Defender…";
            StatusLine.Text = "…";
            _view.Clear();

            Task.Run(() =>
            {
                var d = DefenderInfo.Scan();
                _ui.TryEnqueue(() =>
                {
                    if (d.Error.Length > 0 && !d.Loaded)
                        StatusLine.Text = "Не удалось получить данные Defender: " + d.Error;
                    else
                    {
                        string On(bool b) => b ? "ON" : "OFF";
                        StatusLine.Text =
                            $"Antivirus: {On(d.AntivirusEnabled)}    Real-time: {On(d.RealTime)}    Tamper Protection: {On(d.TamperProtected)}";
                    }
                    foreach (var ex in d.Exclusions) _view.Add(ex);
                    Status.Text = $"{d.Exclusions.Count} exclusions";
                    BtnRefresh.IsEnabled = true;
                });
            });
        }

        private string KindText()
        {
            return (KindBox.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Path";
        }

        private async void Browse_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var picker = new Windows.Storage.Pickers.FileOpenPicker();
                WinRT.Interop.InitializeWithWindow.Initialize(picker, WinRT.Interop.WindowNative.GetWindowHandle(App.MainWindow));
                picker.FileTypeFilter.Add("*");
                var file = await picker.PickSingleFileAsync();
                if (file != null)
                {
                    AddValue.Text = file.Path;
                    KindBox.SelectedIndex = file.Path.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) ? 1 : 0;
                }
            }
            catch { }
        }

        private async void BrowseFolder_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var picker = new Windows.Storage.Pickers.FolderPicker();
                WinRT.Interop.InitializeWithWindow.Initialize(picker, WinRT.Interop.WindowNative.GetWindowHandle(App.MainWindow));
                picker.FileTypeFilter.Add("*");
                var folder = await picker.PickSingleFolderAsync();
                if (folder != null) { AddValue.Text = folder.Path; KindBox.SelectedIndex = 0; }
            }
            catch { }
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            string kind = KindText();
            string val = AddValue.Text?.Trim() ?? "";
            if (val.Length == 0) { Status.Text = "введи значение"; return; }
            Status.Text = "adding…";
            Task.Run(() =>
            {
                var (ok, msg) = DefenderInfo.AddExclusion(kind, val);
                _ui.TryEnqueue(() =>
                {
                    Status.Text = ok ? $"added {kind}: {val}" : "add failed: " + msg;
                    if (ok) { AddValue.Text = ""; Refresh(); }
                });
            });
        }

        private void Remove_Click(object sender, RoutedEventArgs e)
        {
            if (List.SelectedItem is not DefExclusion ex) return;
            Status.Text = "removing…";
            Task.Run(() =>
            {
                var (ok, msg) = DefenderInfo.RemoveExclusion(ex.Kind, ex.Value);
                _ui.TryEnqueue(() =>
                {
                    Status.Text = ok ? $"removed {ex.Kind}: {ex.Value}" : "remove failed: " + msg;
                    if (ok) Refresh();
                });
            });
        }

        private void Copy_Click(object sender, RoutedEventArgs e)
        {
            if (List.SelectedItem is not DefExclusion ex) return;
            try { var dp = new DataPackage(); dp.SetText(ex.Value); Clipboard.SetContent(dp); } catch { }
        }
    }
}
