using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.UI.Dispatching;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using XFlags.Services;

namespace XFlags.Features
{
    public sealed partial class InjectionPage : Page
    {
        private readonly ObservableCollection<InjRow> _view = new();
        private readonly List<InjRow> _all = new();
        private readonly DispatcherQueue _ui;
        private CancellationTokenSource? _cts;

        public InjectionPage()
        {
            InitializeComponent();
            _ui = DispatcherQueue.GetForCurrentThread();
            List.ItemsSource = _view;
        }

        private void Refresh_Click(object sender, RoutedEventArgs e) => Refresh();

        private void Refresh()
        {
            _cts?.Cancel();
            _cts = new CancellationTokenSource();
            var token = _cts.Token;
            BtnRefresh.IsEnabled = false;
            Status.Text = "scanning memory…";
            _all.Clear(); _view.Clear();

            Task.Run(() =>
            {
                var rows = MemoryScan.Scan();
                int bad = rows.Count(r => r.Level == "bad");
                _ui.TryEnqueue(() =>
                {
                    if (token.IsCancellationRequested) return;
                    _all.AddRange(rows);
                    ApplyFilter();
                    Status.Text = $"{rows.Count} exec-private regions · {bad} RWX";
                    BtnRefresh.IsEnabled = true;
                });
            }, token);
        }

        private void Filter_Changed(object sender, TextChangedEventArgs e) => ApplyFilter();
        private void Filter_Toggle(object sender, RoutedEventArgs e) => ApplyFilter();

        private void ApplyFilter()
        {
            string q = Filter.Text?.Trim() ?? "";
            bool rwx = OnlyRwx.IsChecked == true;
            _view.Clear();
            foreach (var r in _all)
            {
                if (rwx && !r.Rwx) continue;
                if (q.Length > 0 && !(r.Proc.Contains(q, StringComparison.OrdinalIgnoreCase) || r.Pid.ToString().Contains(q))) continue;
                _view.Add(r);
            }
        }

        private InjRow? Sel => List.SelectedItem as InjRow;

        private void Ctx_Folder(object sender, RoutedEventArgs e)
        {
            if (Sel is not { Path.Length: > 0 } r || !File.Exists(r.Path)) return;
            try { Process.Start(new ProcessStartInfo("explorer.exe", $"/select,\"{r.Path}\"") { UseShellExecute = true }); } catch { }
        }

        private void Ctx_VirusTotal(object sender, RoutedEventArgs e)
        {
            if (Sel is not { Path.Length: > 0 } r) return;
            Status.Text = "hashing…";
            Task.Run(() =>
            {
                string h = MemoryScan.Sha256(r.Path);
                _ui.TryEnqueue(() =>
                {
                    if (h.Length == 0) { Status.Text = "hash failed"; return; }
                    try { Process.Start(new ProcessStartInfo($"https://www.virustotal.com/gui/file/{h}") { UseShellExecute = true }); } catch { }
                    Status.Text = "opened VirusTotal";
                });
            });
        }

        private void Ctx_Kill(object sender, RoutedEventArgs e)
        {
            if (Sel is not { } r) return;
            if (MemoryScan.Kill(r.Pid))
            {
                foreach (var x in _all.Where(c => c.Pid == r.Pid).ToList()) { _all.Remove(x); _view.Remove(x); }
                Status.Text = $"ended {r.Proc} [{r.Pid}]";
            }
            else Status.Text = $"could not end [{r.Pid}]";
        }
    }
}
