using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;

namespace XFlags.Features
{
    public sealed partial class HostsPage : Page
    {
        private static string HostsPath => Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.System), "drivers", "etc", "hosts");

        public HostsPage()
        {
            InitializeComponent();
            Loaded += (s, e) => Load();
        }

        private void Reload_Click(object sender, RoutedEventArgs e) => Load();

        private void Load()
        {
            try
            {
                string text = File.Exists(HostsPath) ? File.ReadAllText(HostsPath) : "";
                Editor.Text = text;

                int active = 0, suspicious = 0;
                foreach (var raw in text.Split('\n'))
                {
                    string line = raw.Trim();
                    if (line.Length == 0 || line.StartsWith("#")) continue;
                    active++;
                    string ip = line.Split(new[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries).FirstOrDefault() ?? "";
                    if (ip != "127.0.0.1" && ip != "0.0.0.0" && ip != "::1") suspicious++;
                }
                Status.Text = suspicious > 0
                    ? $"{active} active entries · ⚠ {suspicious} redirect(s) not to localhost"
                    : $"{active} active entries";
            }
            catch (Exception ex) { Status.Text = "load error: " + ex.Message; }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (File.Exists(HostsPath))
                    File.Copy(HostsPath, HostsPath + ".xflags.bak", true);
                File.WriteAllText(HostsPath, Editor.Text);
                Status.Text = "saved (backup: hosts.xflags.bak)";
            }
            catch (Exception ex) { Status.Text = "save error (запусти от администратора): " + ex.Message; }
        }

        private void OpenFolder_Click(object sender, RoutedEventArgs e)
        {
            try { Process.Start(new ProcessStartInfo("explorer.exe", $"/select,\"{HostsPath}\"") { UseShellExecute = true }); } catch { }
        }
    }
}
