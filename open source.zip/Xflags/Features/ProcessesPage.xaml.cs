using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.UI.Dispatching;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Windows.ApplicationModel.DataTransfer;
using XFlags.Services;

namespace XFlags.Features
{
    public sealed partial class ProcessesPage : Page
    {
        private readonly ObservableCollection<ProcRow> _view = new();
        private readonly List<ProcRow> _all = new();
        private readonly DispatcherQueue _ui;
        private CancellationTokenSource? _cts;

        public ProcessesPage()
        {
            InitializeComponent();
            _ui = DispatcherQueue.GetForCurrentThread();
            ProcListView.ItemsSource = _view;
            Loaded += (s, e) => { if (_all.Count == 0) Refresh(); };
        }

        private void Refresh_Click(object sender, RoutedEventArgs e) => Refresh();

        private void Refresh()
        {
            _cts?.Cancel();
            _cts = new CancellationTokenSource();
            var token = _cts.Token;

            BtnRefresh.IsEnabled = false;
            Status.Text = "enumerating…";
            _all.Clear(); _view.Clear();

            Task.Run(() =>
            {

                var rows = ProcessList.Enumerate();
                rows.Sort((a, b) => string.Compare(a.Name, b.Name, StringComparison.OrdinalIgnoreCase));
                _ui.TryEnqueue(() =>
                {
                    if (token.IsCancellationRequested) return;
                    _all.AddRange(rows);
                    ApplyFilter();
                    Status.Text = $"{rows.Count} processes · verifying signatures…";
                });

                int done = 0, sus = 0;
                Parallel.ForEach(rows, new ParallelOptions { MaxDegreeOfParallelism = 4, CancellationToken = token }, r =>
                {
                    if (token.IsCancellationRequested) return;
                    ProcessList.Verify(r);
                    int d = Interlocked.Increment(ref done);
                    if (r.Level != "ok") Interlocked.Increment(ref sus);
                    if (d % 15 == 0 || d == rows.Count)
                        _ui.TryEnqueue(() => { if (!token.IsCancellationRequested) Status.Text = $"{rows.Count} processes · checked {d}/{rows.Count}"; });
                });

                _ui.TryEnqueue(() =>
                {
                    if (token.IsCancellationRequested) return;

                    _all.Sort((a, b) => Rank(b).CompareTo(Rank(a)) is int c and not 0 ? c : string.Compare(a.Name, b.Name, StringComparison.OrdinalIgnoreCase));
                    ApplyFilter();
                    Status.Text = $"{rows.Count} processes · {sus} flagged";
                    BtnRefresh.IsEnabled = true;
                });
            }, token);
        }

        private static int Rank(ProcRow r) => r.Level == "bad" ? 2 : r.Level == "warn" ? 1 : 0;

        private void Filter_Changed(object sender, TextChangedEventArgs e) => ApplyFilter();
        private void Filter_Toggle(object sender, RoutedEventArgs e) => ApplyFilter();

        private void ApplyFilter()
        {
            _view.Clear();
            if (TreeMode.IsChecked == true) { BuildTree(); return; }

            string q = Filter.Text?.Trim() ?? "";
            bool onlyUnsigned = OnlyUnsigned.IsChecked == true;
            bool onlySus = OnlySus.IsChecked == true;
            foreach (var r in _all)
            {
                r.Depth = 0;
                if (onlyUnsigned && r.Status != SigStatus.Unsigned && r.Status != SigStatus.Untrusted) continue;
                if (onlySus && r.Level == "ok") continue;
                if (q.Length > 0 &&
                    !(r.Name.Contains(q, StringComparison.OrdinalIgnoreCase)
                      || r.Path.Contains(q, StringComparison.OrdinalIgnoreCase)
                      || r.Company.Contains(q, StringComparison.OrdinalIgnoreCase)
                      || r.Pid.ToString().Contains(q))) continue;
                _view.Add(r);
            }
        }

        private void BuildTree()
        {
            var byId = new Dictionary<int, ProcRow>();
            foreach (var r in _all) byId[r.Pid] = r;

            var children = new Dictionary<int, List<ProcRow>>();
            var hasParent = new HashSet<int>();
            foreach (var r in _all)
            {
                if (r.Ppid != r.Pid && byId.ContainsKey(r.Ppid))
                {
                    if (!children.TryGetValue(r.Ppid, out var l)) children[r.Ppid] = l = new List<ProcRow>();
                    l.Add(r);
                    hasParent.Add(r.Pid);
                }
            }

            var visited = new HashSet<int>();
            void Walk(ProcRow r, int depth)
            {
                if (!visited.Add(r.Pid)) return;
                r.Depth = depth;
                _view.Add(r);
                if (children.TryGetValue(r.Pid, out var kids))
                    foreach (var k in kids.OrderBy(x => x.Name, StringComparer.OrdinalIgnoreCase))
                        Walk(k, depth + 1);
            }

            foreach (var root in _all.Where(r => !hasParent.Contains(r.Pid)).OrderBy(r => r.Name, StringComparer.OrdinalIgnoreCase))
                Walk(root, 0);

            foreach (var r in _all) if (!visited.Contains(r.Pid)) { r.Depth = 0; _view.Add(r); }
        }

        private ProcRow? Sel => ProcListView.SelectedItem as ProcRow;

        private void Row_DoubleTapped(object sender, Microsoft.UI.Xaml.Input.DoubleTappedRoutedEventArgs e) => OpenFolder(Sel);

        private void Ctx_Folder(object sender, RoutedEventArgs e) => OpenFolder(Sel);

        private static void OpenFolder(ProcRow? r)
        {
            if (r == null || r.Path.Length == 0 || !File.Exists(r.Path)) return;
            try { Process.Start(new ProcessStartInfo("explorer.exe", $"/select,\"{r.Path}\"") { UseShellExecute = true }); } catch { }
        }

        private void Ctx_CopyPath(object sender, RoutedEventArgs e) { if (Sel is { Path.Length: > 0 } r) Copy(r.Path); }

        private void Ctx_CopyHash(object sender, RoutedEventArgs e)
        {
            if (Sel is not { Path.Length: > 0 } r) return;
            Status.Text = "hashing…";
            Task.Run(() => { string h = ProcessList.Sha256(r.Path); _ui.TryEnqueue(() => { if (h.Length > 0) { Copy(h); Status.Text = "SHA-256 copied"; } else Status.Text = "hash failed"; }); });
        }

        private void Ctx_VirusTotal(object sender, RoutedEventArgs e)
        {
            if (Sel is not { Path.Length: > 0 } r) return;
            Status.Text = "hashing for VirusTotal…";
            Task.Run(() =>
            {
                string h = ProcessList.Sha256(r.Path);
                _ui.TryEnqueue(() =>
                {
                    if (h.Length == 0) { Status.Text = "hash failed"; return; }
                    try { Process.Start(new ProcessStartInfo($"https://www.virustotal.com/gui/file/{h}") { UseShellExecute = true }); } catch { }
                    Status.Text = "opened VirusTotal";
                });
            });
        }

        private async void Ctx_Modules(object sender, RoutedEventArgs e)
        {
            if (Sel is not { } r) return;
            int pid = r.Pid; string pname = r.Name;
            Status.Text = $"loading modules of {pname}…";
            var mods = await Task.Run(() => ProcessList.Modules(pid));

            var panel = new StackPanel { Spacing = 1 };
            if (mods.Count == 0)
                panel.Children.Add(new TextBlock { Text = "нет доступа к модулям (попробуй от администратора / другая разрядность процесса)", FontSize = 12, Foreground = new Microsoft.UI.Xaml.Media.SolidColorBrush(Microsoft.UI.Colors.Orange) });
            foreach (var m in mods)
            {
                var tb = new TextBlock
                {
                    FontFamily = new Microsoft.UI.Xaml.Media.FontFamily("Consolas"),
                    FontSize = 12,
                    TextWrapping = TextWrapping.NoWrap,
                    Text = $"{(m.Sig.Length > 0 ? m.Sig : "?"),-9}  {m.Name,-30}  {m.Path}",
                    Foreground = m.Level == "warn"
                        ? new Microsoft.UI.Xaml.Media.SolidColorBrush(Microsoft.UI.Colors.Orange)
                        : new Microsoft.UI.Xaml.Media.SolidColorBrush(Microsoft.UI.Colors.Gainsboro)
                };
                panel.Children.Add(tb);
            }

            var sv = new ScrollViewer
            {
                Content = panel,
                MinWidth = 820,
                MaxHeight = 520,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Auto,
                HorizontalScrollMode = ScrollMode.Enabled,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto
            };

            int unsigned = mods.Count(m => m.Level == "warn");
            var dlg = new ContentDialog
            {
                Title = $"Modules — {pname} [{pid}]   ({mods.Count}, unsigned: {unsigned})",
                Content = sv,
                CloseButtonText = "Close",
                XamlRoot = this.XamlRoot
            };
            Status.Text = $"{mods.Count} modules · {unsigned} unsigned";
            try { await dlg.ShowAsync(); } catch { }
        }

        private void Ctx_Kill(object sender, RoutedEventArgs e)
        {
            if (Sel is not { } r) return;
            if (ProcessList.Kill(r.Pid)) { _all.Remove(r); _view.Remove(r); Status.Text = $"ended {r.Name} [{r.Pid}]"; }
            else Status.Text = $"could not end [{r.Pid}]";
        }

        private static void Copy(string text)
        {
            try { var dp = new DataPackage(); dp.SetText(text); Clipboard.SetContent(dp); } catch { }
        }
    }
}
