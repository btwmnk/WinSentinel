using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.UI.Dispatching;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Windows.ApplicationModel.DataTransfer;
using XFlags.Services;

namespace XFlags.Features
{
    public sealed partial class ExecutionPage : Page
    {
        private readonly ObservableCollection<ExecRow> _view = new();
        private readonly List<ExecRow> _all = new();
        private readonly DispatcherQueue _ui;
        private CancellationTokenSource? _cts;

        public ExecutionPage()
        {
            InitializeComponent();
            _ui = DispatcherQueue.GetForCurrentThread();
            List.ItemsSource = _view;
            Loaded += (s, e) => { if (_all.Count == 0) Refresh(); };
        }

        private void Refresh_Click(object sender, RoutedEventArgs e) => Refresh();

        private void Refresh()
        {
            _cts?.Cancel();
            _cts = new CancellationTokenSource();
            var token = _cts.Token;
            BtnRefresh.IsEnabled = false;
            Status.Text = "reading history…";
            _all.Clear(); _view.Clear();

            Task.Run(() =>
            {
                var rows = ExecHistory.Scan();
                _ui.TryEnqueue(() =>
                {
                    if (token.IsCancellationRequested) return;
                    _all.AddRange(rows);
                    ApplyFilter();
                    Status.Text = $"{rows.Count} records";
                    BtnRefresh.IsEnabled = true;
                });
            }, token);
        }

        private void Filter_Changed(object sender, TextChangedEventArgs e) => ApplyFilter();

        private void ApplyFilter()
        {
            string q = Filter.Text?.Trim() ?? "";
            _view.Clear();
            foreach (var r in _all)
            {
                if (q.Length > 0 && !(r.Name.Contains(q, StringComparison.OrdinalIgnoreCase) || r.Path.Contains(q, StringComparison.OrdinalIgnoreCase))) continue;
                _view.Add(r);
            }
        }

        private ExecRow? Sel => List.SelectedItem as ExecRow;

        private void Ctx_Folder(object sender, RoutedEventArgs e)
        {
            if (Sel is not { } r) return;
            string p = r.PfFile.Length > 0 ? r.PfFile : r.Path;
            if (p.Length == 0 || !File.Exists(p)) { Status.Text = "файл не найден на диске"; return; }
            try { Process.Start(new ProcessStartInfo("explorer.exe", $"/select,\"{p}\"") { UseShellExecute = true }); } catch { }
        }

        private void Ctx_CopyPath(object sender, RoutedEventArgs e)
        {
            if (Sel is not { } r) return;
            try { var dp = new DataPackage(); dp.SetText(r.Path); Clipboard.SetContent(dp); } catch { }
        }

        private void Ctx_Delete(object sender, RoutedEventArgs e)
        {
            if (Sel is not { } r) return;
            if (ExecHistory.Delete(r)) { _all.Remove(r); _view.Remove(r); Status.Text = $"deleted ({r.Source}): {r.Name}"; }
            else Status.Text = "не удалось удалить (нет прав — запись BAM защищена системой)";
        }
    }
}
