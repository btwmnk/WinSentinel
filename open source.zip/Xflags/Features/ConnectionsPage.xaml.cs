using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.UI.Dispatching;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Windows.ApplicationModel.DataTransfer;
using XFlags.Services;

namespace XFlags.Features
{
    public sealed partial class ConnectionsPage : Page
    {
        private readonly ObservableCollection<ConnRow> _view = new();
        private readonly List<ConnRow> _all = new();
        private readonly DispatcherQueue _ui;
        private CancellationTokenSource? _cts;

        public ConnectionsPage()
        {
            InitializeComponent();
            _ui = DispatcherQueue.GetForCurrentThread();
            List.ItemsSource = _view;
            Loaded += (s, e) => { if (_all.Count == 0) Refresh(); };
        }

        private void Refresh_Click(object sender, RoutedEventArgs e) => Refresh();

        private void Refresh()
        {
            _cts?.Cancel();
            _cts = new CancellationTokenSource();
            var token = _cts.Token;
            BtnRefresh.IsEnabled = false;
            Status.Text = "scanning connections…";
            _all.Clear(); _view.Clear();

            Task.Run(() =>
            {
                var rows = NetConnections.Scan();
                rows.Sort((a, b) => Rank(b).CompareTo(Rank(a)) is int c and not 0 ? c
                    : string.Compare(a.Proc, b.Proc, StringComparison.OrdinalIgnoreCase));
                int sus = rows.Count(r => r.Level != "ok");
                _ui.TryEnqueue(() =>
                {
                    if (token.IsCancellationRequested) return;
                    _all.AddRange(rows);
                    ApplyFilter();
                    Status.Text = $"{rows.Count} connections · {sus} flagged";
                    BtnRefresh.IsEnabled = true;
                });
            }, token);
        }

        private static int Rank(ConnRow r) => r.Level == "bad" ? 2 : r.Level == "warn" ? 1 : 0;

        private void Filter_Changed(object sender, TextChangedEventArgs e) => ApplyFilter();
        private void Filter_Toggle(object sender, RoutedEventArgs e) => ApplyFilter();

        private void ApplyFilter()
        {
            string q = Filter.Text?.Trim() ?? "";
            bool ext = OnlyExternal.IsChecked == true;
            bool sus = OnlySus.IsChecked == true;
            _view.Clear();
            foreach (var r in _all)
            {
                if (ext && !(r.PublicRemote && r.State == "ESTABLISHED")) continue;
                if (sus && r.Level == "ok") continue;
                if (q.Length > 0 &&
                    !(r.Proc.Contains(q, StringComparison.OrdinalIgnoreCase)
                      || r.Remote.Contains(q, StringComparison.OrdinalIgnoreCase)
                      || r.Local.Contains(q, StringComparison.OrdinalIgnoreCase)
                      || r.Pid.ToString().Contains(q))) continue;
                _view.Add(r);
            }
        }

        private ConnRow? Sel => List.SelectedItem as ConnRow;

        private void Ctx_Folder(object sender, RoutedEventArgs e)
        {
            if (Sel is not { Path.Length: > 0 } r || !File.Exists(r.Path)) return;
            try { Process.Start(new ProcessStartInfo("explorer.exe", $"/select,\"{r.Path}\"") { UseShellExecute = true }); } catch { }
        }

        private void Ctx_CopyRemote(object sender, RoutedEventArgs e) { if (Sel is { } r) Copy(r.Remote); }

        private void Ctx_VirusTotal(object sender, RoutedEventArgs e)
        {
            if (Sel is not { Path.Length: > 0 } r) return;
            Status.Text = "hashing…";
            Task.Run(() =>
            {
                string h = NetConnections.Sha256(r.Path);
                _ui.TryEnqueue(() =>
                {
                    if (h.Length == 0) { Status.Text = "hash failed"; return; }
                    try { Process.Start(new ProcessStartInfo($"https://www.virustotal.com/gui/file/{h}") { UseShellExecute = true }); } catch { }
                    Status.Text = "opened VirusTotal";
                });
            });
        }

        private void Ctx_Kill(object sender, RoutedEventArgs e)
        {
            if (Sel is not { } r) return;
            if (NetConnections.Kill(r.Pid))
            {
                foreach (var x in _all.Where(c => c.Pid == r.Pid).ToList()) { _all.Remove(x); _view.Remove(x); }
                Status.Text = $"ended {r.Proc} [{r.Pid}]";
            }
            else Status.Text = $"could not end [{r.Pid}]";
        }

        private static void Copy(string text)
        {
            try { var dp = new DataPackage(); dp.SetText(text); Clipboard.SetContent(dp); } catch { }
        }
    }
}
