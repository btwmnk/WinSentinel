using System;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Data;

namespace XFlags.Common
{

    public sealed class DepthToMarginConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, string language)
        {
            int d = value is int i ? i : 0;
            return new Thickness(d * 16, 0, 0, 0);
        }

        public object ConvertBack(object value, Type targetType, object parameter, string language) => throw new NotImplementedException();
    }
}
