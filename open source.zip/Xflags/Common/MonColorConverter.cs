using System;
using Microsoft.UI;
using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Media;
using Windows.UI;

namespace XFlags.Common
{

    public sealed class MonColorConverter : IValueConverter
    {
        private static SolidColorBrush B(byte r, byte g, byte b) => new(Color.FromArgb(255, r, g, b));

        public object Convert(object value, Type targetType, object parameter, string language) => (value as string) switch
        {
            "proc"    => B(250, 204, 21),
            "reg"     => B(96, 165, 250),
            "del"     => B(248, 113, 113),
            "net"     => B(244, 114, 182),
            "asset"   => B(52, 211, 153),
            "sni"     => B(56, 189, 248),
            "http"    => B(163, 230, 53),
            "autorun" => B(251, 146, 60),
            _         => B(220, 220, 226),
        };

        public object ConvertBack(object value, Type targetType, object parameter, string language) => throw new NotImplementedException();
    }
}
