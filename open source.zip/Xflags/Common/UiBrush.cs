using Microsoft.UI;
using Microsoft.UI.Xaml.Media;
using Windows.UI;

namespace XFlags.Common
{

    public static class UiBrush
    {
        private static SolidColorBrush B(byte r, byte g, byte b) => new(Color.FromArgb(255, r, g, b));

        public static readonly SolidColorBrush Card = B(28, 28, 28);
        public static readonly SolidColorBrush Stroke = B(45, 45, 45);
        public static readonly SolidColorBrush Secondary = B(176, 176, 176);
        public static readonly SolidColorBrush Accent = B(147, 197, 253);
    }
}
