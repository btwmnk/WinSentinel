using System;
using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Media;
using Windows.UI;

namespace XFlags.Common
{

    public sealed class ProcLevelConverter : IValueConverter
    {
        private static SolidColorBrush B(byte r, byte g, byte b) => new(Color.FromArgb(255, r, g, b));

        public object Convert(object value, Type targetType, object parameter, string language) => (value as string) switch
        {
            "bad"  => B(248, 113, 113),
            "warn" => B(251, 146, 60),
            "off"  => B(110, 110, 116),
            _      => B(220, 220, 226),
        };

        public object ConvertBack(object value, Type targetType, object parameter, string language) => throw new NotImplementedException();
    }
}
