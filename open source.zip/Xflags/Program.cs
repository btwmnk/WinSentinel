using System;
using System.Runtime.InteropServices;
using System.Threading;
using Microsoft.UI.Dispatching;
using Microsoft.UI.Xaml;

namespace XFlags
{
    public static class Program
    {
        private static Mutex? _mutex;
        private const string MutexName = "XFlags_SingleInstanceMutex";
        private const string EventName = "XFlags_SingleInstanceShow";

        [DllImport("user32.dll")] private static extern bool SetForegroundWindow(IntPtr hWnd);
        [DllImport("user32.dll")] private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
        private const int SW_RESTORE = 9;

        [STAThread]
        private static void Main(string[] args)
        {
            _mutex = new Mutex(initiallyOwned: true, MutexName, out var createdNew);
            if (!createdNew)
            {
                try { EventWaitHandle.OpenExisting(EventName).Set(); } catch { }
                return;
            }

            var show = new EventWaitHandle(false, EventResetMode.AutoReset, EventName);
            var waiter = new Thread(() =>
            {
                while (true)
                {
                    try { show.WaitOne(); } catch { break; }
                    var w = App.MainWindow;
                    w?.DispatcherQueue?.TryEnqueue(() =>
                    {
                        try
                        {
                            var hwnd = WinRT.Interop.WindowNative.GetWindowHandle(w);
                            ShowWindow(hwnd, SW_RESTORE);
                            SetForegroundWindow(hwnd);
                            w.Activate();
                        }
                        catch { }
                    });
                }
            }) { IsBackground = true };
            waiter.Start();

            Application.Start((p) =>
            {
                var context = new DispatcherQueueSynchronizationContext(DispatcherQueue.GetForCurrentThread());
                SynchronizationContext.SetSynchronizationContext(context);
                _ = new App();
            });
        }
    }
}
