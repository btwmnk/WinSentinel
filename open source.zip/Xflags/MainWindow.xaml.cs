using System;
using System.Collections.Generic;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using XFlags.Features;

namespace XFlags
{
    public sealed partial class MainWindow : Window
    {
        private readonly Dictionary<string, Type> _pages = new()
        {
            ["Mitigations"] = typeof(MitigationsPage),
            ["Monitor"] = typeof(MonitorPage),
            ["Processes"] = typeof(ProcessesPage),
            ["Autoruns"] = typeof(AutorunsPage),
            ["Connections"] = typeof(ConnectionsPage),
            ["Drivers"] = typeof(DriversPage),
            ["Injection"] = typeof(InjectionPage),
            ["Defender"] = typeof(DefenderPage),
            ["Execution"] = typeof(ExecutionPage),
            ["Hosts"] = typeof(HostsPage),
        };

        public MainWindow()
        {
            InitializeComponent();
            ExtendsContentIntoTitleBar = true;
            SetTitleBar(AppTitleBar);
        }

        private void NavView_Loaded(object sender, RoutedEventArgs e)
        {
            ContentFrame.Navigate(typeof(MitigationsPage));
            if (NavView.MenuItems.Count > 0)
                NavView.SelectedItem = NavView.MenuItems[0];
        }

        private void NavView_ItemInvoked(NavigationView sender, NavigationViewItemInvokedEventArgs args)
        {
            if (args.InvokedItemContainer is NavigationViewItem { Tag: string tag } && _pages.TryGetValue(tag, out var pageType))
                ContentFrame.Navigate(pageType);
        }
    }
}
